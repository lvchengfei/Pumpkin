//
//  PKAccountManager.h
//  Pumpkin
//
//  Created by lv on 6/14/12.
//  Copyright (c) 2012 XXXXX. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PKNetwork.h"

typedef enum 
{
	PKNoneErr,
	PKLogInErr,
	PKNetworkErr,
	PKAuthCodeErr,
	PKHaveRegisterErr,
	PKOldPasswordErr,
	PKChangePasswordErr,
	PKOldAccountErr,
	PKChangeAccountErr,
	PKRemoveAccountErr,
	PKResver,
	
}PKAccountErrorCode;



@class PKAccountManager;
@protocol PKAccountManagerProtocol <NSObject>
@optional
- (void)accountManager:(PKAccountManager*)accountManager registerAccount:(BOOL)isSuccess errorCode:(PKAccountErrorCode)errCode;
- (void)accountManager:(PKAccountManager*)accountManager logInAccount:(BOOL)isSuccess errorCode:(PKAccountErrorCode)errCode;
- (void)accountManager:(PKAccountManager*)accountManager getAuthCode:(BOOL)isSuccess errorCode:(PKAccountErrorCode)errCode;
- (void)accountManager:(PKAccountManager*)accountManager changeAccount:(BOOL)isSuccess errorCode:(PKAccountErrorCode)errCode;
- (void)accountManager:(PKAccountManager*)accountManager changePassword:(BOOL)isSuccess errorCode:(PKAccountErrorCode)errCode;
- (void)accountManager:(PKAccountManager*)accountManager removeAccount:(BOOL)isSuccess errorCode:(PKAccountErrorCode)errCode;

@end

@interface PKAccountManager : NSObject <PKNetworkProtocol>
{
	PKNetwork*						netWorkEngine_;
	id<PKAccountManagerProtocol>	delegate_;
	BOOL							isShowPassWord_;
	NSString*						account_;
	NSString*						passWord_;
	NSString*						tmpInfo_;
	
	NSString*						avatarName_;
	
@private
	struct
	{
		unsigned registerErrorCode		:1;
		unsigned logInErrorCode			:1;
		unsigned getAuthCodeErrCode		:1;
		unsigned changeAccountErrCode	:1;
		unsigned changePasswordErrCode	:1;
		unsigned removeAccountErrCode	:1;

	}flags_;
}
@property(nonatomic,assign) id<PKAccountManagerProtocol> delegate;
@property(nonatomic,assign) BOOL isShowPassWord;
@property(nonatomic,retain) NSString*	account;
@property(nonatomic,retain) NSString*	passWord;

- (void)registerWithAccount:(NSString*)account password:(NSString*)password auth:(NSString*)authCode;
- (void)logInWithAccount:(NSString*)account password:(NSString*)password;
- (void)getAuthorizedCode:(NSString*)account;
- (BOOL)changeAccount:(NSString*)oldAccount newAccount:(NSString*)newAccount;
- (BOOL)changePassword:(NSString*)oldPassword newPassword:(NSString*)newPassword;
- (BOOL)removeUserWithAccount:(NSString*)account password:(NSString*)password;

- (void)resetDefaultsIfNeed;
//- (void)removeAccountWithAccount:(NSString*)account password:(NSString*)password;
@end
