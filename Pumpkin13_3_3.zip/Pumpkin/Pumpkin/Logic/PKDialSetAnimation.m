//
//  PKDialSetAnimation.m
//  Pumpkin
//
//  Created by lv on 7/8/12.
//  Copyright (c) 2012 XXX. All rights reserved.
//

#import "PKDialSetAnimation.h"
#import "PKPathUtil.h"
#import "PKConst.h"
#import "PKDefine.h"
#import "PKJSONKit.h"
#import "PKUtils.h"

@interface PKDialSetAnimation ()
@end

@implementation PKDialSetAnimation
@synthesize  delegate = delegate_;
@synthesize account  ;
@synthesize passWord ;

#pragma mark - Life Cycle

- (id)init
{
	self = [super init];
	if (self)
	{
		NSString* filePath = [[PKPathUtil dialAnimationPath] stringByAppendingPathComponent:kDialAnimationSetFile];
		if([[NSFileManager defaultManager] fileExistsAtPath:filePath])
		{
			animationDict_ = [[NSMutableDictionary alloc]initWithContentsOfFile:filePath];
		}
		else 
		{
			animationDict_ = [[NSMutableDictionary alloc]initWithCapacity:0];
		}
		sn_ = nil;
		
	}
	return self;
}

- (void)dealloc
{
	[animationDict_		release];
	[sn_				release];
	[super dealloc];
}

#pragma mark - Public Method

- (void)updateCandidateFriendsAinmation:(NSString*)sn
{
	[sn_	release];
	sn_ = [sn length]>0?[[NSString stringWithString:sn] retain]:nil;
	[self initCandidatePersons];
}


- (void)initCandidatePersons
{

	[selectIndexArr_ removeAllObjects];
	
	NSArray*	  animationSetArr  = [animationDict_ objectForKey:sn_];
	NSDictionary* totalPersonsDict = [contactEngine_ getTotalValidatePersonsDictionary];
	if ([totalPersonsDict count]>0) 
	{
		self.totalPersonsDict   = [NSDictionary dictionaryWithDictionary:totalPersonsDict];
		self.totalPersonsKeyArr =  [[totalPersonsDict allKeys] sortedArrayUsingSelector:@selector(compare:)];
		if ([self.totalPersonsKeyArr count]>0) 
		{
			NSMutableArray* tmpArr = [NSMutableArray arrayWithArray:self.totalPersonsKeyArr];
			[tmpArr addObject:[tmpArr objectAtIndex:0]];
			[tmpArr removeObjectAtIndex:0];
			self.totalPersonsKeyArr = [NSArray arrayWithArray:tmpArr];
		}
		
		//update pre set
		NSInteger section =0 ,row = 0;
		for (NSString* key in self.totalPersonsKeyArr) 
		{
			row = 0;
			NSArray* personsArr = [self.totalPersonsDict	objectForKey:key];
			for (PKContactPersion* person in personsArr ) 
			{
				NSString* cellPhone = [PKUtils phoneNumber:person];
				if (animationSetArr&&[animationSetArr indexOfObject:cellPhone]!=NSNotFound) 
				{
					[selectIndexArr_ addObject:[NSIndexPath indexPathForRow:row inSection:section]];
				}
				row++;
			}
			section++;
		}
		
	}
}

- (BOOL)saveSelectedPerson
{
	//NSLog(@">>>>PKDialSetAnimation saveSelectedPerson");
	BOOL result = NO;
	NSMutableArray* selectedArray = [[NSMutableArray alloc] initWithCapacity:0];
	if (isSelectAll_)
    {
		for (NSString* key in self.totalPersonsKeyArr) 
		{
			NSArray* personArr = [self.totalPersonsDict	objectForKey:key];
			for (PKContactPersion* person in personArr)
			{
				NSString* cellPhone = [PKUtils phoneNumber:person];
				if ([cellPhone length]>0)
				{
					[selectedArray addObject:cellPhone];
				}
			}
		}
    }
    else if (isSelectInArr_)
	{
		for (NSIndexPath* indexPath in selectIndexArr_) 
		{
			NSString* key = objectAtIndex(self.totalPersonsKeyArr, indexPath.section);
			NSArray* personArr = [self.totalPersonsDict objectForKey:key];
			PKContactPersion* person =objectAtIndex(personArr,indexPath.row);
			
			NSString* cellPhone = [PKUtils phoneNumber:person];
			if ([cellPhone length]>0)
			{
				[selectedArray addObject:cellPhone];
			}
		
		}
	}
	else 
	{
		NSInteger section=0,row=0;
		for (NSString* key in self.totalPersonsKeyArr) 
		{
			row = 0;
			NSArray* personArr = [self.totalPersonsDict	objectForKey:key];
			for (PKContactPersion* person in personArr)
			{
				NSIndexPath* indexPath = [NSIndexPath indexPathForRow:row inSection:section];
				if (![selectIndexArr_ containsObject:indexPath]) 
				{
					NSString* cellPhone = [PKUtils phoneNumber:person];
					if ([cellPhone length]>0)
					{
						[selectedArray addObject:cellPhone];
					}
				}
				row++;
			}
			section++;
		}
	}

	if ([selectedArray count]>0)
	{
		if ([PKUtils isNetWorkAvailable])
		{
			//删除本次为sn_设置的手机号码在之前设置的sn
			NSArray* allKeys = [animationDict_ allKeys];
			for (NSString* key in allKeys)
			{
				if ([key isEqualToString:sn_]==NO) 
				{
					NSArray* array = [animationDict_ objectForKey:key];
					if ([array count]>0)
					{
						NSMutableArray* valueArray = [NSMutableArray arrayWithArray:array];
						[valueArray removeObjectsInArray:selectedArray];
						[animationDict_ setObject:valueArray forKey:key];
					}
				}
			}
			//设置本次处理的
			[animationDict_ setObject:selectedArray forKey:sn_];

			
			if (netWorkEngine_ == nil)
			{
				netWorkEngine_ = [[PKNetwork alloc] init];
				netWorkEngine_.delegate = self;
			}
			
			//http://115.238.43.29/maike/setAnimation.action?ownerMobile=13866669999&oppositeMobile=13877770001~13877770002~13877770003&sn=
			NSString* phonesStr = [selectedArray componentsJoinedByString:@"~"];
			//NSLog(@">>>>setAnimation=%@",phonesStr);
			NSString* URLStr  = [NSString stringWithFormat:@"ownerMobile=%@&oppositeMobile=%@&sn=%@",self.account,phonesStr,sn_];
			NSData* bodyData = [URLStr dataUsingEncoding:NSUTF8StringEncoding];
			NSString* URLPath = [kMaikeSeverURL stringByAppendingPathComponent:@"setAnimation.action"];
			NSMutableURLRequest* urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:URLPath]];
			[urlRequest setHTTPMethod:@"POST"];
			[urlRequest setHTTPBody:bodyData];
			
			[netWorkEngine_ startConnectionWithURLRequest:urlRequest synchronise:NO];
			result = YES;
		}
	}
	else 
	{
		PKALERTVIEW(nil, @"你还未选择好友！", nil,@"确定",nil,nil);
	}
	[selectedArray		release];
	
	return result;
}

#pragma mark - PKNetworkProtocol Delegate

- (void) network:(PKNetwork*)network responseResult:(id)result
{
	NSData* tmpData = (NSData*)result;
	id  resultDict = [tmpData objectFromJSONData];
	if (resultDict&&[[resultDict allKeys] count]>0) 
	{
		id  result = [resultDict objectForKey:kURLResult];
		if(result&&[result isKindOfClass:[NSNumber class]]&&[result integerValue]==1) 
		{

			NSString* filePath = [[PKPathUtil dialAnimationPath] stringByAppendingPathComponent:kDialAnimationSetFile];
			[animationDict_ writeToFile:filePath atomically:YES];
		
			if (delegate_&&[delegate_ respondsToSelector:@selector(animationSet:uploadAnimationSet:errorCode:)]) 
			{
				[delegate_  animationSet:self uploadAnimationSet:YES errorCode:0];		
			}	
		}
		else 
		{
			NSInteger errCode = -1;
			errCode = [result isKindOfClass:[NSNumber class]]?[result integerValue]:-1;
			if (delegate_&&[delegate_ respondsToSelector:@selector(animationSet:uploadAnimationSet:errorCode:)]) 
			{
				[delegate_  animationSet:self uploadAnimationSet:NO errorCode:errCode];		
			}
		}
	}
	
}

- (void) network:(PKNetwork *)network responseError:(PKNetWorkErrorCode)errorCode
{
	if (delegate_&&[delegate_ respondsToSelector:@selector(animationSet:uploadAnimationSet:errorCode:)]) 
	{
		[delegate_  animationSet:self uploadAnimationSet:NO errorCode:kNetWorkErr];		
	}
}

@end
