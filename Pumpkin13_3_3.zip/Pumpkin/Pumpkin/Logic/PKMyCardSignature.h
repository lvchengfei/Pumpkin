//
//  PKMyCardSignature.h
//  Pumpkin
//
//  Created by lv on 7/4/12.
//  Copyright (c) 2012 XXX. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PKNetwork.h"


@class PKMyCardSignature;
@protocol PKMyCardSignatureProtocol <NSObject>
@optional
- (void)signature:(PKMyCardSignature*)signature uploadSignature:(BOOL)isSuccess errorCode:(NSInteger)errCode;

@end

@interface PKMyCardSignature : NSObject<PKNetworkProtocol>
{
	PKNetwork*						netWorkEngine_;
	id<PKMyCardSignatureProtocol>	delegate_;
	NSString*						placeHoldr_;
}
@property(nonatomic,assign) id<PKMyCardSignatureProtocol>	delegate;
@property(nonatomic,retain) NSString*	account;
@property(nonatomic,retain) NSString*	passWord;

- (NSString*)signatureOfMyCard;
- (NSString*)signaturePlaceHolderOfMyCard;
- (BOOL)syncMyCardSignature:(NSString*)signature;

@end
