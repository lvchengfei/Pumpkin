//
//  PKLogicEngine.m
//  Pumpkin
//
//  Created by lv on 3/3/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import "PKGroupViewLogic.h"
#import "PKCustomCellContent.h"
#import "PKSectionObject.h"
#import "PKDefine.h"
#import "PKUtils.h"

DEBUGCATEGROY(PKGroupViewLogic)

@interface PKGroupViewLogic()
@property(nonatomic,retain) NSArray* groupsArr;
@property(nonatomic,retain) NSArray* sectionArr;

- (void)initGroupSectionsArray;

@end

@implementation PKGroupViewLogic
@synthesize groupsArr  = groupsArr_;
@synthesize sectionArr = sectionArr_;

- (id)init
{
	self = [super init];
	if (self) {
		contactEngine_ = [[PKContactEngine sharedContactEngine] retain];
		[self refreshGroups];
	}
	return self;
}

-(void)dealloc
{
	[sectionArr_		release];
	[groupsArr_			release];
	[contactEngine_		release];
	[super dealloc];
}

#pragma mark - Public Method 

- (NSInteger)numberOfSection
{
	return [sectionArr_ count];
}

- (NSInteger)numberOfRowsInSection:(NSInteger)section
{
	return [objectAtIndex(sectionArr_, section) numberOfRowsInSection];
}

- (NSInteger)tagAtIndexPath:(NSIndexPath *)indexPath
{
	PKSectionObject* secObj = objectAtIndex(sectionArr_, indexPath.section);
	NSInteger tag = [secObj tagOfSection];
	return tag;
}

-(PKContactGroup*)groupRecordRefAtIndexPath:(NSIndexPath*)indexPath
{
	PKSectionObject* secObj = objectAtIndex(sectionArr_, indexPath.section);
	NSInteger tag = [secObj tagOfSection];
	return tag == kPKGroupsContentSectionTag?[secObj rowItemAtIndex:indexPath.row]:nil;
	
}

- (id)contentAtIndexPath:(NSIndexPath *)indexPath
{
	PKSectionObject* secObj = objectAtIndex(sectionArr_, indexPath.section);
	NSInteger tag = [secObj tagOfSection];
	id result = nil;
	switch (tag) {
		case kPKGroupsStartSectionTag:
		case kPKGroupsEndSectionTag:
			result = [secObj rowItemAtIndex:indexPath.row];
			break;
		case kPKGroupsContentSectionTag:
			result = [[secObj rowItemAtIndex:indexPath.row] groupName];			
			break;
		default:
			break;
	}
	return result;
}

- (NSInteger)selGroupIndex
{
	return [contactEngine_ selGroupIndex];
}

- (NSString*)groupNameOfGroupIndex:(NSInteger)index
{
	if (index==kContactGroupNone) 
	{
		return NSLocalizedString(@"kAllContact", nil);;
	}
	return [objectAtIndex(groupsArr_, index) groupName];
}

- (void)refreshGroups
{
	self.groupsArr = [contactEngine_ getGroupsArray];
	[self initGroupSectionsArray];
}



#pragma mark - Private Method

- (void)initGroupSectionsArray
{
	NSMutableArray* tmpSecArr = [[NSMutableArray alloc] initWithCapacity:0];
	//init start section 	
	NSString* text = NSLocalizedString(@"kAllContact", nil);
	PKCustomCellContent* rowContent = [PKCustomCellContent cusCellContentWithImage:nil text:text];
	NSArray* startArr = [NSArray arrayWithObjects:rowContent, nil];
	PKSectionObject* section = [[PKSectionObject alloc] initWithSectionTag:kPKGroupsStartSectionTag title:nil rowsArray:startArr];
	[tmpSecArr addObject:section];
	[section	release];
	
	//init contact section
	if ([self.groupsArr count]>0)
	{
		section = [[PKSectionObject alloc] initWithSectionTag:kPKGroupsContentSectionTag title:nil rowsArray:groupsArr_];
		[tmpSecArr addObject:section];
		[section	release];
	}
	
	//init end section 	
	UIImage* image = [PKUtils contactImageWithName:@"AddGroup.png"];
	rowContent = [PKCustomCellContent cusCellContentWithImage:image text:nil];
	NSArray* endArr = [NSArray arrayWithObjects:rowContent, nil];
	section = [[PKSectionObject alloc] initWithSectionTag:kPKGroupsEndSectionTag title:nil rowsArray:endArr];
	[tmpSecArr addObject:section];
	[section	release];
	
	self.sectionArr  = [NSArray arrayWithArray:tmpSecArr];
	[tmpSecArr	release];
}

- (void)didSelectedAtIndex:(NSIndexPath *)indexPath
{
	PKSectionObject* secObj = objectAtIndex(sectionArr_, indexPath.section);
	NSInteger tag = [secObj tagOfSection];
	switch (tag) {
		case kPKGroupsStartSectionTag:
			[contactEngine_ setSelGroupIndex:kContactGroupNone];
			break;
		case kPKGroupsEndSectionTag:
			break;
		case kPKGroupsContentSectionTag:
			[contactEngine_ setSelGroupIndex:indexPath.row];
			break;
		default:
			break;
	}
}


@end
