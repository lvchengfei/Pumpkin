//
//  PKMyCardSignature.m
//  Pumpkin
//
//  Created by lv on 7/4/12.
//  Copyright (c) 2012 XXX. All rights reserved.
//

#import "PKMyCardSignature.h"
#import "PKJSONKit.h"
#import "PKConst.h"
#import "PKDefine.h"

@interface PKMyCardSignature()
@property(nonatomic,retain) NSString* signatureText;
@property(nonatomic,retain) NSString* signatureNew;

@end

@implementation PKMyCardSignature
@synthesize delegate = delegate_;
@synthesize account  = account_;
@synthesize passWord = passWord_;
@synthesize signatureText ;
@synthesize signatureNew ;

- (id)init
{
	self = [super init];
	if (self) {
		NSUserDefaults* userDefault = [NSUserDefaults standardUserDefaults];
		NSString* signature = [userDefault objectForKey:NSLocalizedString(@"kSignature", nil)];
		self.signatureText = [signature length]>0?signature: nil;
		netWorkEngine_ = [[PKNetwork alloc] init];
		netWorkEngine_.delegate = self;
		placeHoldr_ = @"点击编辑签名";
	}
	
	return self;
}

- (void)dealloc
{
	delegate_ = nil;
	[account_		release];
	[passWord_		release];
	[signatureText	release];	
	[netWorkEngine_	release];
	[super dealloc];
}

#pragma mark - Public Method

- (NSString*)signatureOfMyCard
{
	return signatureText;
}

- (NSString*)signaturePlaceHolderOfMyCard
{
	return ([signatureText length]>0)?signatureText:placeHoldr_;
}

- (BOOL)syncMyCardSignature:(NSString*)signature
{
	BOOL result = NO;
	if ([signature length]>0&&[signatureText isEqualToString:signature]==NO)
	{
		if ([PKUtils isNetWorkAvailable])
		{
			//http://115.238.43.29/maike/setMySignature.action?ownerMobile=13866669999&sigContent=签名内容
			NSString* URLStr  = [NSString stringWithFormat:@"ownerMobile=%@&sigContent=%@",self.account,signature];
			NSData* bodyData = [URLStr dataUsingEncoding:NSUTF8StringEncoding];
			NSString* URLPath = [kMaikeSeverURL stringByAppendingPathComponent:@"setMySignature.action"];
			NSMutableURLRequest* urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:URLPath]];
			[urlRequest setHTTPMethod:@"POST"];
			[urlRequest setHTTPBody:bodyData];
			
			self.signatureNew = signature;
			[netWorkEngine_ startConnectionWithURLRequest:urlRequest synchronise:NO];
			result = YES;	
		}
	}
	else
	{
		PKALERTVIEW(nil, NSLocalizedString(@"kSignatureNotChanged", nil), nil,NSLocalizedString(@"kOK", nil),nil,nil);
	}
	return result;
	
}

#pragma mark - PKNetworkProtocol Delegate

- (void) network:(PKNetwork*)network responseResult:(id)result
{
	NSData* tmpData = (NSData*)result;
	id  resultDict = [tmpData objectFromJSONData];
	if (resultDict&&[[resultDict allKeys] count]>0) 
	{
		id  result = [resultDict objectForKey:kURLResult];
		if(result&&[result isKindOfClass:[NSNumber class]]&&[result integerValue]==1) 
		{
			
			self.signatureText = self.signatureNew;
			self.signatureNew  = nil;
			NSUserDefaults* userDefault = [NSUserDefaults standardUserDefaults];
			[userDefault setObject:self.signatureText forKey:NSLocalizedString(@"kSignature", nil)];
			[userDefault synchronize];
		
			[delegate_ signature:self uploadSignature:YES errorCode:0];			
			//NSLog(@">>>syn signture result=%d",[result integerValue]);
		}
		else 
		{
			NSInteger errCode = -1;
			errCode = [result isKindOfClass:[NSNumber class]]?[result integerValue]:-1;
			[delegate_ signature:self uploadSignature:NO errorCode:errCode];
			//NSLog(@">>>>syn signture  error = %d!!!",errCode);
		}
	}
	
}

- (void) network:(PKNetwork *)network responseError:(PKNetWorkErrorCode)errorCode
{
	//NSLog(@">>>responseError");
	[delegate_ signature:self uploadSignature:NO errorCode:kNetWorkErr];
}
@end
