//
//  PKMyCard.h
//  Pumpkin
//
//  Created by lv on 3/13/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PKMyCardCategory.h"




enum{
	kPKMyCardGenInfoCellPhone,
	kPKMyCardGenInfoTelePhone,
	kPKMyCardGenInfoEmail,
	kPKMyCardGenInfoQQ,
	kPKMyCardGenInfoMSN,
	kPKMyCardGenInfoCampany,
	kPKMyCardGenInfoTitle,
	kPKMyCardGenInfoNote,
	kPKMyCardGenInfoCount
};


@interface PKMyCard : NSObject {

	NSArray*				validateCateArr_;
	NSMutableDictionary*	cateObjectDict_;

}
- (NSInteger)categoryOfMyCard;
- (NSString*)titleOfCategory:(NSInteger)index;
- (NSInteger)rowOfCategory:(NSInteger)index;
- (NSString*)titleOfCategroy:(NSInteger)cateIndex row:(NSInteger)rowIndex;
- (BOOL)selectedOfCategroy:(NSInteger)cateIndex row:(NSInteger)rowIndex;
- (UIKeyboardType)keyBoardTypeOfCategroy:(NSInteger)cateIndex row:(NSInteger)rowIndex;
- (void)setSelected:(BOOL)selected categroy:(NSInteger)cateIndex row:(NSInteger)rowIndex;
@end
