//
//  PKDialAnimation.h
//  Pumpkin
//
//  Created by lv on 6/10/12.
//  Copyright (c) 2012 XXXXX. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PKNetwork.h"

@class PKDialAnimation;
@protocol PKDialAnimationDelegate <NSObject>
@required
- (void)dialAnimation:(PKDialAnimation*)dialAnimation updateAnimation:(BOOL)isSuccess count:(NSInteger)count error:(NSError*)error;

@end

@interface PKAnimationItem : NSObject<NSCoding>
{
	NSString* title_;
	NSString* type_;
	NSString* sn_;
	NSString* imageName_;
	UIImage*  smallImage_;
	UIImage*  largeImage_;

}
@property(nonatomic,retain) NSString*title;
@property(nonatomic,retain) NSString*type;
@property(nonatomic,retain) NSString*sn;
@property(nonatomic,retain) NSString*imageName;
@property(nonatomic,retain) UIImage*smallImage;
@property(nonatomic,retain) UIImage*largeImage;

@end


@interface PKDialAnimation : NSObject <PKNetworkProtocol>
{
	id<PKDialAnimationDelegate>delegate_; 
	PKNetwork*		netWorkEngine_;
	NSMutableArray*		curAnimationArr_;
	NSArray*			updateAnimationArr_;
	NSInteger			curUpdateIndex_;
	BOOL				isRuning_;
}
@property(nonatomic,assign) id<PKDialAnimationDelegate>delegate; 

- (void)updateAnimationNumbers;
- (NSInteger)numberOfAnimationSections;
- (NSInteger)numberOfRowsInAnimationSection:(NSInteger)section;
- (NSString*)titleOfAnimationSection:(NSInteger)section;
- (NSString*)titleOfAnimationSection:(NSInteger)section row:(NSInteger)row;
- (UIImage*)smallImageOfAnimationSection:(NSInteger)section row:(NSInteger)row;
- (UIImage*)largeImageOfAnimationSection:(NSInteger)section row:(NSInteger)row;
- (NSString*)imageNameOfAnimationSection:(NSInteger)section row:(NSInteger)row;
- (NSString*)detailTitleOfAnimationSection:(NSInteger)section row:(NSInteger)row;
- (NSString*)snOfAnimationSection:(NSInteger)section row:(NSInteger)row;
//- (PKAnimationItem*)animationItemOfAnimationSection:(NSInteger)section row:(NSInteger)row;
@end
