//
//  PKMyCardEngine.m
//  Pumpkin
//
//  Created by lv on 6/3/12.
//  Copyright (c) 2012 XXXXX. All rights reserved.
//

#import "PKMyCardEngine.h"
#import "PKConst.h"
#import "PKDefine.h"
#import "PKPathUtil.h"
#import "PKUIConst.h"
#import "PKUtils.h"
#import "PKLogicEngine.h"
#import "PKJSONKit.h"


@interface PKMyCardEngine()
@property(nonatomic,assign)	NSString*	templateName;

- (void)initMyCardTemplate;
- (void)initMyCardRowsValue;
- (void)initSectionAndRowItems;
- (NSArray*)initRowItemsOfSection:(PKMyCardSectionItem)section;
- (NSData* )generatePostMyCardData;
- (void)saveMyCardItemsValue;


@end

@implementation PKMyCardEngine
@synthesize delegate   = delegate_; 
@synthesize sectionArr = sectionArr_;
@synthesize myCardTemplate = myCardTemplate_;
@synthesize selTemplateIndex = selTemplateIndex_;
@synthesize templateName = templateName_;

- (id)init
{
	self = [super init];
	if (self) {
			
		sectionArr_   = [[NSMutableArray alloc] initWithCapacity:0];
		rowItemDict_  = [[NSMutableDictionary alloc] initWithCapacity:0];
		rowTitleDict_ = [[NSMutableDictionary alloc] initWithDictionary:[PKUtils myCardAllItemsTitleDictionary]];
		rowValueDict_ = [[NSMutableDictionary alloc] initWithCapacity:0];
		
		candidateSectionArr_ = [[NSMutableArray alloc] initWithCapacity:0];
		for (NSInteger i=kPKMyCardSectionMSN; i<kPKMyCardSectionCount; i++) 
		{
			NSArray* rowItems = [self initRowItemsOfSection:i];
			PKMyCardSection* section = [[PKMyCardSection alloc] initWithSectionTag:i title:nil rowsArray:rowItems];
			[candidateSectionArr_ addObject:section];
			[section	release];
		}
		[self initMyCardRowsValue];
		[self initSectionAndRowItems];
	
		[self initMyCardTemplate];
		
		myCardTemplate_ = [[PKLogicEngine sharedInstance] getBusinessInstance:@"PKMyCardTemplate"];
		myCardTemplate_.selTemplateName = templateName_;
		//myCardTemplate_ = [[PKMyCardTemplate alloc] initWithTemplateName:templateName_];
		myCardTemplate_.delegate = self;
	}
	
	return self;
}

- (void)dealloc
{
	[rowItemDict_	 release];
	[sectionArr_	 release];
	[rowItemDict_	 release];
	[templateName_			release];
	[candidateSectionArr_	release];
	[netWorkEngine_	release];
	delegate_  = nil;
	
	[super dealloc];
}

#pragma mark - Public Method

- (NSInteger)numberOfSection
{
	return [sectionArr_ count];
}

- (NSInteger)numberOfRowsInSection:(NSInteger)section
{
	NSInteger count = 0;
	PKMyCardSection* sec = objectAtIndex(sectionArr_,section);
	count = [[sec rowItemsArr] count];
	count = ([sec tagOfSection]==kPKMyCardSectionHeadImage)?1:count;
	return count;
}

- (PKMyCardSection*)sectionOfIndex:(NSInteger)index
{
	return objectAtIndex(sectionArr_,index);
}

- (PKMyCardRow*)rowOfSectionIndex:(NSInteger)section rowIndex:(NSInteger)row
{
	return [[objectAtIndex(sectionArr_, section)	rowItemsArr] objectAtIndex:row];
}

- (UIKeyboardType)keyBoardTypeOfSectionIndex:(NSInteger)section rowIndex:(NSInteger)row
{
	UIKeyboardType keyboardType = UIKeyboardTypeDefault;
	PKMyCardRow* rowItem = [[objectAtIndex(sectionArr_, section)	rowItemsArr] objectAtIndex:row];
	switch (rowItem.tag) 
	{
		case kPKMyCardRowName:
		case kPKMyCardRowCompany:
		case kPKMyCardRowDepartment:
		case kPKMyCardRowTitle:
		case kPKMyCardRowCompanyAddress:
		case kPKMyCardRowHomeAddress:
			keyboardType = UIKeyboardTypeDefault;
			break;
		case kPKMyCardRowCellPhone:
		case kPKMyCardRowQQ:
		case kPKMyCardRowWorkPhone:
			keyboardType = UIKeyboardTypeNumberPad;
			break;
		case	kPKMyCardRowEmail:
			keyboardType = UIKeyboardTypeEmailAddress;
			break;
		case kPKMyCardRowGTalk:
		case kPKMyCardRowMSN:
			keyboardType = UIKeyboardTypeASCIICapable;
			break;
		case	kPKMyCardRowWebSite:
			keyboardType = UIKeyboardTypeURL;
			break;
		default:
			keyboardType = UIKeyboardTypeDefault;
			break;
	}
	return keyboardType;
}

- (NSInteger)numberOfCandidateSection
{
	return [candidateSectionArr_ count];
}

- (PKMyCardRow*)firstRowOfCandidateSectionIndex:(NSInteger)index
{
	return [[objectAtIndex(candidateSectionArr_, index)	rowItemsArr] objectAtIndex:0];
}

- (void)selectCandidateSectionIndex:(NSInteger)index
{
	PKMyCardSection* section =  objectAtIndex(candidateSectionArr_, index);
	if (section)
	{
		[sectionArr_ insertObject:section atIndex:[sectionArr_ count]-1];
		[candidateSectionArr_	removeObject:section];
	}
}

- (void)saveAvatarImage:(UIImage*)image
{
	[selAvatarImage_	release];
	selAvatarImage_ = [image retain];
	if (netWorkEngine_ == nil) 
	{
		netWorkEngine_ = [[PKNetwork alloc] init];
		netWorkEngine_.delegate = self;
	}
	NSString *BOUNDARY2 = @"6261696475696D60";

	// get protocol head
	NSMutableString *headStr = [NSMutableString stringWithCapacity:40];
	[headStr appendString:@"--"];
	[headStr appendString:BOUNDARY2];
	[headStr appendString:@"\r\n"];
	[headStr appendString:@"Content-Disposition: form-data;name=\""];
	[headStr appendString:@"attachement"];
	[headStr appendString:@"\";filename=\"attachement\"\r\n"];
	[headStr appendString:@"Content-Type: application/octet-stream\r\n\r\n"];
	
	// get protocol end
	NSMutableString *endStr = [NSMutableString stringWithCapacity:40];
	[endStr appendString:@"\r\n--"];
	[endStr appendString:BOUNDARY2];
	[endStr appendString:@"--\r\n"];
	
	//http://115.238.43.29/maike/setMyAvatar.action
	NSString* account = [rowValueDict_ objectForKey:[NSNumber numberWithInteger:kPKMyCardRowCellPhone]];
	//NSString* URLStr  = [NSString stringWithFormat:@"ownerMobile=%@&attachement=",account];
	//NSData* bodyData =  [URLStr dataUsingEncoding:NSUTF8StringEncoding];
	NSMutableData* totalData = [NSMutableData dataWithCapacity:0];
	// compile data
	[totalData appendData:[headStr dataUsingEncoding:NSUTF8StringEncoding]];
	[totalData appendData:UIImagePNGRepresentation(image)];
	[totalData appendData:[endStr dataUsingEncoding:NSUTF8StringEncoding]];
	
	//[totalData appendData:bodyData];
	//[totalData appendData:UIImagePNGRepresentation(image)];
	//NSString* URLPath = [kMaikeSeverURL stringByAppendingPathComponent:@"setMyAvatar.action"];
	NSString* URLPath = [NSString stringWithFormat:@"%@/setMyAvatar.action?ownerMobile=%@",kMaikeSeverURL,account];

	NSMutableURLRequest* urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:URLPath]];
	[urlRequest setHTTPMethod:@"POST"];
	[urlRequest setHTTPBody:totalData];
	NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@", BOUNDARY2];
	[urlRequest addValue:contentType forHTTPHeaderField: @"Content-Type"];
	
	netWorkEngine_.tag = kUploadMyCardAvatar;
	[netWorkEngine_ startConnectionWithURLRequest:urlRequest synchronise:NO];
}

- (void)saveMyCardEdit
{
	if (netWorkEngine_ == nil) 
	{
		netWorkEngine_ = [[PKNetwork alloc] init];
		netWorkEngine_.delegate = self;
	}
	NSData* bodyData = [self generatePostMyCardData];
	//http://115.238.43.29/maike/saveUserInfo.action?mobile=13899990002&name=abc
	NSString* URLPath = [kMaikeSeverURL stringByAppendingPathComponent:@"saveUserInfo.action"];
	NSMutableURLRequest* urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:URLPath]];
	[urlRequest setHTTPMethod:@"POST"];
	[urlRequest setHTTPBody:bodyData];
	
	netWorkEngine_.tag = kUploadMyCardItem;
	[netWorkEngine_ startConnectionWithURLRequest:urlRequest synchronise:NO];
}
	

- (void)cancelMyCardEdit
{
	NSMutableArray* tmpSection = [[NSMutableArray alloc] initWithCapacity:0];
	for (PKMyCardSection* section in sectionArr_)
	{
		PKMyCardSectionItem sectionTag = section.tagOfSection;
		PKMyCardRow* row = objectAtIndex([section rowItemsArr], 0);
		if(sectionTag>=kPKMyCardSectionMSN &&row.value==nil)
		{
			[tmpSection addObject:section];
		}
	}
	[sectionArr_			removeObjectsInArray:tmpSection];
	[candidateSectionArr_   addObjectsFromArray:tmpSection];
	[candidateSectionArr_	sortUsingComparator:^(id obj1,id obj2){ 
		PKMyCardSection* u1 = (PKMyCardSection*)obj1;
        PKMyCardSection* u2 = (PKMyCardSection*)obj2;
        return u1.tagOfSection>u2.tagOfSection;}];
	[tmpSection	release];
}

//上传完成后保存选中模板
- (void)saveTemplateName:(NSString*)templateName
{
	if (templateName&&[kDefaultTemplateArray indexOfObject:templateName]!=NSNotFound)
	{
		self.templateName     = templateName;
		self.selTemplateIndex =  [kDefaultTemplateArray indexOfObject:templateName];
		NSUserDefaults* userDefault = [NSUserDefaults standardUserDefaults];
		[userDefault setObject:self.templateName  forKey:kMyCardTemplateName];
		[userDefault synchronize];
	}
}
//取消还未上传服务器的模板选择
- (void)cancelTemplateSelected
{
	[self initMyCardTemplate];
	myCardTemplate_.selTemplateName = templateName_;
}

//首次登录后需要重新载入信息
- (void)reloadPersonInfoIfNeed
{
	if ([PKUtils checkShouldReloadPersonInfo]) 
	{
		[self initMyCardRowsValue];		
	}
}

#pragma mark - Private Method

- (void)initMyCardTemplate
{
	NSUserDefaults* userDefault = [NSUserDefaults standardUserDefaults];
	[templateName_	release];
	templateName_ = [[NSString alloc] initWithString:kDefaultTemplateName];
	selTemplateIndex_ = kDefaultTemplateIndex;
	if ([userDefault objectForKey:kMyCardTemplateName])
	{
		templateName_ = [[userDefault objectForKey:kMyCardTemplateName] retain];
		selTemplateIndex_ = [kDefaultTemplateArray indexOfObject:templateName_];
	}
}

- (void)initMyCardRowsValue
{
	NSString* value = nil;
	NSUserDefaults* userDefault = [NSUserDefaults standardUserDefaults];
	[rowValueDict_ setObject:[PKUtils loadAvatarImage]		forKey:[NSNumber numberWithInteger:kPKMyCardRowAvatar]];
	value = [userDefault objectForKey:NSLocalizedString(@"kName", nil)];
	if (value) 
	{
		[rowValueDict_ setObject:value		forKey:[NSNumber numberWithInteger:kPKMyCardRowName]];
	}
	value = [userDefault objectForKey:kAccountInfo];//NSLocalizedString(@"kCellPhone", nil)
	if (value) 
	{
		[rowValueDict_ setObject:value		forKey:[NSNumber numberWithInteger:kPKMyCardRowCellPhone]];
	}
	value = [userDefault objectForKey:NSLocalizedString(@"kCompany", nil)];
	if (value) 
	{
		[rowValueDict_ setObject:value		forKey:[NSNumber numberWithInteger:kPKMyCardRowCompany]];
	}
	value = [userDefault objectForKey:NSLocalizedString(@"kDepartMent", nil)];
	if (value) 
	{
		[rowValueDict_ setObject:value		forKey:[NSNumber numberWithInteger:kPKMyCardRowDepartment]];
	}
	value = [userDefault objectForKey:NSLocalizedString(@"kEmail", nil)];
	if (value) 
	{
		[rowValueDict_ setObject:value		forKey:[NSNumber numberWithInteger:kPKMyCardRowEmail]];
	}
	value = [userDefault objectForKey:NSLocalizedString(@"kQQ", nil)];
	if (value) 
	{
		[rowValueDict_ setObject:value		forKey:[NSNumber numberWithInteger:kPKMyCardRowQQ]];
	}
	value = [userDefault objectForKey:NSLocalizedString(@"kAddContactItems", nil)];
	if (value) 
	{
		[rowValueDict_ setObject:value		forKey:[NSNumber numberWithInteger:kPKMyCardRowAddItems]];
	}
	value = [userDefault objectForKey:NSLocalizedString(@"kMSN", nil)];
	if (value) 
	{
		[rowValueDict_ setObject:value		forKey:[NSNumber numberWithInteger:kPKMyCardRowMSN]];
	}
	value = [userDefault objectForKey:NSLocalizedString(@"kGtalk", nil)];
	if (value) 
	{
		[rowValueDict_ setObject:value		forKey:[NSNumber numberWithInteger:kPKMyCardRowGTalk]];
	}
	value = [userDefault objectForKey:NSLocalizedString(@"kWorkAddress", nil)];
	if (value) 
	{
		[rowValueDict_ setObject:value		forKey:[NSNumber numberWithInteger:kPKMyCardRowCompanyAddress]];
	}
	value = [userDefault objectForKey:NSLocalizedString(@"kHomeAddress", nil)];
	if (value) 
	{
		[rowValueDict_ setObject:value		forKey:[NSNumber numberWithInteger:kPKMyCardRowHomeAddress]];
	}
	value = [userDefault objectForKey:NSLocalizedString(@"kTitle", nil)];
	if (value) 
	{
		[rowValueDict_ setObject:value		forKey:[NSNumber numberWithInteger:kPKMyCardRowTitle]];
	}
	value = [userDefault objectForKey:NSLocalizedString(@"kBirthday", nil)];
	if (value) 
	{
		[rowValueDict_ setObject:value		forKey:[NSNumber numberWithInteger:kPKMyCardRowBirthday]];
	}
	value = [userDefault objectForKey:NSLocalizedString(@"kWorkPhone", nil)];
	if (value) 
	{
		[rowValueDict_ setObject:value		forKey:[NSNumber numberWithInteger:kPKMyCardRowWorkPhone]];
	}
	value = [userDefault objectForKey:NSLocalizedString(@"kWebSite", nil)];
	if (value) 
	{
		[rowValueDict_ setObject:value		forKey:[NSNumber numberWithInteger:kPKMyCardRowWebSite]];
	}

}

- (void)initSectionAndRowItems
{
	//1.默认字段
	for (NSInteger i=kPKMyCardSectionHeadImage; i<=kPKMyCardSectionAddItem; i++) 
	{
		NSArray* rowItems = [self initRowItemsOfSection:i];
		PKMyCardSection* section = [[PKMyCardSection alloc] initWithSectionTag:i title:nil rowsArray:rowItems];
		[sectionArr_ addObject:section];
		if (i==kPKMyCardSectionHeadImage)
		{
			section.image = [rowValueDict_ objectForKey:[NSNumber numberWithInt:kPKMyCardRowAvatar]];
		}
		[section	release];
	}
	//2.添加的字段
	NSUserDefaults* userDefault = [NSUserDefaults standardUserDefaults];
	if ([userDefault objectForKey:kMyCardShowContactItems])
	{
		NSArray* itemArr = [userDefault objectForKey:kMyCardShowContactItems];
		for (NSNumber* item in itemArr)
		{
			//已经添加的从可添加列表删除
			[candidateSectionArr_	removeObject:item];
			NSInteger index = [item integerValue]; 
			NSArray* rowItems = [self initRowItemsOfSection:index];
			PKMyCardSection* section = [[PKMyCardSection alloc] initWithSectionTag:index title:nil rowsArray:rowItems];
			[sectionArr_ addObject:section];
			[section	release];
		}
	}
}

- (NSArray*)initRowItemsOfSection:(PKMyCardSectionItem)section
{
	NSArray* rowArr = nil;
	switch (section) 
	{
		case kPKMyCardSectionHeadImage:
		{
			PKMyCardRow* row1 = [[PKMyCardRow alloc] initWithTitle:[rowTitleDict_ objectForKey:[NSNumber numberWithInt:kPKMyCardRowName]] rowTag:kPKMyCardRowName];
			PKMyCardRow* row2 = [[PKMyCardRow alloc] initWithTitle:[rowTitleDict_ objectForKey:[NSNumber numberWithInt:kPKMyCardRowCompany]] rowTag:kPKMyCardRowCompany];
			row1.value = [rowValueDict_ objectForKey:[NSNumber numberWithInt:kPKMyCardRowName]];
			row2.value = [rowValueDict_ objectForKey:[NSNumber numberWithInt:kPKMyCardRowCompany]];
			rowArr = [NSArray arrayWithObjects:row1,row2, nil];
			[row1	release];
			[row2	release];
		}
			break;
		case kPKMyCardSectionCellPhone:
		{
			PKMyCardRow* row = [[PKMyCardRow alloc] initWithTitle:[rowTitleDict_ objectForKey:[NSNumber numberWithInt:kPKMyCardRowCellPhone]] rowTag:kPKMyCardRowCellPhone];
			row.value = [rowValueDict_ objectForKey:[NSNumber numberWithInt:kPKMyCardRowCellPhone]];
			rowArr = [NSArray arrayWithObjects:row, nil];
			[row	release];
		}
			break;
			
		case kPKMyCardSectionDepartment:
		{
			PKMyCardRow* row = [[PKMyCardRow alloc] initWithTitle:[rowTitleDict_ objectForKey:[NSNumber numberWithInt:kPKMyCardRowDepartment]] rowTag:kPKMyCardRowDepartment];
			row.value = [rowValueDict_ objectForKey:[NSNumber numberWithInt:kPKMyCardRowDepartment]];
			rowArr = [NSArray arrayWithObjects:row, nil];
			[row	release];

		}
			break;
		case kPKMyCardSectionEmail:
		{
			PKMyCardRow* row = [[PKMyCardRow alloc] initWithTitle:[rowTitleDict_ objectForKey:[NSNumber numberWithInt:kPKMyCardRowEmail]] rowTag:kPKMyCardRowEmail];
			row.value = [rowValueDict_ objectForKey:[NSNumber numberWithInt:kPKMyCardRowEmail]];
			rowArr = [NSArray arrayWithObjects:row, nil];
			[row	release];
		}
			break;
		case kPKMyCardSectionQQ:
		{
			PKMyCardRow* row = [[PKMyCardRow alloc] initWithTitle:[rowTitleDict_ objectForKey:[NSNumber numberWithInt:kPKMyCardRowQQ]] rowTag:kPKMyCardRowQQ];
			row.value = [rowValueDict_ objectForKey:[NSNumber numberWithInt:kPKMyCardRowQQ]];
			rowArr = [NSArray arrayWithObjects:row, nil];
			[row	release];
		}
			break;
		case kPKMyCardSectionWebSite:
		{
			PKMyCardRow* row = [[PKMyCardRow alloc] initWithTitle:[rowTitleDict_ objectForKey:[NSNumber numberWithInt:kPKMyCardRowWebSite]] rowTag:kPKMyCardRowWebSite];
			row.value = [rowValueDict_ objectForKey:[NSNumber numberWithInt:kPKMyCardRowWebSite]];
			rowArr = [NSArray arrayWithObjects:row, nil];
			[row	release];
		}
			break;
		case kPKMyCardSectionAddItem:
		{
			PKMyCardRow* row = [[PKMyCardRow alloc] initWithTitle:[rowTitleDict_ objectForKey:[NSNumber numberWithInt:kPKMyCardRowAddItems]] rowTag:kPKMyCardRowAddItems];
			row.value = [rowValueDict_ objectForKey:[NSNumber numberWithInt:kPKMyCardRowAddItems]];
			rowArr = [NSArray arrayWithObjects:row, nil];
			[row	release];
		}
			break;
	
			
		case kPKMyCardSectionMSN:
		{
			PKMyCardRow* row = [[PKMyCardRow alloc] initWithTitle:[rowTitleDict_ objectForKey:[NSNumber numberWithInt:kPKMyCardRowMSN]] rowTag:kPKMyCardRowMSN];
			row.value = [rowValueDict_ objectForKey:[NSNumber numberWithInt:kPKMyCardRowMSN]];
			rowArr = [NSArray arrayWithObjects:row, nil];
			[row	release];
		}
			break;
		case kPKMyCardSectionGTalk:
		{
			PKMyCardRow* row = [[PKMyCardRow alloc] initWithTitle:[rowTitleDict_ objectForKey:[NSNumber numberWithInt:kPKMyCardRowGTalk]] rowTag:kPKMyCardRowGTalk];
			row.value = [rowValueDict_ objectForKey:[NSNumber numberWithInt:kPKMyCardRowGTalk]];
			rowArr = [NSArray arrayWithObjects:row, nil];
			[row	release];
		}
			break;
		case kPKMyCardSectionCompanyAddress:
		{
			PKMyCardRow* row = [[PKMyCardRow alloc] initWithTitle:[rowTitleDict_ objectForKey:[NSNumber numberWithInt:kPKMyCardRowCompanyAddress]] rowTag:kPKMyCardRowCompanyAddress];
			row.value = [rowValueDict_ objectForKey:[NSNumber numberWithInt:kPKMyCardRowCompanyAddress]];
			rowArr = [NSArray arrayWithObjects:row, nil];
			[row	release];
		}
			break;
		case kPKMyCardSectionHomeAddress:
		{
			PKMyCardRow* row = [[PKMyCardRow alloc] initWithTitle:[rowTitleDict_ objectForKey:[NSNumber numberWithInt:kPKMyCardRowHomeAddress]] rowTag:kPKMyCardRowHomeAddress];
			row.value = [rowValueDict_ objectForKey:[NSNumber numberWithInt:kPKMyCardRowHomeAddress]];
			rowArr = [NSArray arrayWithObjects:row, nil];
			[row	release];
		}
			break;
		case kPKMyCardSectionTitle:
		{
			PKMyCardRow* row = [[PKMyCardRow alloc] initWithTitle:[rowTitleDict_ objectForKey:[NSNumber numberWithInt:kPKMyCardRowTitle]] rowTag:kPKMyCardRowTitle];
			row.value = [rowValueDict_ objectForKey:[NSNumber numberWithInt:kPKMyCardRowTitle]];
			rowArr = [NSArray arrayWithObjects:row, nil];
			[row	release];
		}
			break;
		case kPKMyCardSectionBirthday:
		{
			PKMyCardRow* row = [[PKMyCardRow alloc] initWithTitle:[rowTitleDict_ objectForKey:[NSNumber numberWithInt:kPKMyCardRowBirthday]] rowTag:kPKMyCardRowBirthday];
			row.value = [rowValueDict_ objectForKey:[NSNumber numberWithInt:kPKMyCardRowBirthday]];
			rowArr = [NSArray arrayWithObjects:row, nil];
			[row	release];
		}
			break;
		case kPKMyCardSectionWorkPhone:
		{
			PKMyCardRow* row = [[PKMyCardRow alloc] initWithTitle:[rowTitleDict_ objectForKey:[NSNumber numberWithInt:kPKMyCardRowWorkPhone]] rowTag:kPKMyCardRowWorkPhone];
			row.value = [rowValueDict_ objectForKey:[NSNumber numberWithInt:kPKMyCardRowWorkPhone]];
			rowArr = [NSArray arrayWithObjects:row, nil];
			[row	release];
		}
			break;
		default:
			break;
	}
	return [[rowArr retain] autorelease];
}




- (NSData* )generatePostMyCardData
{
	NSMutableString* bodyStr = [NSMutableString stringWithCapacity:0];
	NSMutableString* imsStr  = [NSMutableString stringWithCapacity:0];
	[imsStr appendString:@"&ims="];
	NSDictionary* myCardKeyMapDict = [PKUtils myCardAllItemsPostKeyDictionary];
	for (PKMyCardSection* section in sectionArr_)
	{
		if (section.tagOfSection == kPKMyCardSectionHeadImage)
		{
			PKMyCardRow* rowItem = nil;
			for (NSInteger i=0; i<[[section rowItemsArr] count]; i++)
			{
				rowItem = ((PKMyCardRow* )[[section rowItemsArr] objectAtIndex:i]);
				if ([rowItem.value length]>0)
				{
					[bodyStr appendFormat:@"%@=%@&",[myCardKeyMapDict objectForKey:[NSNumber numberWithInt:rowItem.tag]],rowItem.value];
				}
			}
			
		}
		else if(section.tagOfSection==kPKMyCardSectionQQ||section.tagOfSection==kPKMyCardSectionGTalk||section.tagOfSection==kPKMyCardSectionMSN)
		{
			PKMyCardRow* rowItem = ((PKMyCardRow* )[[section rowItemsArr] objectAtIndex:0]);
			if ([rowItem.value length]>0) 
			{
				[imsStr appendFormat:@"%@:%@~ng~",[myCardKeyMapDict objectForKey:[NSNumber numberWithInt:rowItem.tag]],rowItem.value];
			}	
			
		}
		else if(section.tagOfSection!= kPKMyCardSectionAddItem)
		{
			PKMyCardRow* rowItem = ((PKMyCardRow* )[[section rowItemsArr] objectAtIndex:0]);
			if ([rowItem.value length]>0) 
			{
				[bodyStr appendFormat:@"%@=%@&",[myCardKeyMapDict objectForKey:[NSNumber numberWithInt:rowItem.tag]],rowItem.value];
			}			
		}
	}
	NSUserDefaults* userDefault = [NSUserDefaults standardUserDefaults];
	NSString* signature = [userDefault objectForKey:NSLocalizedString(@"kSignature", nil)];
	if ([signature length]>0)
	{
		[bodyStr appendFormat:@"signature=%@&",signature];
	}
	//delete the last '&'
	NSString* tmpStr  = [bodyStr substringToIndex:[bodyStr length]-1];
	NSString* imsStr1 = nil;
	if ([imsStr length]>5)
	{
		imsStr1 = [imsStr substringToIndex:[imsStr length]-4];
	}
	
	NSString* tmpStr1 = [imsStr1 length]>0?[NSString stringWithFormat:@"%@%@",tmpStr,imsStr1]:tmpStr;
	NSData* bodyData = [tmpStr1 dataUsingEncoding:NSUTF8StringEncoding];
	return bodyData;
}

//上传服务器成功后才保存个人名片信息到本地文件
- (void)saveMyCardItemsValue
{
	for (PKMyCardSection* section in sectionArr_)
	{
		if (section.tagOfSection == kPKMyCardSectionHeadImage)
		{
			PKMyCardRow* rowItem = nil;
			for (NSInteger i=0; i<[[section rowItemsArr] count]; i++)
			{
				rowItem = ((PKMyCardRow* )[[section rowItemsArr] objectAtIndex:i]);
				NSString* value = [rowItem.value length]>0?rowItem.value:@"";
				[rowValueDict_ setObject:value	forKey:[NSNumber numberWithInteger:rowItem.tag]];
				
			}
			
		}
		else if(section.tagOfSection!= kPKMyCardSectionAddItem)
		{
			PKMyCardRow* rowItem = ((PKMyCardRow* )[[section rowItemsArr] objectAtIndex:0]);
			NSString* value = [rowItem.value length]>0?rowItem.value:@"";
			[rowValueDict_ setObject:value	forKey:[NSNumber numberWithInteger:rowItem.tag]];
		}
	}

	NSDictionary* myCardTitleDict = [PKUtils myCardAllItemsTitleDictionary];	
	NSUserDefaults* userDefault = [NSUserDefaults standardUserDefaults];
	for (NSNumber* keyNumber in rowValueDict_)
	{
		if ([keyNumber intValue]!=kPKMyCardRowAvatar) 
		{
			NSString* value = [rowValueDict_ objectForKey:keyNumber];
			value = [value length]>0?value:@"";
			NSString* key   = ([keyNumber intValue]== kPKMyCardRowCellPhone)?kAccountInfo:[myCardTitleDict objectForKey:keyNumber];
			[userDefault setObject:value forKey:key];
		}
	}
	[userDefault synchronize];
}


#pragma mark - PKMyCardTemplateDelegate

- (id)valueOfMyCardRow:(PKMyCardRowItem)item
{
	return [rowValueDict_ objectForKey:[NSNumber numberWithInt:item]];
}



#pragma mark - PKNetworkProtocol Delegate

- (void) network:(PKNetwork*)network responseResult:(id)result
{
	NSData* tmpData = (NSData*)result;
	id  resultDict = [tmpData objectFromJSONData];
	if (resultDict&&[[resultDict allKeys] count]>0) 
	{
		id  result = [resultDict objectForKey:kURLResult];
		if (network.tag == kUploadMyCardItem)
		{
			if(result&&[result isKindOfClass:[NSNumber class]]&&[result integerValue]==1) 
			{
				[self saveMyCardItemsValue];
				if (delegate_&&[delegate_ respondsToSelector:@selector(myCardEngine:uploadMyCard:errorCode:)])
				{
					[delegate_ myCardEngine:self uploadMyCard:YES errorCode:0];
				}
				//NSLog(@">>>update MyCard result=%d",[result integerValue]);
			}
			else 
			{
				NSInteger errCode = -1;
				errCode = [result isKindOfClass:[NSNumber class]]?[result integerValue]:-1;
				if (delegate_&&[delegate_ respondsToSelector:@selector(myCardEngine:uploadMyCard:errorCode:)])
				{
					[delegate_ myCardEngine:self uploadMyCard:NO errorCode:errCode];
				}
				//NSLog(@">>>>>update MyCard  error = %d!!!",errCode);
			}
		}
		else if(network.tag == kUploadMyCardAvatar)
		{
			if(result&&[result isKindOfClass:[NSNumber class]]&&[result integerValue]==2) 
			{
				[self sectionOfIndex:kPKMyCardSectionHeadImage].image = selAvatarImage_;
				[rowValueDict_ setObject:selAvatarImage_ forKey:[NSNumber numberWithInt:kPKMyCardRowAvatar]];
				[selAvatarImage_	release];
				selAvatarImage_ = nil;
				if (delegate_&&[delegate_ respondsToSelector:@selector(myCardEngine:uploadAvatar:errorCode:)])
				{
					[delegate_ myCardEngine:self uploadAvatar:YES errorCode:0];
				}
				//NSLog(@">>>update MyCard avatar result=%d",[result integerValue]);
			}
			else 
			{
				NSInteger errCode = -1;
				errCode = [result isKindOfClass:[NSNumber class]]?[result integerValue]:-1;
				if (delegate_&&[delegate_ respondsToSelector:@selector(myCardEngine:uploadAvatar:errorCode:)])
				{
					[delegate_ myCardEngine:self uploadAvatar:NO errorCode:errCode];
				}
				//NSLog(@">>>>>update MyCard avatar error = %d!!!",errCode);
			}
		}
		
	}
	
}

- (void) network:(PKNetwork *)network responseError:(PKNetWorkErrorCode)errorCode
{
	//NSLog(@">>>responseError");
	if (network.tag == kUploadMyCardItem)
	{
		if (delegate_&&[delegate_ respondsToSelector:@selector(myCardEngine:uploadMyCard:errorCode:)])
		{
			[delegate_ myCardEngine:self uploadMyCard:NO errorCode:kNetWorkErr];
		}
	}
	else if(network.tag == kUploadMyCardAvatar)
	{
		if (delegate_&&[delegate_ respondsToSelector:@selector(myCardEngine:uploadAvatar:errorCode:)])
		{
			[delegate_ myCardEngine:self uploadAvatar:NO errorCode:kNetWorkErr];
		}
	}
}



@end
