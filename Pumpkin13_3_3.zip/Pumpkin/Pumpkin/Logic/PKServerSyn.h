//
//  PKServerSyn.h
//  Pumpkin
//
//  Created by lv on 8/2/12.
//  Copyright (c) 2012 XXX. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PKNetwork.h"
#import "PKContactEngine.h"

@class PKServerSyn;

@protocol PKServerSynDelegate<NSObject>
@optional
-(void)PKServerSyn:(PKServerSyn*)serverSyn requestAddFriends:(NSArray*)requestArray error:(NSError*)error;
-(void)PKServerSyn:(PKServerSyn*)serverSyn updateFriendsInfo:(NSArray*)updateArray error:(NSError*)error;
-(void)PKServerSyn:(PKServerSyn*)serverSyn setRequestAddFriends:(BOOL)isSuccess error:(NSError*)error;
-(void)PKServerSyn:(PKServerSyn*)serverSyn synMyAnimationInfo:(NSArray*)animationArray error:(NSError*)error;

@end


@interface PKServerSyn : NSObject <PKNetworkProtocol>
{
	PKNetwork*				netWorkEngine_;
	NSString*				account_;
	NSString*				passWord_;
	id<PKServerSynDelegate> delegate_;
	PKContactEngine*		contactEngine_;
	BOOL					isRuning_;
	BOOL					isCancel_;
	BOOL					isSuccess_;
	NSMutableArray*			animationArray_;
	NSMutableArray*			requestAddFriendArray_;
}
@property(nonatomic,assign) id<PKServerSynDelegate> delegate;
@property(nonatomic,retain) NSString*	account;
@property(nonatomic,retain) NSString*	passWord;
@property(nonatomic,retain) NSMutableArray*	requestAddFriendArray;



//哪些人请求我开放名片列表
- (void)synRequestAddFriends; 
//好友更新名片列表
- (void)synUpdateFriendsInfo;
//好友为我设置浮面动画更新列表
- (void)synMyAnimationInfo;
//是否同意 请求开放名片列表
- (void)setAgreeRequestFriend:(NSArray*)agreeFrirends disAgreeRequestFriends:(NSArray*)disAgreeFriends;
//保存请求自己为好友的陌生人列表
- (void)saveRequestAddArray;

@end
