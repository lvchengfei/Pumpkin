//
//  PKPersonViewLogic.m
//  Pumpkin
//
//  Created by lv on 4/15/12.
//  Copyright (c) 2012 XXXXX. All rights reserved.
//

#import "PKPersonViewLogic.h"
#import "PKDefine.h"
#import "PKSectionObject.h"
#import "PKUtils.h"

DEBUGCATEGROY(PKPersonViewLogic)


@interface PKPersonViewLogic()
@property(nonatomic,retain) NSDictionary* personsDict;
@property(nonatomic,retain) NSArray* sectionArr;

- (void)initPersonsSectionsArray:(BOOL)isHaveFirstItem;

@end

@implementation PKPersonViewLogic
@synthesize isSearching = isSearching_;
@synthesize personsDict = personsDict_;
@synthesize sectionArr  = sectionArr_;

- (id)init
{
	self = [super init];
	if (self) {
		contactEngine_    = [[PKContactEngine sharedContactEngine] retain];
		self.personsDict  = [contactEngine_ getPersonsDictionary];
		BOOL isFirstGroup = [contactEngine_ selGroupIndex]==-1;
		[self initPersonsSectionsArray:!isFirstGroup];
	}
	return self;
}

-(void)dealloc
{

	[sectionArr_			release];
	[personsDict_			release];
	[contactEngine_			release];
	[super dealloc];
}

#pragma mark - Public Method 

- (NSInteger)numberOfSection
{
	return [sectionArr_ count];
}

- (NSInteger)numberOfRowsInSection:(NSInteger)section
{
	return [objectAtIndex(sectionArr_, section) numberOfRowsInSection];
}

- (NSInteger)tagOfSectionAtIndexPath:(NSIndexPath *)indexPath
{
	PKSectionObject* secObj = objectAtIndex(sectionArr_, indexPath.section);
	NSInteger tag = [secObj tagOfSection];
	return tag;
}

- (NSString*)contentAtIndexPath:(NSIndexPath *)indexPath
{
	PKSectionObject* secObj = objectAtIndex(sectionArr_, indexPath.section);
	NSInteger tag = [secObj tagOfSection];
	NSString* result = nil;
	switch (tag) {
		case kPKPersonsSearchBarSectionTag:
			break;
		case kPKPersonsStartSectionTag:
			result = [secObj rowItemAtIndex:indexPath.row];
			break;
		case kPKPersonsEndSectionTag:
			break;
		case kPKPersonsContactSectionTag:
			result = [[secObj rowItemAtIndex:indexPath.row] contactName];			
			break;
		default:
			break;
	}
	return result;
}

- (NSString*)titleForHeaderInSection:(NSInteger)section
{
	NSString* key = nil;
	PKSectionObject* secObj = objectAtIndex(sectionArr_, section);
	NSInteger tag = [secObj tagOfSection];
	if (tag==kPKPersonsContactSectionTag) {
		key = [secObj titleOfSection];
	}
	return key;
}

- (NSArray*)sectionIndexTitlesArray
{
	NSMutableArray* titlesArray = nil;
	NSArray* personsKey = [personsDict_ allKeys];
	if ([personsKey count]>0) 
	{
		personsKey = [personsKey sortedArrayUsingSelector:@selector(compare:)];
		titlesArray = [NSMutableArray arrayWithArray:personsKey];
		[titlesArray addObject:[titlesArray objectAtIndex:0]];
		[titlesArray removeObjectAtIndex:0];
		[titlesArray insertObject:UITableViewIndexSearch atIndex:0];
	}
	return titlesArray;
}

- (UIImage*)imageAtIndexPath:(NSIndexPath *)indexPath
{
	PKSectionObject* secObj = objectAtIndex(sectionArr_, indexPath.section);
	NSInteger tag = [secObj tagOfSection];
	PKContactPersion* result = nil;
	switch (tag) {
		case kPKPersonsSearchBarSectionTag:
			break;
		case kPKPersonsStartSectionTag:
			break;
		case kPKPersonsEndSectionTag:
			break;
		case kPKPersonsContactSectionTag:
			result = [secObj rowItemAtIndex:indexPath.row];			
			break;
		default:
			break;
	}
	UIImage* image = [result image];
	if (image==nil)
	{
		image = [PKUtils contactImageWithName:@"person.png"];
	}
	return image;
}


- (void)refreshPersons
{
	self.personsDict  = [contactEngine_ getPersonsDictionary];
	BOOL isFirstGroup = [contactEngine_ selGroupIndex]==-1;
	[self initPersonsSectionsArray:!isFirstGroup];
}


- (PKContactPersion*)personRecordRefAtIndexPath:(NSIndexPath*)indexPath
{	
	PKSectionObject* secObj = objectAtIndex(sectionArr_, indexPath.section);
	NSInteger tag = [secObj tagOfSection];
	PKContactPersion* person = (tag==kPKPersonsContactSectionTag)?[secObj rowItemAtIndex:indexPath.row]:nil;
	//NSLog(@">>>>person = %@ class=%@  indexpath=%@",person,NSStringFromClass([person class]),indexPath);
	return [[person retain] autorelease];
}

- (void)searchPersonsWithKeyStr:(NSString*)keyStr
{
	self.personsDict = [contactEngine_ getPersonsDictionary];
	if ([keyStr length]>0) 
	{
		NSMutableDictionary* filteredPersonsDict = [[NSMutableDictionary alloc] initWithCapacity:0];
		NSPredicate *predicate = [NSPredicate predicateWithFormat:@"self.fullName contains[cd] %@", keyStr];
			NSDictionary* personDict  = self.personsDict;
		NSArray* personsKey = [personDict allKeys];
		personsKey = [personsKey sortedArrayUsingSelector:@selector(compare:)];
		for (NSString* key in personsKey) 
		{
			NSArray* persons   = [personDict objectForKey:key];
			NSArray* filterArr = [persons filteredArrayUsingPredicate:predicate];
			if ([filterArr count]>0) 
			{
				[filteredPersonsDict setObject:filterArr forKey:key];
			}
		}
		self.personsDict = [NSDictionary dictionaryWithDictionary:filteredPersonsDict];
		[filteredPersonsDict	release];
		
		//update section array 
		[self initPersonsSectionsArray:NO];
	}
	else 
	{
		//update section array 
		BOOL isFirstGroup = [contactEngine_ selGroupIndex]==-1;
		[self initPersonsSectionsArray:!isFirstGroup];
	}
}


- (void)didSelectedAtIndex:(NSIndexPath*)indexPath
{}

#pragma mark - Private Method

- (void)initPersonsSectionsArray:(BOOL)isHaveFirstItem
{
	NSMutableArray* tmpSecArr = [[NSMutableArray alloc] initWithCapacity:0];
	PKSectionObject* section  = nil; 
	if (isHaveFirstItem) 
	{
		//init start section 
		NSArray* startArr = [NSArray arrayWithObjects:NSLocalizedString(@"kAddMemberToGroup", nil), nil];
		section = [[PKSectionObject alloc] initWithSectionTag:kPKPersonsStartSectionTag title:nil rowsArray:startArr];
		[tmpSecArr addObject:section];
		[section	release];
	}
	
	//init contact section
	NSArray* personsKey = [personsDict_ allKeys];
	if ([personsKey count]>0) 
	{
		personsKey = [personsKey sortedArrayUsingSelector:@selector(compare:)];
		//exchange # to last position
		if ([[personsKey objectAtIndex:0] isEqualToString:@"#"]) 
		{
			NSMutableArray* tmpArr = [NSMutableArray arrayWithArray:personsKey];
			[tmpArr addObject:[tmpArr objectAtIndex:0]];
			[tmpArr removeObjectAtIndex:0];
			personsKey = tmpArr;
		}
		for (NSString* key in personsKey) 
		{
			section = [[PKSectionObject alloc] initWithSectionTag:kPKPersonsContactSectionTag title:key	rowsArray:[personsDict_ objectForKey:key]];
			[tmpSecArr addObject:section];
			[section	release];

		}
	}
	self.sectionArr = [NSArray arrayWithArray:tmpSecArr];
	[tmpSecArr	release];
	
}


@end
