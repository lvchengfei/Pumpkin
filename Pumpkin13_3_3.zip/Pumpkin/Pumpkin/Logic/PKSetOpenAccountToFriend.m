//
//  PKSetOpenAccountToFriend.m
//  Pumpkin
//
//  Created by lv on 7/8/12.
//  Copyright (c) 2012 XXX. All rights reserved.
//

#import "PKSetOpenAccountToFriend.h"
#import "PKPathUtil.h"
#import "PKConst.h"
#import "PKDefine.h"
#import "PKJSONKit.h"
#import "PKUtils.h"

@interface PKSetOpenAccountToFriend ()
@end

@implementation PKSetOpenAccountToFriend
@synthesize  delegate = delegate_;


#pragma mark - Life Cycle

- (id)init
{
	self = [super init];
	if (self)
	{
		NSString* filePath = [[PKPathUtil settingsPath] stringByAppendingPathComponent:kAccountOpenToFriendsFile];
		if([[NSFileManager defaultManager] fileExistsAtPath:filePath])
		{
			openToFriendsArray_ = [[NSMutableArray alloc] initWithContentsOfFile:filePath];
		}
		else 
		{
			openToFriendsArray_ = [[NSMutableArray alloc] initWithCapacity:0];
		}
		[self initCandidatePersons];
	}
	return self;
}

- (void)dealloc
{
	[openToFriendsArray_	release];
	[super dealloc];
}

#pragma mark - Public Method


//overWrite super initCandidatePersons
- (void)initCandidatePersons
{

	NSArray*	  animationSetArr  = openToFriendsArray_;
	NSDictionary* totalPersonsDict = [contactEngine_ getTotalValidatePersonsDictionary];
	if ([totalPersonsDict count]>0) 
	{
		self.totalPersonsDict   = [NSDictionary dictionaryWithDictionary:totalPersonsDict];
		self.totalPersonsKeyArr =  [[totalPersonsDict allKeys] sortedArrayUsingSelector:@selector(compare:)];
		if ([self.totalPersonsKeyArr count]>0) 
		{
			NSMutableArray* tmpArr = [NSMutableArray arrayWithArray:self.totalPersonsKeyArr];
			[tmpArr addObject:[tmpArr objectAtIndex:0]];
			[tmpArr removeObjectAtIndex:0];
			self.totalPersonsKeyArr = [NSArray arrayWithArray:tmpArr];
		}
		
		//update pre set
		NSInteger section =0 ,row = 0;
		for (NSString* key in self.totalPersonsKeyArr) 
		{
			row = 0;
			NSArray* personsArr = [self.totalPersonsDict	objectForKey:key];
			for (PKContactPersion* person in personsArr ) 
			{
				NSString* cellPhone = [PKUtils phoneNumber:person];
				if (animationSetArr&&[animationSetArr indexOfObject:cellPhone]!=NSNotFound) 
				{
					[selectIndexArr_ addObject:[NSIndexPath indexPathForRow:row inSection:section]];
				}
				row++;
			}
			section++;
		}
		
	}
}

- (NSString*)getSelectedFriendsPhoneNumber
{
	[self saveSelectedPerson];
	NSString* phonesStr = [openToFriendsArray_ componentsJoinedByString:@"~"];
	return phonesStr;
}

- (void)saveSelectedPerson
{
	//NSLog(@">>>>PKDialSetAnimation saveSelectedPerson");
	[openToFriendsArray_ removeAllObjects];
	if (isSelectAll_)
    {
		for (NSString* key in self.totalPersonsKeyArr) 
		{
			NSArray* personArr = [self.totalPersonsDict	objectForKey:key];
			for (PKContactPersion* person in personArr)
			{
				NSString* cellPhone = [PKUtils phoneNumber:person];
				if ([cellPhone length]>0)
				{
					[openToFriendsArray_ addObject:cellPhone];
				}
			}
		}
    }
    else if (isSelectInArr_)
	{
		for (NSIndexPath* indexPath in selectIndexArr_) 
		{
			NSString* key = objectAtIndex(self.totalPersonsKeyArr, indexPath.section);
			NSArray* personArr = [self.totalPersonsDict objectForKey:key];
			PKContactPersion* person =objectAtIndex(personArr,indexPath.row);
			
			NSString* cellPhone = [PKUtils phoneNumber:person];
			if ([cellPhone length]>0)
			{
				[openToFriendsArray_ addObject:cellPhone];
			}
		
		}
	}
	else 
	{
		NSInteger section=0,row=0;
		for (NSString* key in self.totalPersonsKeyArr) 
		{
			row = 0;
			NSArray* personArr = [self.totalPersonsDict	objectForKey:key];
			for (PKContactPersion* person in personArr)
			{
				NSIndexPath* indexPath = [NSIndexPath indexPathForRow:row inSection:section];
				if (![selectIndexArr_ containsObject:indexPath]) 
				{
					NSString* cellPhone = [PKUtils phoneNumber:person];
					if ([cellPhone length]>0)
					{
						[openToFriendsArray_ addObject:cellPhone];
					}
				}
				row++;
			}
			section++;
		}
	}

}


@end
