//
//  PKAddMemToGroup.h
//  Pumpkin
//
//  Created by lv on 3/18/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PKContactEngine.h"

@interface PKAddMemToGroup : NSObject 
{
	PKContactEngine*		contactEngine_;
	NSDictionary*			totalPersonsDict_;
	NSArray*				totalPersonsKeyArr_;
	
	BOOL			isSelectAll_;					///select all tag
    BOOL			isSelectInArr_ ;				///YES ,select item in selectIndex , NO not in
	NSMutableArray* selectIndexArr_;				///<NSIndexPath(row , section)>
}
@property(nonatomic,retain) NSDictionary* totalPersonsDict;
@property(nonatomic,retain) NSArray*	  totalPersonsKeyArr;
- (void)initCandidatePersons;

- (BOOL)isHaveCandidatePersons;
- (NSInteger)numberOfSection;
- (NSInteger)numberOfRowsInSection:(NSInteger)section;
- (NSString*)contentAtIndexPath:(NSIndexPath *)indexPath;
- (NSString*)titleForHeaderInSection:(NSInteger)section;
- (NSArray*)sectionIndexTitlesArray;

- (void)allSelected;
- (void)reverseSelected;
- (void)cancelSelected;
- (BOOL)isSelectedAtindexpath:(NSIndexPath*)indexPath;
- (void)setSelectedPerson:(BOOL)isSelected indexpath:(NSIndexPath*)index;
//保存选中项
- (void)saveSelectedPerson;

@end
