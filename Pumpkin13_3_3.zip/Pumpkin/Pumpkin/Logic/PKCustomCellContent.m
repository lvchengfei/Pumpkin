//
//  PKCustomCellContent.m
//  Pumpkin
//
//  Created by lv on 3/3/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import "PKCustomCellContent.h"


@implementation PKCustomCellContent
@synthesize image = image_ ;
@synthesize text  = text_ ;

+ (id)cusCellContentWithImage:(UIImage*)image text:(NSString*)text;
{
	PKCustomCellContent* content = [[PKCustomCellContent alloc] init];
	content.image = image ;
	content.text  = text ;
	return [content autorelease];
}

- (void)dealloc
{
	[image_ release];
	[text_	release];
	[super dealloc];
}
@end
