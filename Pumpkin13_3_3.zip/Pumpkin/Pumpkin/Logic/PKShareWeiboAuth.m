//
//  PKShareWeiboAuth.m
//  Pumpkin
//
//  Created by lv on 7/14/12.
//  Copyright (c) 2012 XXX. All rights reserved.
//

#import "PKShareWeiboAuth.h"
#import "PKConst.h"
#import "PKDefine.h"

@interface PKShareWeiboAuth()
- (void)initWeiboListAndValue;

@end

@implementation PKShareWeiboAuth

- (id)init
{
	self = [super init];
	if (self) {
		[self initWeiboListAndValue];
	}
	return self;
}

- (void)dealloc
{
	[weiboAuthoArr_				release];
	[weiboAuthoValueDict_		release];
	[super dealloc];
}

#pragma mark - 
- (NSInteger)numberOfWeiboAutho
{
	return [weiboAuthoArr_ count];
}

- (NSString*)titleOfWeiboAuthoAtIndex:(PKWeiboAuthType)index
{
	return  objectAtIndex(weiboAuthoArr_, index);
}

- (BOOL)isWeiboAuthoAtIndex:(PKWeiboAuthType)index
{
	NSNumber* number = [weiboAuthoValueDict_ objectForKey:[NSNumber numberWithInt:index]];
	return [number boolValue];
}

- (void)setWeiboAuthoAtIndex:(PKWeiboAuthType)index value:(BOOL)value
{
	NSArray* weiboArray = [NSArray arrayWithObjects:kAuthSinaWeibo,kAuthTencentWeibo,kAuthNetEaseWeibo, nil];
	NSString* weibo  = [weiboArray objectAtIndex:index];
	NSNumber* number = [weiboAuthoValueDict_ objectForKey:[NSNumber numberWithInt:index]];
	if ([weibo length]>0&&[number boolValue]!=value) 
	{
		[weiboAuthoValueDict_ setObject:[NSNumber numberWithBool:value] forKey:[NSNumber numberWithInt:index]];
		NSUserDefaults* userDefault = [NSUserDefaults standardUserDefaults];
		[userDefault setBool:value forKey:weibo];
		[userDefault synchronize];
	}
}


#pragma mark - Private Method

- (void)initWeiboListAndValue
{
	weiboAuthoArr_ = [[NSMutableArray alloc] initWithObjects:NSLocalizedString(@"kSinaWeibo", nil),
					  NSLocalizedString(@"kTencentWeibo", nil),NSLocalizedString(@"kKaiXin", nil),
					  /*NSLocalizedString(@"kNetEaseWeibo", nil),,NSLocalizedString(@"kTencentQzone", nil),NSLocalizedString(@"kRenRen", nil),NSLocalizedString(@"kKaiXin", nil),*/ nil];
	weiboAuthoValueDict_ = [[NSMutableDictionary alloc] initWithCapacity:0];
	for (NSInteger  i=0 ; i< [weiboAuthoArr_ count];i++) 
	{
		[weiboAuthoValueDict_ setObject:[NSNumber numberWithBool:NO] forKey:[NSNumber numberWithInt:i]];
	}
	
	//需要保证weiboAuthoArr_中的顺序，和weiboAuthoValueDict_中顺序一致
	NSUserDefaults* userDefault = [NSUserDefaults standardUserDefaults];
	if ([userDefault objectForKey:kAuthSinaWeibo])
	{
		[weiboAuthoValueDict_ setObject:[NSNumber numberWithBool:[userDefault boolForKey:kAuthSinaWeibo]] forKey:[NSNumber numberWithInt:kSinaWeibo]];
	}
	if ([userDefault objectForKey:kAuthTencentWeibo])
	{
		[weiboAuthoValueDict_ setObject:[NSNumber numberWithBool:[userDefault boolForKey:kAuthTencentWeibo]] forKey:[NSNumber numberWithInt:kTencentWeibo]];
	}
	if ([userDefault objectForKey:kAuthKaixin])
	{
		[weiboAuthoValueDict_ setObject:[NSNumber numberWithBool:[userDefault boolForKey:kAuthKaixin]] forKey:[NSNumber numberWithInt:kKaiXin]];
	}
	if ([userDefault objectForKey:kAuthNetEaseWeibo])
	{
		[weiboAuthoValueDict_ setObject:[NSNumber numberWithBool:[userDefault boolForKey:kAuthNetEaseWeibo]] forKey:[NSNumber numberWithInt:kNetEaseWeibo]];
	}

	
}

@end
