//
//  PKMyCard.m
//  Pumpkin
//
//  Created by lv on 3/13/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import "PKMyCard.h"
#import "PKDefine.h"

@interface PKMyCard()
- (void)initCate;

@end

@implementation PKMyCard

- (id)init
{
	self = [super init];
	if (self) {
		validateCateArr_ = [[NSArray alloc]initWithObjects:[NSNumber numberWithInt:kPKMyCardGeneralInfo],[NSNumber numberWithInt:kPKMyCardNameInfo],[NSNumber numberWithInt:kPKMyCardContactPhoneInfo], [NSNumber numberWithInt:kPKMyCardPersonalInfo],[NSNumber numberWithInt:kPKMyCardInstantMessageInfo],[NSNumber numberWithInt:kPKMyCardCharacterDesignInfo],[NSNumber numberWithInt:kPKMyCardTemplateInfo],nil];
		[self initCate];
	}

	return self;
}

- (void)dealloc
{
	[validateCateArr_	 release];
	[cateObjectDict_	 release];
	[super dealloc];
}

#pragma mark - Public Method
- (NSInteger)categoryOfMyCard
{
	return [validateCateArr_ count];
}

- (NSString*)titleOfCategory:(NSInteger)index
{
	PKMyCardCategory* cateObj =[cateObjectDict_ objectForKey:[NSNumber numberWithInt:index]];
	return [cateObj cateName];
}

- (NSInteger)rowOfCategory:(NSInteger)index
{
	PKMyCardCategory* cateObj =[cateObjectDict_ objectForKey:[NSNumber numberWithInt:index]];
	return [cateObj numberOfItems];
}

- (NSString*)titleOfCategroy:(NSInteger)cateIndex row:(NSInteger)rowIndex
{
	PKMyCardCategory* cateObj =[cateObjectDict_ objectForKey:[NSNumber numberWithInt:cateIndex]];
	return  [cateObj itemNameOfIndex:rowIndex];
}

- (BOOL)selectedOfCategroy:(NSInteger)cateIndex row:(NSInteger)rowIndex
{
	PKMyCardCategory* cateObj =[cateObjectDict_ objectForKey:[NSNumber numberWithInt:cateIndex]];
	return [cateObj itemMaskOfIndex:rowIndex];
}

- (UIKeyboardType)keyBoardTypeOfCategroy:(NSInteger)cateIndex row:(NSInteger)rowIndex
{
	PKMyCardCategory* cateObj =[cateObjectDict_ objectForKey:[NSNumber numberWithInt:cateIndex]];
	return [cateObj keyboardTypeOfIndex:rowIndex];
}

- (void)setSelected:(BOOL)selected categroy:(NSInteger)cateIndex row:(NSInteger)rowIndex
{
	PKMyCardCategory* cateObj =[cateObjectDict_ objectForKey:[NSNumber numberWithInt:cateIndex]];
	[cateObj setItemMask:selected index:rowIndex];
}

#pragma mark - Private Method

- (void)initCate
{
	cateObjectDict_ = [[NSMutableDictionary alloc] initWithCapacity:0];
	for (NSNumber* cate in validateCateArr_) {
		switch ([cate intValue]) {
			case kPKMyCardGeneralInfo:
			{
				PKMyCardCategory* cateObj = [[PKMyCardCategory alloc] initWithCategoryStyle:kPKMyCardGeneralInfo];
				[cateObjectDict_ setObject:cateObj forKey:cate];
				[cateObj	release];
			}
				break;
			case kPKMyCardNameInfo:
			{	
				PKMyCardCategory* cateObj = [[PKMyCardCategory alloc] initWithCategoryStyle:kPKMyCardNameInfo];
				[cateObjectDict_ setObject:cateObj forKey:cate];
				[cateObj	release];
			}
				break;
			case kPKMyCardContactPhoneInfo:
			{	
				PKMyCardCategory* cateObj = [[PKMyCardCategory alloc] initWithCategoryStyle:kPKMyCardContactPhoneInfo];
				[cateObjectDict_ setObject:cateObj forKey:cate];
				[cateObj	release];

			}	
				break;
			case kPKMyCardPersonalInfo:
			{	
				PKMyCardCategory* cateObj = [[PKMyCardCategory alloc] initWithCategoryStyle:kPKMyCardPersonalInfo];
				[cateObjectDict_ setObject:cateObj forKey:cate];
				[cateObj	release];
			}			
				break;
			case kPKMyCardInstantMessageInfo:
			{	
				PKMyCardCategory* cateObj = [[PKMyCardCategory alloc] initWithCategoryStyle:kPKMyCardInstantMessageInfo];
				[cateObjectDict_ setObject:cateObj forKey:cate];
				[cateObj	release];
			}			
				break;
			case kPKMyCardCharacterDesignInfo:
			{	
				PKMyCardCategory* cateObj = [[PKMyCardCategory alloc] initWithCategoryStyle:kPKMyCardCharacterDesignInfo];
				[cateObjectDict_ setObject:cateObj forKey:cate];
				[cateObj	release];
			}			
				break;
			case kPKMyCardTemplateInfo:
			{	
				PKMyCardCategory* cateObj = [[PKMyCardCategory alloc] initWithCategoryStyle:kPKMyCardTemplateInfo];
				[cateObjectDict_ setObject:cateObj forKey:cate];
				[cateObj	release];
			}			
				break;
			case kPKMyCardEmailInfo:
				break;
			default:
				break;
		}
	}
}

@end
