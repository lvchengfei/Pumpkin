//
//  PKLogicEngine.m
//  Pumpkin
//
//  Created by lv on 7/3/12.
//  Copyright (c) 2012 XXX. All rights reserved.
//

#import "PKLogicEngine.h"
#import "PKAccountManager.h"
#import "PKMyCardEngine.h"
#import "PKMyCardSignature.h"
#import "PKMyCardTemplate.h"
#import "PKDialSetAnimation.h"
#import "PKShareWeiboAuth.h"
#import "PKSettings.h"
#import "PKServerSyn.h"

#define  kPushToken		@"kPushTokenKey"

static PKLogicEngine* logicEngicInstance = nil;

//@interface NSObject(BIBUSINESSENGINE_INTERNAL)
//- (id)initWith;
//@end

@interface PKLogicEngine ()
@property(nonatomic,retain) PKSettings*				settings;
@property(nonatomic,retain) PKAccountManager*		accountManager;
@property(nonatomic,retain) PKMyCardEngine*			myCardEngine;
@property(nonatomic,retain) PKMyCardSignature*		myCardSignature;
@property(nonatomic,retain) PKMyCardTemplate*		myCardTemplate;
@property(nonatomic,retain) PKDialSetAnimation*		dialAnimationSet;
@property(nonatomic,retain) PKShareWeiboAuth*		shareWeiboAutho;
@property(nonatomic,retain) PKServerSyn*			serverSyn;


@end

@implementation PKLogicEngine
@synthesize pushToken = pushToken_;
@synthesize settings;
@synthesize accountManager ;
@synthesize myCardEngine;
@synthesize myCardSignature;
@synthesize myCardTemplate;
@synthesize dialAnimationSet;
@synthesize shareWeiboAutho;
@synthesize serverSyn;

- (id)init
{
	
	self = [super init] ;
	if (self)
	{
		accountManager = [[PKAccountManager alloc] init];
		NSData* data = [[NSUserDefaults standardUserDefaults] objectForKey:kPushToken];
		pushToken_ = [data length]>0?[[NSData dataWithData:data] retain]:nil;
	}
	return self ;
}

- (void)dealloc
{
	[pushToken_			release];
	[settings			release];
	[accountManager		release];
	[myCardEngine		release];
	[myCardSignature	release];
	[dialAnimationSet	release];
	[shareWeiboAutho	release];
	[serverSyn			release];
	[super dealloc];
}

#pragma mark Public Method

+(PKLogicEngine*)sharedInstance
{
	if (nil == logicEngicInstance) 
	{
		logicEngicInstance = [[PKLogicEngine alloc] init] ; 
	}
	return logicEngicInstance ;
}

+ (void)releaseSharedInstance 
{
	if (logicEngicInstance)
	{
		[logicEngicInstance release] ;
		logicEngicInstance = nil ;
	}
}


- (id)getBusinessInstance:(NSString*)className
{
	if ([className isEqualToString:@"PKSettings"])
	{
		if (settings==nil) 
		{
			settings = (PKSettings*)[[NSClassFromString(className) alloc] init];
			settings.account  = accountManager.account;
			settings.passWord = accountManager.passWord; 
		}
		return settings;
		
	}
	else if([className isEqualToString:@"PKAccountManager"])
	{
		if (accountManager==nil) 
		{
			accountManager = (PKAccountManager*)[[NSClassFromString(className) alloc] init];
		}
		return accountManager;
		
	}
	else if([className isEqualToString:@"PKMyCardEngine"])
	{
		if (myCardEngine==nil) 
		{
			myCardEngine = (PKMyCardEngine*)[[NSClassFromString(className) alloc] init];
		}
		return myCardEngine;
		
	}
	else if([className isEqualToString:@"PKMyCardSignature"])
	{
		if (myCardSignature==nil) 
		{
			myCardSignature = (PKMyCardSignature*)[[NSClassFromString(className) alloc] init];
			myCardSignature.account  = accountManager.account;
			myCardSignature.passWord = accountManager.passWord; 
		}
		return myCardSignature;
		
	}
	else if([className isEqualToString:@"PKMyCardTemplate"])
	{
		if (myCardTemplate==nil) 
		{
			myCardTemplate = (PKMyCardTemplate*)[[NSClassFromString(className) alloc] init];
			myCardTemplate.account  = accountManager.account;
			myCardTemplate.passWord = accountManager.passWord; 
		}
		return myCardTemplate;
		
	}
	else if([className isEqualToString:@"PKDialSetAnimation"])
	{
		if (dialAnimationSet==nil) 
		{
			dialAnimationSet = (PKDialSetAnimation*)[[NSClassFromString(className) alloc] init];
			dialAnimationSet.account  = accountManager.account;
			dialAnimationSet.passWord = accountManager.passWord; 
		}
		return dialAnimationSet;
		
	}
	
	else if([className isEqualToString:@"PKShareWeiboAuth"])
	{
		if (shareWeiboAutho==nil) 
		{
			shareWeiboAutho = (PKShareWeiboAuth*)[[NSClassFromString(className) alloc] init];
		}
		return shareWeiboAutho;
	}
	else if([className isEqualToString:@"PKServerSyn"])
	{
		if (serverSyn==nil) 
		{
			serverSyn = (PKServerSyn*)[[NSClassFromString(className) alloc] init];
			serverSyn.account  = accountManager.account;
			serverSyn.passWord = accountManager.passWord;
		}
		return serverSyn;
	}
	
	return [[[NSClassFromString(className) alloc] init] autorelease];
}


//"8d1209f2274a0250195ac82fc038ef86d70a251a8213497b4002a1c63a4f8542"
- (void)setPushToken:(NSData *)pushToken
{
	if ([pushToken length]>0 &&[pushToken_ isEqualToData:pushToken]==NO)
	{
		[pushToken_ release];
		pushToken_ = [[NSData dataWithData:pushToken] retain];
		NSUserDefaults* userDefault = [NSUserDefaults standardUserDefaults];
		[userDefault setObject:pushToken_ forKey:kPushToken];
		[userDefault synchronize];
	}
}

@end
