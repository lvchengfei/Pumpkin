//
//  PKSettings.h
//  Pumpkin
//
//  Created by lv on 5/8/12.
//  Copyright (c) 2012 XXXXX. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PKNetwork.h"

typedef enum
{
	PKContactBackup,
	PKContactResume,
	PKWeiBoAuth,
	PKShareWithFrineds,
	PKShowCallInteractive,			//是否来电显示
	PKAccountAuthManager,			//是否开放名片
	PKAccountAuthManagerDetail,		//完全开放名片，仅对好友开放，不开放
    PKChangePhoneNumber,
    PKChangePassword,
	//	PKLockAccount,
	//    PKUnlockAccount,
	//    PKAccountAuthManager,
	PKAboutUs,
	PKLogOut,
}PKSettingsType;

typedef  enum
{
	PKOpenAccountNone,
	PKOpenAccountToFriends,
	PKOpenAccountToAll,
	PKOpenAccountCount,
}PKOpenAccountType;

typedef  enum
{
	PKLogInBackup,
	PKLogInResume,
	PKLogInChangeNumber,
	PKLogInChangePassword,
	PKLogInRemoveAccount,
}
PKLogInType;

@class PKSettings;

@protocol PKSettingsDelegate <NSObject>
@optional
- (void)settings:(PKSettings*)settings showLoginView:(PKLogInType)style;
- (void)settings:(PKSettings*)settings accountOpen:(BOOL)isSuccess errorCode:(NSInteger)errCode;

@end



@interface PKSettings : NSObject <PKNetworkProtocol>
{
	NSMutableDictionary*	settingsDict_;
	NSMutableDictionary*	imageIconDict_;
	NSMutableArray*			sectionArr_;
	NSInteger				currentSelecteSet_;
	id<PKSettingsDelegate>	delegate_;
	PKNetwork*				netWorkEngine_;
	
	BOOL					isShowCallInteractive_;
	BOOL					isOpenAccountAuth_;
	//PKOpenAccountType		openAccountAutho_;	//0,不开放，1，对好友开放，2完全开放
	NSString*				frinedsPhoneList_;	//对好友开放的列表，临时记录，上传成功后写入文件
	BOOL					isRuning_;
}
@property(nonatomic,assign)id<PKSettingsDelegate>	delegate;
//@property(nonatomic,assign) PKOpenAccountType	openAccountAutho;
@property(nonatomic,retain) NSString*	account;
@property(nonatomic,retain) NSString*	passWord;

- (NSInteger)numberOfSettings;
- (NSInteger)numberOfSettingsSection;
- (NSInteger)numberOfSettingsAtSection:(NSInteger)section;
- (NSString*)contentOfSettingsAtSection:(NSInteger)section;
- (NSString*)contentOfSettingsAtSection:(NSInteger)section row:(NSInteger)row;
- (UIImage*)imageOfSettingsAtSection:(NSInteger)section row:(NSInteger)row;
- (NSInteger)tagOfSettingsAtSection:(NSInteger)section row:(NSInteger)row;
- (BOOL)showSwitchOfSettingsAtSection:(NSInteger)section row:(NSInteger)row;
- (BOOL)showDisclosureIndicatorAtIndexPath:(NSIndexPath*)indexPath;

- (void)didSeletedIndexPath:(NSIndexPath*)indexPath;
- (BOOL)valueOfSwitchTag:(NSInteger)tag;
- (BOOL)setSwitchTag:(NSInteger)tag value:(BOOL)value;
- (void)setOpenList:(NSString*)phoneList;					//设置好友开放列表
- (void)addFriendsToOpenList:(NSString*)phoneList;			//将好友加入我的开放列表
- (void)logout;//退出登录

- (NSString*)contentOfOpenAccountType:(PKOpenAccountType)type;

-(void)importAllFriendsToOpenList;

@end
