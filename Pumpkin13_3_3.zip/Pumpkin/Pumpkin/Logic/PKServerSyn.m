//
//  PKServerSyn.m
//  Pumpkin
//
//  Created by lv on 8/2/12.
//  Copyright (c) 2012 XXX. All rights reserved.
//

#import "PKServerSyn.h"
#import "PKUtils.h"
#import "PKConst.h"
#import "PKJSONKit.h"
#import "PKDefine.h"
#import "PKPathUtil.h"
#import "PKDialAnimation.h"
#import "PKToastView.h"


#define kSynAddFrinedsRequest   101
#define kSynUpdateFrinedsInfo   102
#define kSetAddFriendsRequest   103
#define ksynMyAnimationInfo     104

@interface PKServerSyn() 
@property(nonatomic, retain) NSMutableArray* animationArray;

- (void)setRequestAddFriends:(NSString*)mobile action:(NSInteger)action;
- (void)downloadAnimationIfNeed;
- (void)notifyHaveGetAnimationList;
@end

@implementation PKServerSyn
@synthesize delegate = delegate_;
@synthesize account  = account_;
@synthesize passWord = passWord_;
@synthesize animationArray = animationArray_;
@synthesize requestAddFriendArray = requestAddFriendArray_;

- (id)init
{
	self = [super init] ;
	if (self)
	{		
		netWorkEngine_ = [[PKNetwork alloc] init];
		netWorkEngine_.delegate = self;
		contactEngine_ = [PKContactEngine sharedContactEngine];
		[self initRequestAddFriendsArray];
	}
	return self ;
}
- (void)dealloc
{
	[netWorkEngine_			release];
	[requestAddFriendArray_ release];
	[super dealloc];
}

#pragma mark - Public Method

- (void)synRequestAddFriends
{
	if ([PKUtils checkNetWorkAvailable])
	{
		//http://115.238.43.29/maike/askOpenToMe.action?ownerMobile=13866669999&oppositeMobile=13899990002
		//http://115.238.43.29/maike/myAskedOpenToList.action?ownerMobile=13899990002
		//http://202.91.233.108/mobile/myAskedOpenToList.action?ownerMobile=13866669999
		NSString* URLStr  = [NSString stringWithFormat:@"ownerMobile=%@",self.account];
		NSData* bodyData = [URLStr dataUsingEncoding:NSUTF8StringEncoding];
		NSString* URLPath = [kMaikeSeverURL stringByAppendingPathComponent:@"myAskedOpenToList.action"];
		NSMutableURLRequest* urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:URLPath]];
		[urlRequest setHTTPMethod:@"POST"];
		[urlRequest setHTTPBody:bodyData];
		netWorkEngine_.tag = kSynAddFrinedsRequest;
		[netWorkEngine_ startConnectionWithURLRequest:urlRequest synchronise:NO];
	}
	else
	{
		[PKToastView dismissWithAnimation:YES];
	}

}

- (void)synUpdateFriendsInfo
{
	if ([PKUtils checkNetWorkAvailable])
	{
		//http://202.91.233.108/mobile/updateListOpenToMe.action?ownerMobile=13866669999
		NSString* URLStr  = [NSString stringWithFormat:@"ownerMobile=%@",self.account];
#warning Test
		//NSString* URLStr  = [NSString stringWithFormat:@"ownerMobile=13685361569"];

		NSData* bodyData = [URLStr dataUsingEncoding:NSUTF8StringEncoding];
		NSString* URLPath = [kMaikeSeverURL stringByAppendingPathComponent:@"updateListOpenToMe.action"];
		NSMutableURLRequest* urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:URLPath]];
		[urlRequest setHTTPMethod:@"POST"];
		[urlRequest setHTTPBody:bodyData];
		netWorkEngine_.tag = kSynUpdateFrinedsInfo;
		[netWorkEngine_ startConnectionWithURLRequest:urlRequest synchronise:NO];
	}	
	else
	{
		[PKToastView dismissWithAnimation:YES];
	}
}

- (void)synMyAnimationInfo
{
	self.animationArray = nil;
	if ([PKUtils checkNetWorkAvailable])
	{
		//http://202.91.233.108/mobile/getAnimationNotifyList.action?mobile=13866669999
		NSString* URLStr  = [NSString stringWithFormat:@"mobile=%@",self.account];
		NSData* bodyData = [URLStr dataUsingEncoding:NSUTF8StringEncoding];
		NSString* URLPath = [kMaikeSeverURL stringByAppendingPathComponent:@"getAnimationNotifyList.action"];
		NSMutableURLRequest* urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:URLPath]];
		[urlRequest setHTTPMethod:@"POST"];
		[urlRequest setHTTPBody:bodyData];
		netWorkEngine_.tag = ksynMyAnimationInfo;
		[netWorkEngine_ startConnectionWithURLRequest:urlRequest synchronise:NO];
	}
	else
	{
		[PKToastView dismissWithAnimation:YES];
	}
}

- (void)setAgreeRequestFriend:(NSArray*)agreeFrirends disAgreeRequestFriends:(NSArray*)disAgreeFriends;
{
	if ([PKUtils isNetWorkAvailable])
	{
		for (NSDictionary* personInfo in agreeFrirends)
		{
			isSuccess_ = NO;
			NSString* mobile = [personInfo objectForKey:@"mobile"];
			[self setRequestAddFriends:mobile action:1];
			if (isCancel_)
			{
				break;
			}
			if (isSuccess_)
			{
				[self updateFriendsInfo:[NSArray arrayWithObject:personInfo]];
			}
		}
		
		
		if (1)
		{			
			if (isCancel_) 
			{
				[delegate_ PKServerSyn:self setRequestAddFriends:NO error:nil];
				return;
			}
			for (NSDictionary* personInfo in disAgreeFriends) 
			{
				NSString* mobile = [personInfo objectForKey:@"mobile"];
				[self setRequestAddFriends:mobile action:0];
				if (isCancel_)
				{
					break;
				}
			}
			if (isCancel_) 
			{
				[delegate_ PKServerSyn:self setRequestAddFriends:NO error:nil];
				return;
			}
			
			[delegate_ PKServerSyn:self setRequestAddFriends:YES error:nil];
		}
	}
	else
	{
		[delegate_ PKServerSyn:self setRequestAddFriends:NO error:nil];
	}
}

//保存请求自己为好友的陌生人列表
- (void)saveRequestAddArray
{
	NSData* jsonData = [self.requestAddFriendArray JSONData];
	NSString* path = [[PKPathUtil contactPath] stringByAppendingPathComponent:kRequestAddFriendsFile];
	[jsonData writeToFile:path atomically:YES];
}

#pragma mark - Private Method

/**
 *	@brief	解析联网结果生成PKContactPersion实例的NSArray
 *
 *	@param 	friendsArray 	联网返回json解析后结果
 *
 *	@return	PKContactPersion实例的NSArray
 */
- (NSArray*)updateFriendsInfo:(NSArray*)friendsArray
{
	NSMutableArray* result = [[NSMutableArray alloc] initWithCapacity:0];
	for (NSDictionary* dict in friendsArray)
	{
		NSString* phone = [dict objectForKey:@"mobile"];
		if ([phone length]>0)
		{
			NSArray* personArray = [contactEngine_ contactsMatchingPhone:phone];
			PKContactPersion*person = objectAtIndex(personArray, 0);
			if (person==nil)
			{
				person = [contactEngine_ createNewContactPerson];
			}
			if (person)
			{
				/*
				[person setLastname:@"name"];	
				[person setOrganization:@"company"];
				[person setDepartment:@"department"];
				[person setNote:@"note"];	
				NSString* birthDay = @"1978-09-24";
				if (birthDay&&[birthDay isKindOfClass:[NSString class]]&&[birthDay length]>0)
				{
					NSDateFormatter* dateFormat = [[NSDateFormatter alloc] init];
					[dateFormat setDateFormat:@"yyyy-MM-dd"];
					NSDate* date = [dateFormat dateFromString:birthDay];//1978-09-24
					[person setBirthday:date];
					[dateFormat	release];
				}
				
				NSDictionary* qq = [NSDictionary dictionaryWithObjectsAndKeys:@"132432432",@"value",kABPersonInstantMessageServiceQQ,@"label", nil];
				NSDictionary* msn = [NSDictionary dictionaryWithObjectsAndKeys:@"dfadsfds",@"value",kABPersonInstantMessageServiceMSN,@"label", nil];
				NSDictionary* gtalk = [NSDictionary dictionaryWithObjectsAndKeys:@"abcdgtalk",@"value",kABPersonInstantMessageServiceGoogleTalk,@"label", nil];	
				[person setImDictionaries:[NSArray arrayWithObjects:qq,msn,gtalk, nil]]	;
				
	
				//NSDictionary* home = [NSDictionary dictionaryWithObjectsAndKeys:@"home",@"value",kABPersonHomePageLabel,@"label", nil];
				//NSDictionary* main = [NSDictionary dictionaryWithObjectsAndKeys:@"main",@"value",kABPersonPhoneMainLabel,@"label", nil];
				NSDictionary* mobile = [NSDictionary dictionaryWithObjectsAndKeys:@"mobile",@"value",kABPersonPhoneMobileLabel,@"label", nil];	
				NSDictionary* companyFax = [NSDictionary dictionaryWithObjectsAndKeys:@"companyFax",@"value",kABPersonPhoneWorkFAXLabel,@"label", nil];	
				NSDictionary* homeFax = [NSDictionary dictionaryWithObjectsAndKeys:@"homeFax",@"value",kABPersonPhoneHomeFAXLabel,@"label", nil];	
		
				NSDictionary* homePhone = [NSDictionary dictionaryWithObjectsAndKeys:@"homePhone",@"value",kABHomeLabel,@"label", nil];
				NSDictionary* companyPhone = [NSDictionary dictionaryWithObjectsAndKeys:@"companyPhone",@"value",kABWorkLabel,@"label", nil];
				NSDictionary* otherPhones = [NSDictionary dictionaryWithObjectsAndKeys:@"otherPhones",@"value",kABOtherLabel,@"label", nil];
				//[person setPhoneDictionaries:[NSArray arrayWithObjects:homePhone,companyPhone,otherPhones, nil]];
				
				[person setPhoneDictionaries:[NSArray arrayWithObjects:mobile,companyFax,homeFax,homePhone,companyPhone,otherPhones, nil]]	;
				
				
				//Address
				NSDictionary* homeAddress = [NSDictionary dictionaryWithObjectsAndKeys:@"homeAddress",@"value",kABHomeLabel,@"label", nil];
				NSDictionary* companyAddress = [NSDictionary dictionaryWithObjectsAndKeys:@"companyAddress",@"value",kABWorkLabel,@"label", nil];
				NSDictionary* otherAddress = [NSDictionary dictionaryWithObjectsAndKeys:@"otherAddress",@"value",kABOtherLabel,@"label", nil];
				[person setAddressDictionaries:[NSArray arrayWithObjects:homeAddress,companyAddress,otherAddress, nil]];
	

				//email
				NSDictionary* homeEmail = [NSDictionary dictionaryWithObjectsAndKeys:@"homeEmail",@"value",kABHomeLabel,@"label", nil];
				NSDictionary* companyEmail = [NSDictionary dictionaryWithObjectsAndKeys:@"companyEmail",@"value",kABWorkLabel,@"label", nil];
				[person setEmailDictionaries:[NSArray arrayWithObjects:homeEmail,companyEmail, nil]];
				
				
				//webPage
				NSDictionary* companyWebpage = [NSDictionary dictionaryWithObjectsAndKeys:@"companyWebpage",@"value",kABWorkLabel,@"label", nil];
				[person setUrlDictionaries:[NSArray arrayWithObjects:companyWebpage, nil]];
				*/
							
//				{"companyFax":"",,"companyZipcode":"","department":"","englishName":"",,"":"","homeFax":"",,"homeZipcode":"","ims":[],,,"nickName":"","note":"",:[],,"otherZipcode":"","personalWebpage":"","position":"","signature":"","updateFlag":1},
			
							
				NSString* name = [dict objectForKey:@"name"];
				if ([name length]>0)
				{
					[person setLastname:name];
					[person resetFirstName];
				}
				[person setOrganization:[dict objectForKey:@"company"]];
				[person setDepartment:[dict objectForKey:@"department"]];
				[person setNote:[dict objectForKey:@"signature"]];	
				NSString* birthDay = [dict objectForKey:@"birthday"];
				if (birthDay&&[birthDay isKindOfClass:[NSString class]]&&[birthDay length]>0)
				{
					NSDateFormatter* dateFormat = [[NSDateFormatter alloc] init];
					[dateFormat setDateFormat:@"yyyy-MM-dd"];
					NSDate* date = [dateFormat dateFromString:birthDay];//1978-09-24
					[person setBirthday:date];
					[dateFormat	release];
				}
				
				//IM
				NSArray* imArray = [dict objectForKey:@"ims"];
				if (imArray&&[imArray isKindOfClass:[NSArray class]])
				{
					NSMutableArray* resultArray = [[NSMutableArray alloc]initWithCapacity:0];
				 	//NSDictionary* imMapDict = [PKUtils myCardAllPostKeyToItemsDictionary];
					NSDictionary* imAddDict = [PKUtils myCardImDictionary];
					for (NSDictionary* imDict in imArray) 
					{
						NSString* typeKey =  [imDict objectForKey:@"imType"];
						NSString* imValue = [imDict objectForKey:@"imAddr"];
						CFStringRef label = (CFStringRef)[imAddDict objectForKey:typeKey];
						NSDictionary* dict = [NSDictionary dictionaryWithObjectsAndKeys:imValue,@"value",label,@"label", nil];
						[resultArray addObject:dict];
					}
					if ([resultArray count]>0)
					{
						[person setImDictionaries:resultArray];
					}
					[resultArray	release];
				}
				
				
				
				//Address
				NSDictionary* homeAddress = [NSDictionary dictionaryWithObjectsAndKeys:[dict objectForKey:@"homeAddress"],@"value",kABHomeLabel,@"label", nil];
				NSDictionary* companyAddress = [NSDictionary dictionaryWithObjectsAndKeys:[dict objectForKey:@"companyAddress"],@"value",kABWorkLabel,@"label", nil];
				NSDictionary* otherAddress = [NSDictionary dictionaryWithObjectsAndKeys:[dict objectForKey:@"otherAddress"],@"value",kABOtherLabel,@"label", nil];
				[person setAddressDictionaries:[NSArray arrayWithObjects:homeAddress,companyAddress,otherAddress, nil]];
				
				//Phone
				NSMutableArray* phoneArray = [[NSMutableArray alloc] initWithCapacity:0];
				if ([[dict objectForKey:@"mobile"] length]>0) {
					NSDictionary* mobile = [NSDictionary dictionaryWithObjectsAndKeys:[dict objectForKey:@"mobile"],@"value",kABPersonPhoneMobileLabel,@"label", nil];	
					[phoneArray addObject:mobile];
				}
		
				if ([[dict objectForKey:@"companyFax"] length]>0) {
					NSDictionary* companyFax = [NSDictionary dictionaryWithObjectsAndKeys:[dict objectForKey:@"companyFax"],@"value",kABPersonPhoneWorkFAXLabel,@"label", nil];	
					[phoneArray addObject:companyFax];

				}
				if ([[dict objectForKey:@"homeFax"] length]>0) 
				{
					NSDictionary* homeFax = [NSDictionary dictionaryWithObjectsAndKeys:[dict objectForKey:@"homeFax"],@"value",kABPersonPhoneHomeFAXLabel,@"label", nil];		
					[phoneArray addObject:homeFax];
				}
				
				if ([[dict objectForKey:@"homePhone"] length]>0) 
				{
					NSDictionary* homePhone = [NSDictionary dictionaryWithObjectsAndKeys:[dict objectForKey:@"homePhone"],@"value",kABHomeLabel,@"label", nil];
					[phoneArray addObject:homePhone];
				}
				if ([[dict objectForKey:@"companyPhone"] length]>0) {
					NSDictionary* companyPhone = [NSDictionary dictionaryWithObjectsAndKeys:[dict objectForKey:@"companyPhone"],@"value",kABWorkLabel,@"label", nil];
					[phoneArray addObject:companyPhone];
				}
				/*
				//签名存在电话的自定义字段中
				if ([[dict objectForKey:@"signature"] length]>0) {
					const CFStringRef customLabel = CFSTR("签名");
					NSDictionary* signature = [NSDictionary dictionaryWithObjectsAndKeys:[dict objectForKey:@"signature"],@"value",customLabel,@"label", nil];
					[phoneArray addObject:signature];
				}
				*/
				
//				if ([[dict objectForKey:@"otherPhones"] length]>0) 
//				{
//					NSDictionary* otherPhones = [NSDictionary dictionaryWithObjectsAndKeys:[dict objectForKey:@"otherPhones"],@"value",kABOtherLabel,@"label", nil];
//					[phoneArray addObject:otherPhones];
//				}
				
				[person setPhoneDictionaries:phoneArray];
				[phoneArray	release];
				

				
				//email
				NSDictionary* homeEmail = [NSDictionary dictionaryWithObjectsAndKeys:[dict objectForKey:@"homeEmail"],@"value",kABHomeLabel,@"label", nil];
				NSDictionary* companyEmail = [NSDictionary dictionaryWithObjectsAndKeys:[dict objectForKey:@"companyEmail"],@"value",kABWorkLabel,@"label", nil];
				//NSDictionary* otherEmail = [NSDictionary dictionaryWithObjectsAndKeys:[dict objectForKey:@"otherEmail"],@"value",kABOtherLabel,@"label", nil];
				[person setEmailDictionaries:[NSArray arrayWithObjects:homeEmail,companyEmail, nil]];
				
				//webPage
				NSDictionary* companyWebpage = [NSDictionary dictionaryWithObjectsAndKeys:[dict objectForKey:@"companyWebpage"],@"value",kABWorkLabel,@"label", nil];
				//NSDictionary* otherWebpage = [NSDictionary dictionaryWithObjectsAndKeys:[dict objectForKey:@"otherEmail"],@"value",kABOtherLabel,@"label", nil];
				[person setUrlDictionaries:[NSArray arrayWithObjects:companyWebpage, nil]];
				
				
				NSDictionary* value = [dict objectForKey:@"ngAvatar"];
				if (value&&[value isKindOfClass:[NSDictionary class]])
				{
					NSString* avatarName = [value objectForKey:@"path"];
					NSString* URLPath = [kMaikeSeverDownloadURL stringByAppendingPathComponent:@"/avarta/"];
					URLPath = [URLPath stringByAppendingPathComponent:avatarName];
					
					NSMutableURLRequest* urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:URLPath]];
					[urlRequest setHTTPMethod:@"GET"];
					NSHTTPURLResponse* response = nil;
					NSData* responseData =	[NSURLConnection sendSynchronousRequest:urlRequest returningResponse:&response error:nil];
					if ([response statusCode]==200)
					{
						[person setImageWithData:responseData];
					}
				}
				 
			}
			
			[contactEngine_		addPKContactPerson:person];
			if (person)
			{
				[result addObject:person];
			}
		}
		
	}
	
	NSArray* array  = [result count]>0? [NSArray arrayWithArray:result]:nil;
	[result release];
	return array;
}

/**
 *	@brief	载入之前未处理的请教自己好友列表
 */
- (void)initRequestAddFriendsArray
{
	
	NSString* path = [[PKPathUtil contactPath] stringByAppendingPathComponent:kRequestAddFriendsFile];
	NSData* data = [NSData dataWithContentsOfFile:path];
	self.requestAddFriendArray  = [data mutableObjectFromJSONData];
}
/**
 *	@brief	保存请求自己添加好友的陌生人列表 
 *
 *	@param 	requestArray 	请求自己添加好友的陌生人列表，requestArray中每条记录为一个陌生人，为NSDictionary结构，其中保存陌生人的详细名片信息
 */
- (void)saveRequestAddFriendsArray:(NSArray*)requestArray
{
	//这里requestArray类型其实是JKArray
	if (nil==self.requestAddFriendArray)
	{
		self.requestAddFriendArray = [requestArray mutableCopy];
	}
	else
	{
		[self.requestAddFriendArray addObjectsFromArray:requestArray];
	}
	[self saveRequestAddArray];
}


- (void)setRequestAddFriends:(NSString*)mobile action:(NSInteger)action
{
	if ([mobile length]>0)
	{
		isRuning_ = YES;
		//http://202.91.233.108/mobile/actionOnExchangeCard.action?mobile=13866669999&oppositeMobile=13911112222&action=1
		NSString* URLStr  = [NSString stringWithFormat:@"ownerMobile=%@&oppositeMobile=%@&action=%d",self.account,mobile,action];
		NSData* bodyData = [URLStr dataUsingEncoding:NSUTF8StringEncoding];
		NSString* URLPath = [kMaikeSeverURL stringByAppendingPathComponent:@"actionOnExchangeCard.action"];
		NSMutableURLRequest* urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:URLPath]];
		[urlRequest setHTTPMethod:@"POST"];
		[urlRequest setHTTPBody:bodyData];
		netWorkEngine_.tag = kSetAddFriendsRequest;
		netWorkEngine_.delegate = self;
		[netWorkEngine_ startConnectionWithURLRequest:urlRequest synchronise:NO];
	}
	while (isRuning_)
	{
		[[NSRunLoop currentRunLoop] runUntilDate:[NSDate dateWithTimeIntervalSinceNow:0.5]];
	}
}

- (void)downloadAnimationIfNeed
{
	BOOL haveChanged = NO;
	NSArray* animationArr = [NSKeyedUnarchiver unarchiveObjectWithFile:[PKPathUtil dialAnimationArchiverPath]];
	NSMutableArray* animationMutArr = [[NSMutableArray  alloc]initWithArray:animationArr];
	
	NSArray* localAnimationArray = kDefaultDialAnimationArray;
	for (NSDictionary* animation in self.animationArray)
	{
		NSString* sn = [animation objectForKey:@"sn"];
		if ([localAnimationArray containsObject:sn]) 
		{
			continue;
		}
		
		NSString* dir  = [animation objectForKey:kAnimationDirectory];
		NSString* path = [animation objectForKey:kAnimationPath];
		NSString* URLStr  = [NSString stringWithFormat:@"%@/%@",dir,path];
		NSString* URLPath = [kMaikeSeverDownloadURL stringByAppendingPathComponent:URLStr];
		NSMutableURLRequest* urlRequest = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:URLPath]];
		[urlRequest setHTTPMethod:@"GET"];
		NSHTTPURLResponse* response = nil;
		NSData* responseData =	[NSURLConnection sendSynchronousRequest:urlRequest returningResponse:&response error:nil];
		[urlRequest		release];
		if ([response statusCode]==200&&[responseData length]>0)
		{
			UIImage* image = [[UIImage alloc] initWithData:responseData];
			NSString* imagePath = [[PKPathUtil dialAnimationPath] stringByAppendingPathComponent:path];
			if([responseData writeToFile:imagePath atomically:YES])
			{
				PKAnimationItem* item = [[PKAnimationItem alloc] init];
				item.title = [animation objectForKey:kAnimationDescription];
				item.type  = [NSString stringWithFormat:@"animation%d" ,[[animation objectForKey:kAnimationType] integerValue]];
				item.sn    = [animation objectForKey:kAnimationSN];
				item.imageName  = [animation objectForKey:kAnimationPath];
				item.largeImage = image;
				item.smallImage = image;
				[animationMutArr addObject:item];
				[item			release];
				haveChanged = YES;
			}
			[image release];
		}
	}
	
	if (haveChanged) 
	{
		[NSKeyedArchiver archiveRootObject:animationMutArr toFile:[PKPathUtil dialAnimationArchiverPath]];
	}
	[animationMutArr	release];
	
	[self notifyHaveGetAnimationList];
}

- (void)notifyHaveGetAnimationList
{
	//http://202.91.233.108/mobile/notifyAnimationListDone.action?mobile=13866669999
	NSString* URLStr  = [NSString stringWithFormat:@"notifyAnimationListDone.action?mobile=%@",self.account];
	NSString* URLPath = [kMaikeSeverURL stringByAppendingPathComponent:URLStr];
	NSMutableURLRequest* urlRequest = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:URLPath]];
	[urlRequest setHTTPMethod:@"GET"];
	NSHTTPURLResponse* response = nil;
	NSData* responseData =	[NSURLConnection sendSynchronousRequest:urlRequest returningResponse:&response error:nil];
	[urlRequest		release];
	if ([response statusCode]==200&&[responseData length]>0)
	{
		//NSLog(@">>>notifyHaveGetAnimationList Done");
	}
}

#pragma mark - PKNetworkProtocol Delegate

- (void) network:(PKNetwork*)network responseResult:(id)result
{
	NSData* tmpData = (NSData*)result;
	BOOL validate = NO;
	if ([tmpData length]>0)
	{
		id  resultDict = [tmpData objectFromJSONData];
		if (resultDict&&[[resultDict allKeys] count]>0) 
		{
			validate = YES;
			id  result = [resultDict objectForKey:kURLResult];
			if (network.tag == kSynAddFrinedsRequest)
			{
		       if(result&&[result isKindOfClass:[NSArray class]])
				{
					
					[self saveRequestAddFriendsArray:result];
					if (delegate_&&[delegate_ respondsToSelector:@selector(PKServerSyn:requestAddFriends:error:)])
					{
						[delegate_ PKServerSyn:self requestAddFriends:result error:nil];
					}
				}
				else
				{
					if (delegate_&&[delegate_ respondsToSelector:@selector(PKServerSyn:requestAddFriends:error:)])
					{
						[delegate_ PKServerSyn:self requestAddFriends:nil error:nil];
					}
				}
			}
			else if(network.tag == kSynUpdateFrinedsInfo)
			{
				if(result&&[result isKindOfClass:[NSArray class]])
				{
					
					NSArray* array = [self updateFriendsInfo:result];
					if (delegate_&&[delegate_ respondsToSelector:@selector(PKServerSyn:updateFriendsInfo:error:)])
					{
						[delegate_ PKServerSyn:self updateFriendsInfo:array error:nil];
					}
				}
				else
				{
					if (delegate_&&[delegate_ respondsToSelector:@selector(PKServerSyn:updateFriendsInfo:error:)])
					{
						[delegate_ PKServerSyn:self updateFriendsInfo:nil error:nil];
					}
				}

			}
			else if(network.tag == kSetAddFriendsRequest)
			{
				isRuning_ = NO;
				isSuccess_ = YES;
				if(result&&[result isKindOfClass:[NSNumber class]]&&[result integerValue]!=0)
				{
					isCancel_ = YES;
					isSuccess_ = NO;
				}
			}
			else if(network.tag == ksynMyAnimationInfo)
			{
				if (result&&[result isKindOfClass:[NSArray class]]&&[result count]>0) 
				{
					self.animationArray = result;
					//下载新的动画
					[self downloadAnimationIfNeed];
					
					if (delegate_&&[delegate_ respondsToSelector:@selector(PKServerSyn:synMyAnimationInfo:error:)])
					{
						[delegate_ PKServerSyn:self synMyAnimationInfo:self.animationArray error:nil];
					}
				}
				else 
				{
					if (delegate_&&[delegate_ respondsToSelector:@selector(PKServerSyn:synMyAnimationInfo:error:)])
					{
						[delegate_ PKServerSyn:self synMyAnimationInfo:nil error:nil];
					}
				}
			}
			
		}
	}
	//错误处理
	if (!validate)
	{
		if (network.tag == kSynAddFrinedsRequest)
		{
			if (delegate_&&[delegate_ respondsToSelector:@selector(PKServerSyn:requestAddFriends:error:)])
			{
				[delegate_ PKServerSyn:self requestAddFriends:nil error:nil];
			}
		}
		else if(network.tag ==kSynUpdateFrinedsInfo)
		{
			if (delegate_&&[delegate_ respondsToSelector:@selector(PKServerSyn:updateFriendsInfo:error:)])
			{
				[delegate_ PKServerSyn:self updateFriendsInfo:nil error:nil];
			}
		}
		else if(network.tag == kSetAddFriendsRequest)
		{
			isRuning_ = NO;
			isCancel_ = YES;
		}
		else if (network.tag == ksynMyAnimationInfo)
		{
			if (delegate_&&[delegate_ respondsToSelector:@selector(PKServerSyn:synMyAnimationInfo:error:)])
			{
				[delegate_ PKServerSyn:self synMyAnimationInfo:nil error:nil];
			}
		}
	}
	
	
}

- (void) network:(PKNetwork *)network responseError:(PKNetWorkErrorCode)errorCode
{
	if (network.tag == kSynAddFrinedsRequest)
	{
		if (delegate_&&[delegate_ respondsToSelector:@selector(PKServerSyn:requestAddFriends:error:)])
		{
			[delegate_ PKServerSyn:self requestAddFriends:nil error:nil];
		}
	}
	else if(network.tag ==kSynUpdateFrinedsInfo)
	{
		if (delegate_&&[delegate_ respondsToSelector:@selector(PKServerSyn:updateFriendsInfo:error:)])
		{
			[delegate_ PKServerSyn:self updateFriendsInfo:nil error:nil];
		}
	}
	else if(network.tag == kSetAddFriendsRequest)
	{
		isRuning_ = NO;
		isCancel_ = YES;
	}
	else if (network.tag == ksynMyAnimationInfo)
	{
		if (delegate_&&[delegate_ respondsToSelector:@selector(PKServerSyn:synMyAnimationInfo:error:)])
		{
			[delegate_ PKServerSyn:self synMyAnimationInfo:nil error:nil];
		}
	}
	
}

@end
