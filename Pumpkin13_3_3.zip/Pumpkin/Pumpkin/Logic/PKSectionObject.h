//
//  PKSectionObject.h
//  Pumpkin
//
//  Created by lv on 4/15/12.
//  Copyright (c) 2012 XXXXX. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PKSectionObject : NSObject
{
	NSInteger sectionTag_;
	NSString* sectionTitle_;
	NSArray*  rowItemsArr_;		//row tag ,enum number 
	UIImage*  image_;
}
@property(nonatomic,retain)UIImage* image;
@property(nonatomic,retain)NSArray* rowItemsArr;

- (id)initWithSectionTag:(NSInteger)secTag title:(NSString*)title rowsArray:(NSArray*)array;
- (NSString*)titleOfSection;
- (NSInteger)tagOfSection;
- (NSInteger)numberOfRowsInSection;
- (id)rowItemAtIndex:(NSInteger)index;
@end
