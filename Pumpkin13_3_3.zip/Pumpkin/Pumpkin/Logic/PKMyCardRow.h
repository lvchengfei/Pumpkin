//
//  PKMyCardRow.h
//  Pumpkin
//
//  Created by lv on 6/27/12.
//  Copyright (c) 2012 XXX. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PKMyCardRow : NSObject
{
	NSString* title_;
	NSString* value_;
	NSInteger tag_;
	BOOL	  isValidate_;
}
@property(nonatomic,retain)NSString* title;
@property(nonatomic,retain)NSString* value;
@property(nonatomic,assign)NSInteger tag;
@property(nonatomic,assign)BOOL isValidate;

- (id)initWithTitle:(NSString*)title rowTag:(NSInteger)tag;
@end
