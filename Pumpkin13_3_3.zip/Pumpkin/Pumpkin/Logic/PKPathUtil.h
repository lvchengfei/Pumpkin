//
//  PKPathUtil.h
//  XXXXXIMLib
//
//  Created by lv on 2/27/12.
//  Copyright 2012 yunyi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PKPathUtil : NSObject {
    
}

#pragma mark - Directory path
+ (NSString*)documentRootPath;
+ (NSString*)appResourcePath;
+ (NSString*)ImageResourcePath;
+ (NSString*)commonImagePath;
+ (NSString*)contactImagePath;
+ (NSString*)dialAnimationPath;
+ (NSString*)dialAnimationArchiverPath;
+ (NSString*)myCardPath;
+ (NSString*)settingsPath;
+ (NSString*)contactPath;


@end
