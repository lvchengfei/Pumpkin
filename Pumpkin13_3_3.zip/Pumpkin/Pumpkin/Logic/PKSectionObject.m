//
//  PKSectionObject.m
//  Pumpkin
//
//  Created by lv on 4/15/12.
//  Copyright (c) 2012 XXXXX. All rights reserved.
//

#import "PKSectionObject.h"
#import "PKDefine.h"

@implementation PKSectionObject
@synthesize image = image_;
@synthesize rowItemsArr = rowItemsArr_;

- (id)initWithSectionTag:(NSInteger)secTag title:(NSString*)title rowsArray:(NSArray*)array
{
	self = [super init];
	if (self) {
		sectionTag_   = secTag;
		sectionTitle_ = title?[[NSString alloc] initWithString:title]:nil;
		rowItemsArr_  = array?[[NSArray alloc] initWithArray:array]:nil;
	}
	return self;
}

- (void)dealloc
{
	[sectionTitle_	release];
	[rowItemsArr_	release];
	[image_			release];
	[super dealloc];
}

- (NSString*)titleOfSection
{
	return sectionTitle_;
}

- (NSInteger)tagOfSection
{
	return sectionTag_;
}

- (NSInteger)numberOfRowsInSection
{
	NSInteger count = [rowItemsArr_ count];
	count = count==0?1:count;
	return count;
}

- (id)rowItemAtIndex:(NSInteger)index
{
	return  objectAtIndex(rowItemsArr_,index);
}

- (NSString *)description
{
	NSMutableString* desStr = [NSMutableString stringWithCapacity:0];
	[desStr appendFormat:@"|--------PKSectionObject %p----------|\n",self];
	[desStr appendFormat:@"|SectionTag  =%d\n",sectionTag_];
	[desStr appendFormat:@"|SectionTitle=%@\n",sectionTitle_];
	[desStr appendFormat:@"|------------------------------------|\n"];
	return desStr;
}

@end
