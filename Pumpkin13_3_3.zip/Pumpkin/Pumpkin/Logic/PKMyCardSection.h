//
//  PKMyCardSection.h
//  Pumpkin
//
//  Created by lv on 6/27/12.
//  Copyright (c) 2012 XXX. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PKSectionObject.h"




@interface PKMyCardSection : PKSectionObject

@end
