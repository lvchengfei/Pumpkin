//
//  PKDialSetAnimation.h
//  Pumpkin
//
//  Created by lv on 7/8/12.
//  Copyright (c) 2012 XXX. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PKAddMemToGroup.h"
#import "PKNetwork.h"

@class PKDialSetAnimation;
@protocol PKDialSetAnimationProtocol <NSObject>
@optional
- (void)animationSet:(PKDialSetAnimation*)animationSet uploadAnimationSet:(BOOL)isSuccess errorCode:(NSInteger)errCode;

@end

@interface PKDialSetAnimation : PKAddMemToGroup <PKNetworkProtocol>
{
	NSMutableDictionary*				animationDict_; //<某个动画设置的好友列表（NSArray）,某个动画的sn(NSString)>
	NSString*							sn_;
	PKNetwork*							netWorkEngine_;
	id <PKDialSetAnimationProtocol>		delegate_;
}
@property(nonatomic,assign) id <PKDialSetAnimationProtocol>	delegate;
@property(nonatomic,retain) NSString*	account;
@property(nonatomic,retain) NSString*	passWord;

- (void)updateCandidateFriendsAinmation:(NSString*)sn;
- (BOOL)saveSelectedPerson;

@end
