//
//  PKMyCardTemplate.m
//  Pumpkin
//
//  Created by lv on 7/1/12.
//  Copyright (c) 2012 XXX. All rights reserved.
//

#import "PKMyCardTemplate.h"
#import "PKDefine.h"
#import "PKJSONKit.h"
#import "PKUIConst.h"

@interface PKMyCardTemplate()
@property(nonatomic,retain) NSArray*	displayMyCardItems;
@property(nonatomic,retain) NSArray*	titleRectArray;
@property(nonatomic,retain) NSArray*	valueRectArray;
@property(nonatomic,retain) NSString*   templateNameNew;

- (void)initTemplateDisplayItem;
- (void)initTemplateDisplayItemRect;
@end

@implementation PKMyCardTemplate
@synthesize account  ;
@synthesize passWord ;
@synthesize delegate = delegate_;
@synthesize updateDelegate = updateDelegate_;
//@synthesize selTemplateName = selTemplateName_;
@synthesize displayMyCardItems = displayMyCardItems_;
@synthesize titleRectArray = titleRectArray_;
@synthesize valueRectArray = valueRectArray_;
@synthesize templateNameNew = templateNameNew_;

//- (id)initWithTemplateName:(NSString*)templateName
- (id)init
{
	self = [super init];
	if (self) 
	{
		netWorkEngine_ = [[PKNetwork alloc] init];
		netWorkEngine_.delegate = self;
	}
	return self;
}

- (void)dealloc
{
	[initTemplateName_		release];
	[selTemplateName_		release];
	[displayMyCardItems_	release];
	[titleRectArray_		release];
	[valueRectArray_		release];
	[netWorkEngine_			release];
	delegate_		= nil;
	updateDelegate_ = nil;
	self.account  = nil;
	self.passWord = nil;
	self.templateNameNew = nil;
	[super dealloc];
}

- (NSString *)selTemplateName
{
	return selTemplateName_;
}
- (void)setSelTemplateName:(NSString *)selTemplateName
{
	if (selTemplateName_!=selTemplateName && [selTemplateName length]>0) 
	{
		if (selTemplateName_==nil) 
		{
			initTemplateName_ = [[NSString alloc] initWithString:selTemplateName];
		}
		selTemplateName_ = [selTemplateName length]>0?[NSString stringWithString:selTemplateName]:nil;
		[self initTemplateDisplayItem];
		[self initTemplateDisplayItemRect];
	}

}

#pragma mark - Public Method

- (NSInteger)numberOfDisplayMyCardItems
{
	return [displayMyCardItems_ count];
}

- (NSString*)titleOfDisplayMyCardItems:(NSInteger)index
{
	NSNumber* row = objectAtIndex(displayMyCardItems_, index);
	NSInteger rowTag = [row integerValue];
	if (rowTag==kPKMyCardRowAvatar||rowTag==kPKMyCardRowName||rowTag==kPKMyCardRowCompany) 
	{
		return nil;
	}
	NSDictionary* titleDict = [PKUtils myCardAllItemsTitleDictionary];
	return [titleDict objectForKey:row];
}

- (UIFont*)valueFontOfDisplayMyCardItems:(NSInteger)index
{
	NSNumber* row = objectAtIndex(displayMyCardItems_, index);
	NSInteger rowTag = [row integerValue];
	if (rowTag==kPKMyCardRowName) 
	{
		return [UIFont systemFontOfSize:16];
	}
	else if(rowTag==kPKMyCardRowCompany) 
	{
		return 	[UIFont systemFontOfSize:14];
	}
	return 	[UIFont systemFontOfSize:12];

}

- (UIColor*)valueFontColorOfDisplayMyCardItems:(NSInteger)index
{
	return kMyCardValueFontColor;
}

- (UITextAlignment)valueTextAlignmentOfDisplayMyCardItems:(NSInteger)index
{
	UITextAlignment textAlignment = UITextAlignmentLeft;
	NSInteger templateIndex = [kDefaultTemplateArray indexOfObject:selTemplateName_];
	if (templateIndex==1||templateIndex==5) 
	{
		textAlignment = UITextAlignmentRight;
	}
	NSNumber* row = objectAtIndex(displayMyCardItems_, index);
	NSInteger rowTag = [row integerValue];
	switch (rowTag) 
	{
		case kPKMyCardRowName:
		case kPKMyCardRowCompany:
			return textAlignment;
		case kPKMyCardRowCellPhone:
		case kPKMyCardRowEmail:
		case kPKMyCardRowWebSite:
		case kPKMyCardRowCompanyAddress:
			return UITextAlignmentLeft;
			break;
		default:
			break;
	}
	return UITextAlignmentLeft;
}

- (id)valueOfDisplayMyCardItems:(NSInteger)index
{
	NSNumber* row = objectAtIndex(displayMyCardItems_, index);
	NSInteger rowTag = [row integerValue];
	if (delegate_&&[delegate_ respondsToSelector:@selector(valueOfMyCardRow:)])
	{
		return [delegate_ valueOfMyCardRow:rowTag];
	}
	return nil;
}

- (CGRect)titleRectOfDisplayMyCardItems:(NSInteger)index
{
	NSValue* value = objectAtIndex(titleRectArray_, index);
	return [value CGRectValue];
}

- (CGRect)valueRectOfDisplayMyCardItems:(NSInteger)index
{
	NSValue* value = objectAtIndex(valueRectArray_, index);
	return [value CGRectValue];
}

- (PKMyCardRowItem)tagOfDisplayMyCardItems:(NSInteger)index
{
	NSNumber* row = objectAtIndex(displayMyCardItems_, index);
	return [row integerValue];
}


- (void)updateWithTemplateName:(NSString*)templateName
{
	if ([templateName length]>0)
	{
		self.selTemplateName = templateName;
		[self initTemplateDisplayItem];
		[self initTemplateDisplayItemRect];
	}
}

- (BOOL)saveSelectedTemplate
{
	BOOL result = NO;
	if ([initTemplateName_ isEqualToString:selTemplateName_]==NO)
	{
		if ([PKUtils isNetWorkAvailable])
		{
			//http://115.238.43.29/maike/setCardTemplate.action?ownerMobile=13866669999&sn=cardtemplate1
			NSString* template = [selTemplateName_ stringByDeletingPathExtension];
			template  = [template substringFromIndex:[template length]-1];
			NSString* templateIndex = [NSString stringWithFormat:@"ct%d",[template integerValue]];
			
			NSString* URLStr  = [NSString stringWithFormat:@"ownerMobile=%@&sn=%@",self.account,templateIndex];
			NSData* bodyData = [URLStr dataUsingEncoding:NSUTF8StringEncoding];
			NSString* URLPath = [kMaikeSeverURL stringByAppendingPathComponent:@"setCardTemplate.action"];
			NSMutableURLRequest* urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:URLPath]];
			[urlRequest setHTTPMethod:@"POST"];
			[urlRequest setHTTPBody:bodyData];
			
			[netWorkEngine_ startConnectionWithURLRequest:urlRequest synchronise:NO];
			result = YES;
		}
	}
	else
	{
		PKALERTVIEW(nil, @"没有更新内容！", nil,@"确定",nil,nil);
	}
	return result;
}

#pragma mark - Private Method

- (void)initTemplateDisplayItem
{
	NSArray* defaultTemplateArr = kDefaultTemplateArray;
	NSInteger templateIndex = [defaultTemplateArr indexOfObject:selTemplateName_];
	switch (templateIndex)
	{
		case 0:
		case 1:
		case 2:		
		case 3:
		case 4:
		case 5:
		case 6:
		{
			self.displayMyCardItems = [NSArray arrayWithObjects:[NSNumber numberWithInteger:kPKMyCardRowAvatar],[NSNumber numberWithInteger:kPKMyCardRowName],[NSNumber numberWithInteger:kPKMyCardRowCompany],[NSNumber numberWithInteger:kPKMyCardRowCellPhone],[NSNumber numberWithInteger:kPKMyCardRowEmail],[NSNumber numberWithInteger:kPKMyCardRowWebSite],[NSNumber numberWithInteger:kPKMyCardRowCompanyAddress], nil];
		}
			break;
			
		default:
			break;
	}
}

- (void)initTemplateDisplayItemRect
{
	NSArray* defaultTemplateArr = kDefaultTemplateArray;
	NSInteger templateIndex = [defaultTemplateArr indexOfObject:selTemplateName_];
	NSInteger originX = 110 , originY = 120 , titleW=30,titleH=16 , valueW=150,valueH=16;
	NSInteger avatarX = 220 , avatarY = 10 , avatarW = 70 , avatarH = 70;
	NSInteger offSet =12, nameW = 120 , nameH = 30 , nameX = avatarX-nameW-offSet, nameY = 20;
	NSInteger campanyW = 220, companyH =valueH, companyX = avatarX-campanyW-offSet;
	CGRect rectT1=CGRectZero,rectT2=CGRectZero,rectT3=CGRectZero,rectT4=CGRectZero;
	CGRect rectV1=CGRectZero,rectV2=CGRectZero,rectV3=CGRectZero,rectV4=CGRectZero,rectV5=CGRectZero,rectV6=CGRectZero,rectV7=CGRectZero;
	switch (templateIndex)
	{
		case 0:
		case 3:
		{
			originX = 20;
			avatarX = 15;
			avatarY = 20;
			nameY = 30;
			nameX =  avatarX+avatarW+offSet;
			companyX = nameX;
		}
			break;
		case 1:
			break;
		case 2:	
		case 4:
		{
			originX = 15;
			originY = 130;
			avatarX = 15;
			nameX = 15;
			nameY = 2;
			companyX = 15;
			avatarY = nameY+nameH+companyH+2;
		}
			break;
		case 5:
		{
			avatarY = 20;
		}
			break;
		default:
		break;
	}
	
	rectT1 = CGRectMake(originX, originY, titleW, titleH);
	rectT2 = CGRectMake(originX, rectT1.origin.y+rectT1.size.height, titleW, titleH);
	rectT3 = CGRectMake(originX, rectT2.origin.y+rectT2.size.height, titleW, titleH);
	rectT4 = CGRectMake(originX, rectT3.origin.y+rectT3.size.height, titleW, titleH);
	
	rectV1 = CGRectMake(avatarX, avatarY, avatarW, avatarH);//avatar 80x80
	rectV2 = CGRectMake(nameX, nameY, nameW, nameH);//name
	rectV3 = CGRectMake(companyX, rectV2.origin.y+rectV2.size.height, campanyW, companyH);//company
	
	rectV4 = CGRectMake(originX+titleW, originY, valueW, valueH);
	rectV5 = CGRectMake(originX+titleW, rectT2.origin.y, valueW, valueH);
	rectV6 = CGRectMake(originX+titleW, rectT3.origin.y, valueW, valueH);
	rectV7 = CGRectMake(originX+titleW, rectT4.origin.y, valueW, valueH);
	
	//titleRectArray_、valueRectArray_中的元素顺序要和displayMyCardItems_中元素一致
	
	self.titleRectArray = [NSArray arrayWithObjects:[NSValue valueWithCGRect:CGRectZero],[NSValue valueWithCGRect:CGRectZero],[NSValue valueWithCGRect:CGRectZero],[NSValue valueWithCGRect:rectT1],[NSValue valueWithCGRect:rectT2],[NSValue valueWithCGRect:rectT3],[NSValue valueWithCGRect:rectT4], nil] ;
	
	self.valueRectArray = [NSArray arrayWithObjects:[NSValue valueWithCGRect:rectV1],[NSValue valueWithCGRect:rectV2],[NSValue valueWithCGRect:rectV3],[NSValue valueWithCGRect:rectV4],[NSValue valueWithCGRect:rectV5],[NSValue valueWithCGRect:rectV6],[NSValue valueWithCGRect:rectV7], nil] ;
}


#pragma mark - PKNetworkProtocol Delegate

- (void) network:(PKNetwork*)network responseResult:(id)result
{
	NSData* tmpData = (NSData*)result;
	id  resultDict = [tmpData objectFromJSONData];
	if (resultDict&&[[resultDict allKeys] count]>0) 
	{
		id  result = [resultDict objectForKey:kURLResult];
		if(result&&[result isKindOfClass:[NSNumber class]]&&[result integerValue]==1) 
		{
			if (updateDelegate_&&[updateDelegate_ respondsToSelector:@selector(cardTemplate:updateTemplate:errorCode:)]) 
			{
				[updateDelegate_  cardTemplate:self updateTemplate:YES errorCode:0];		
			}	
			//NSLog(@">>>update template result=%d",[result integerValue]);
			
		}
		else 
		{
			NSInteger errCode = -1;
			errCode = [result isKindOfClass:[NSNumber class]]?[result integerValue]:-1;
			if (updateDelegate_&&[updateDelegate_ respondsToSelector:@selector(cardTemplate:updateTemplate:errorCode:)]) 
			{
				[updateDelegate_  cardTemplate:self updateTemplate:NO errorCode:errCode];		
			}
			//NSLog(@">>>>update template  error = %d!!!",errCode);
		}
	}
	
}

- (void) network:(PKNetwork *)network responseError:(PKNetWorkErrorCode)errorCode
{
	//NSLog(@">>>update template responseError");
	if (updateDelegate_&&[updateDelegate_ respondsToSelector:@selector(cardTemplate:updateTemplate:errorCode:)]) 
	{
		[updateDelegate_  cardTemplate:self updateTemplate:NO errorCode:kNetWorkErr];		
	}
}

@end
