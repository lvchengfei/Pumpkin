//
//  PKAccountManager.m
//  Pumpkin
//
//  Created by lv on 6/14/12.
//  Copyright (c) 2012 XXXXX. All rights reserved.
//

#import "PKAccountManager.h"
#import "PKConst.h"
#import "PKJSONKit.h"
#import "PKLogicEngine.h"
#import "PKMyCardEngine.h"
#import "PKPathUtil.h"

typedef  enum
{
	PKGetAuthCode,
	PKLogIn,
	PKRegister,
	PKChangeAccount,
	PKChangePassword,
	PKRemoveAccount,
	PKGetPersonInfo,
}PKAccountManageType;

const NSInteger netWorkErr = 0x10;

@interface PKAccountManager ()
@property(nonatomic,assign) PKAccountManageType	type;
@property(nonatomic,retain) NSString*   tmpInfo;

- (void)handlerDelegateMethods:(BOOL)isSuccess errorCode:(NSInteger)errCode;
- (BOOL) logicSuccessCode:(NSInteger)type;
- (void)setAccountInfo;
- (void)resetAccountInfo;
- (void)getPersonInfoFromSever;
- (void)getAvatarImage:(NSString*)avatarName;
- (void)savePersonInfo:(NSArray*)array;


@end

@implementation PKAccountManager
//@synthesize delegate = delegate_;
@synthesize isShowPassWord = isShowPassWord_;
@synthesize type = type_;
@synthesize account  = account_;
@synthesize passWord = passWord_;
@synthesize tmpInfo = tmpInfo_;


- (id)init
{
	self = [super init];
	if (self) {
		netWorkEngine_ = [[PKNetwork alloc] init];
		netWorkEngine_.delegate = self;
		NSUserDefaults* userDefault = [NSUserDefaults standardUserDefaults];
		self.account  = [userDefault objectForKey:kAccountInfo];
		self.passWord = [userDefault objectForKey:kPassWordInfo];
	}
	return self;
}

- (void)dealloc
{
	[netWorkEngine_				cancelConnection];
	[netWorkEngine_				release];
	delegate_     = nil;
	self.account  = nil;
	self.passWord = nil;
	self.tmpInfo  = nil;
	[super dealloc];
}

#pragma mark - Public Methods

- (void)registerWithAccount:(NSString*)account password:(NSString*)password auth:(NSString*)authCode
{
	type_ = PKRegister;
	self.account  = account;
	self.passWord = password;
	/*
	NSString* URLStr  = [NSString stringWithFormat:@"register.action?mobile=%@&password=%@&verCode=%@&clientType=%d",account,password,authCode,kDeviceType];
	NSString* URLPath = [kMaikeSeverURL stringByAppendingPathComponent:URLStr];
	NSURLRequest* urlRequest = [[NSURLRequest alloc] initWithURL:[NSURL URLWithString:URLPath]];
	*/
	NSData* token = [PKLogicEngine sharedInstance].pushToken;
	NSString* tokenStr = [NSString stringWithFormat:@"%@",token];
	//过滤 <>括号
	if ([tokenStr length]>2) 
	{
		tokenStr = [tokenStr substringWithRange:NSMakeRange(1, [tokenStr length]-2)];
	}
	NSString* URLStr  = [NSString stringWithFormat:@"mobile=%@&password=%@&verCode=%@&clientType=%d&imei=%@",account,password,authCode,kDeviceType,tokenStr];
	NSData* bodyData = [URLStr dataUsingEncoding:NSUTF8StringEncoding];
	NSString* URLPath = [kMaikeSeverURL stringByAppendingPathComponent:@"register.action"];
	NSMutableURLRequest* urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:URLPath]];
	[urlRequest setHTTPMethod:@"POST"];
	[urlRequest setHTTPBody:bodyData];
	[netWorkEngine_ startConnectionWithURLRequest:urlRequest synchronise:NO];
}

- (void)logInWithAccount:(NSString*)account password:(NSString*)password
{
	type_ = PKLogIn;
	self.account  = account;
	self.passWord = password;
	/*
	NSString* URLStr  = [NSString stringWithFormat:@"login.action?mobile=%@&password=%@",account,password];
	NSString* URLPath = [kMaikeSeverURL stringByAppendingPathComponent:URLStr];
	NSURLRequest* urlRequest = [[NSURLRequest alloc] initWithURL:[NSURL URLWithString:URLPath]];
	*/
	NSData* token = [PKLogicEngine sharedInstance].pushToken;
	NSString* tokenStr = [NSString stringWithFormat:@"%@",token];
	//过滤 <>括号
	if ([tokenStr length]>2) 
	{
		tokenStr = [tokenStr substringWithRange:NSMakeRange(1, [tokenStr length]-2)];
	}
	//NSLog(@">>>token=%@ tokenStr=%@",token,tokenStr);
	NSString* URLStr  = [NSString stringWithFormat:@"mobile=%@&password=%@&clientType=%d&imei=%@",account,password,kDeviceType,tokenStr];
	NSData* bodyData = [URLStr dataUsingEncoding:NSUTF8StringEncoding];
	NSString* URLPath = [kMaikeSeverURL stringByAppendingPathComponent:@"login.action"];
	NSMutableURLRequest* urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:URLPath]];
	[urlRequest setHTTPMethod:@"POST"];
	[urlRequest setHTTPBody:bodyData];
	[netWorkEngine_ startConnectionWithURLRequest:urlRequest synchronise:NO];
	
}


- (void)getAuthorizedCode:(NSString*)account
{
	type_ = PKGetAuthCode;
	//NSString* URLStr  = [NSString stringWithFormat:@"getVerCode.action?mobile=%@",account];
	//NSString* URLPath = [kMaikeSeverURL stringByAppendingPathComponent:URLStr];
	//NSURLRequest* urlRequest = [[NSURLRequest alloc] initWithURL:[NSURL URLWithString:URLPath]];
	NSString* URLStr  = [NSString stringWithFormat:@"mobile=%@",account];
	NSData* bodyData = [URLStr dataUsingEncoding:NSUTF8StringEncoding];
	NSString* URLPath = [kMaikeSeverURL stringByAppendingPathComponent:@"getVerCode.action"];
	NSMutableURLRequest* urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:URLPath]];
	[urlRequest setHTTPMethod:@"POST"];
	[urlRequest setHTTPBody:bodyData];
	[netWorkEngine_ startConnectionWithURLRequest:urlRequest synchronise:NO];
}

- (BOOL)changeAccount:(NSString*)oldAccount newAccount:(NSString*)newAccount
{
	type_ = PKChangeAccount;
	self.tmpInfo = newAccount;
	if (self.passWord==nil||[self.account isEqualToString:oldAccount]==NO)
	{
		if(flags_.changeAccountErrCode)
			[delegate_ accountManager:self changeAccount:NO errorCode:PKOldAccountErr];
		return NO;
	}
	/*
	 NSString* URLStr  = [NSString stringWithFormat:@"login.action?mobile=%@&password=%@",account,password];
	 NSString* URLPath = [kMaikeSeverURL stringByAppendingPathComponent:URLStr];
	 NSURLRequest* urlRequest = [[NSURLRequest alloc] initWithURL:[NSURL URLWithString:URLPath]];
	 */
	NSString* URLStr  = [NSString stringWithFormat:@"mobile=%@&password=%@&newMobile=%@",oldAccount,self.passWord,newAccount];
	NSData* bodyData = [URLStr dataUsingEncoding:NSUTF8StringEncoding];
	NSString* URLPath = [kMaikeSeverURL stringByAppendingPathComponent:@"changeMobileNum.action"];
	NSMutableURLRequest* urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:URLPath]];
	[urlRequest setHTTPMethod:@"POST"];
	[urlRequest setHTTPBody:bodyData];
	[netWorkEngine_ startConnectionWithURLRequest:urlRequest synchronise:NO];
	
	return YES;
}

- (BOOL)changePassword:(NSString*)oldPassword newPassword:(NSString*)newPassword
{
	type_ = PKChangePassword;
	self.tmpInfo = newPassword;
	if (self.account==nil||[self.passWord isEqualToString:oldPassword]==NO)
	{
		if(flags_.changePasswordErrCode)
			[delegate_ accountManager:self changePassword:NO errorCode:PKOldPasswordErr];
		return NO;
	}
	/*
	 NSString* URLStr  = [NSString stringWithFormat:@"login.action?mobile=%@&password=%@",account,password];
	 NSString* URLPath = [kMaikeSeverURL stringByAppendingPathComponent:URLStr];
	 NSURLRequest* urlRequest = [[NSURLRequest alloc] initWithURL:[NSURL URLWithString:URLPath]];
	 */
	NSString* URLStr  = [NSString stringWithFormat:@"mobile=%@&oriPassword=%@&newPassword=%@",self.account,oldPassword,newPassword];
	NSData* bodyData = [URLStr dataUsingEncoding:NSUTF8StringEncoding];
	NSString* URLPath = [kMaikeSeverURL stringByAppendingPathComponent:@"changePassword.action"];
	NSMutableURLRequest* urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:URLPath]];
	[urlRequest setHTTPMethod:@"POST"];
	[urlRequest setHTTPBody:bodyData];
	[netWorkEngine_ startConnectionWithURLRequest:urlRequest synchronise:NO];
	return YES;
}



- (BOOL)removeUserWithAccount:(NSString*)account password:(NSString*)password
{
	type_ = PKRemoveAccount;
	//NSLog(@"%@ %@",self.account,self.passWord);
	if ([self.account isEqualToString:account]==NO||[self.passWord isEqualToString:password]==NO)
	{
		if(flags_.changePasswordErrCode)
			[delegate_ accountManager:self removeAccount:NO errorCode:PKRemoveAccountErr];
		return NO;
	}
	/*
	 NSString* URLStr  = [NSString stringWithFormat:@"login.action?mobile=%@&password=%@",account,password];
	 NSString* URLPath = [kMaikeSeverURL stringByAppendingPathComponent:URLStr];
	 NSURLRequest* urlRequest = [[NSURLRequest alloc] initWithURL:[NSURL URLWithString:URLPath]];
	 */
	NSString* URLStr  = [NSString stringWithFormat:@"mobile=%@&password=%@",self.account,self.passWord];
	NSData* bodyData = [URLStr dataUsingEncoding:NSUTF8StringEncoding];
	NSString* URLPath = [kMaikeSeverURL stringByAppendingPathComponent:@"removeUser.action"];
	NSMutableURLRequest* urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:URLPath]];
	[urlRequest setHTTPMethod:@"POST"];
	[urlRequest setHTTPBody:bodyData];
	[netWorkEngine_ startConnectionWithURLRequest:urlRequest synchronise:NO];
	return YES;
}

- (id<PKAccountManagerProtocol>)delegate
{
	return delegate_;
}

- (void)setDelegate:(id<PKAccountManagerProtocol>)delegate
{
	if (delegate_!=delegate)
	{
		delegate_ = delegate;
		flags_.logInErrorCode		= [delegate_ respondsToSelector:@selector(accountManager:logInAccount:errorCode:)];
		flags_.getAuthCodeErrCode	= [delegate_ respondsToSelector:@selector(accountManager:getAuthCode:errorCode:)];
		flags_.registerErrorCode	= [delegate_ respondsToSelector:@selector(accountManager:registerAccount:errorCode:)];
		flags_.changeAccountErrCode = [delegate_ respondsToSelector:@selector(accountManager:changeAccount:errorCode:)];
		flags_.changePasswordErrCode= [delegate_ respondsToSelector:@selector(accountManager:changePassword:errorCode:)];
		flags_.removeAccountErrCode = [delegate_ respondsToSelector:@selector(accountManager:removeAccount:errorCode:)];
		
	}
}

- (void)resetDefaultsIfNeed
{	
    NSUserDefaults * userDefault = [NSUserDefaults standardUserDefaults];
	NSString* oldAccount = [userDefault objectForKey:koldAccountInfo];
	//NSLog(@">>>>resetDefaultsIfNeed oldAccount=%@  %@",oldAccount,self.account);

	if ([oldAccount length]>0)
	{
		if ([self.account isEqualToString:oldAccount]==NO)
		{
			NSDictionary* dict = [userDefault dictionaryRepresentation];
			NSArray* allKeys = [dict allKeys];
			for (id key in allKeys) 
			{
				//NSLog(@">>>key=%@",key);
				[userDefault removeObjectForKey:key];
			}	
			[userDefault setBool:YES forKey:kCheckShouldReloadPersonInfo];	
		}
	}
    [userDefault synchronize];
}

#pragma mark - Private Method

- (BOOL) logicSuccessCode:(NSInteger)type
{
	BOOL resultFlag = NO;
	NSInteger result = -1;
	switch (type_) {
		case PKRegister:
		case PKChangeAccount:
			result = 2;
			break;
		case PKLogIn:
		{
			//type >0 登录时 返回大于1表示成功 张三
			//返回值说明：30+clientType或者50+clientType。android版本为31或者51, iphone版本为32或者52。31和32表示普及版，51和52表示vip版本。
			if (type>0)
			{
				result = type;
			}
		}
			break;
		case PKChangePassword:
		case PKRemoveAccount:
			result = 1;
			break;
		case PKGetAuthCode:
			result = 0;
			break;
			
		default:
			break;
	}
	resultFlag = (result==type);
	return resultFlag;
}

- (void)setAccountInfo
{
	NSUserDefaults* userDefault = [NSUserDefaults standardUserDefaults];
	[userDefault setBool:YES			 forKey:kisHaveRegisterAccount];
	[userDefault setObject:self.account  forKey:kAccountInfo];
	[userDefault setObject:self.passWord forKey:kPassWordInfo];
	[userDefault synchronize];
}

- (void)resetAccountInfo
{
	NSUserDefaults* userDefault = [NSUserDefaults standardUserDefaults];
	[userDefault setBool:NO			 forKey:kisHaveRegisterAccount];
	[userDefault removeObjectForKey:kAccountInfo];
	[userDefault removeObjectForKey:kPassWordInfo];
	[userDefault synchronize];
}

//只有在第一次正常登录后才会调用此借口
- (void)getPersonInfoFromSever
{
	type_ = PKGetPersonInfo;
	NSString* URLStr  = [NSString stringWithFormat:@"ownerMobile=%@&specificMobile=%@",self.account,self.account];
	NSData* bodyData = [URLStr dataUsingEncoding:NSUTF8StringEncoding];
	NSString* URLPath = [kMaikeSeverURL stringByAppendingPathComponent:@"getSpecificUserInfo.action"];
	NSMutableURLRequest* urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:URLPath]];
	[urlRequest setHTTPMethod:@"POST"];
	[urlRequest setHTTPBody:bodyData];
	[netWorkEngine_ startConnectionWithURLRequest:urlRequest synchronise:NO];
}

- (void)getAvatarImage:(NSString*)avatarName
{
	NSString* URLPath = [kMaikeSeverDownloadURL stringByAppendingPathComponent:@"/avarta/"];
	URLPath = [URLPath stringByAppendingPathComponent:avatarName];
	
	NSMutableURLRequest* urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:URLPath]];
	[urlRequest setHTTPMethod:@"GET"];
	NSHTTPURLResponse* response = nil;
	NSData* responseData =	[NSURLConnection sendSynchronousRequest:urlRequest returningResponse:&response error:nil];
	if ([response statusCode]==200&&[responseData length]>0)
	{
		UIImage* image = [[UIImage alloc] initWithData:responseData];
		[PKUtils saveAvatarImage:image];
		[image	release];
	}
}

- (void)savePersonInfo:(NSArray*)array
{
	NSUserDefaults* userDefault = [NSUserDefaults standardUserDefaults];
	NSDictionary* map1Dict = [PKUtils myCardAllItemsTitleDictionary];	
	NSDictionary* map2Dict = [PKUtils myCardAllPostKeyToItemsDictionary];

	for (NSDictionary* dict in array)
	{
		//[[PKLogicEngine sharedInstance] getBusinessInstance:@""]
		NSArray* allKey = [dict allKeys];
		
		//NSLog(@">>allKey=%@",allKey);
		for (NSString* key  in allKey)
		{
			if ([key isEqualToString:@"ngAvatar"])
			{
				NSDictionary* value = [dict objectForKey:key];
				if (value&&[value isKindOfClass:[NSDictionary class]])
				{
					NSString* avatarName = [ value objectForKey:@"path"];
					[avatarName_	release];
					avatarName_ = [avatarName length]>0?[avatarName retain]:nil;
					[self  getAvatarImage:(NSString*)avatarName];
					//NSLog(@">>>avatarName_=%@",avatarName_);
				}
			}
			else if([key isEqualToString:@"ngCardTemplate"])
			{
				NSDictionary* value = [dict objectForKey:key];
				if (value&&[value isKindOfClass:[NSDictionary class]])
				{
					NSString* templateName = [ value objectForKey:@"path"];
					if ([kDefaultTemplateArray indexOfObject:templateName]!=NSNotFound) 
					{
						NSUserDefaults* userDefault = [NSUserDefaults standardUserDefaults];
						[userDefault setObject:templateName forKey:kMyCardTemplateName];
						[userDefault synchronize];
						//NSLog(@">>>template=%@",templateName);
					}
				}
			}
			else if([key isEqualToString:@"ims"])
			{
				NSArray* value = [dict objectForKey:key];
				if (value&&[value isKindOfClass:[NSArray class]])
				{
					for (NSDictionary* dict in value)
					{
						NSString* imsType  = [dict objectForKey:@"imType"];
						NSString* imsValue = [dict objectForKey:@"imAddr"];
						
						NSNumber* itemKey = [map2Dict objectForKey:imsType];
						NSString* itemKey1 = [map1Dict objectForKey:itemKey];
						if ([imsValue length]>0&&[itemKey1 length]>0)
						{
							[userDefault setObject:imsValue forKey:itemKey1];
						}
						//NSLog(@">>>imsType=%@,value=%@",imsType,imsValue);
					}
				}
			}
			else
			{
				id value = [dict objectForKey:key];
				if (value&&[value isKindOfClass:[NSString class]]&&[value length]>0) 
				{
					NSNumber* itemKey = [map2Dict objectForKey:key];
					NSString* itemKey1 = [map1Dict objectForKey:itemKey];
					if ([itemKey1 length]>0)
					{
						[userDefault setObject:value forKey:itemKey1];
					}
					//NSLog(@">>>key=%@,value=%@,key1=%@,key2=%@",key,[dict objectForKey:key],itemKey,itemKey1);
				}
			}
			
		}
	}
	[userDefault synchronize];
}

#pragma mark - Delegate Handler

- (void)handlerDelegateMethods:(BOOL)isSuccess errorCode:(NSInteger)errCode
{
	switch (type_) {
		case PKRegister:
		{
			if (flags_.registerErrorCode) 
			{
				if (isSuccess)
				{
					[self resetDefaultsIfNeed];
					[self setAccountInfo];
					[delegate_ accountManager:self registerAccount:YES errorCode:PKNoneErr];
				}
				else 
				{
					PKAccountErrorCode code = errCode==0?PKAuthCodeErr:PKHaveRegisterErr;
					code = errCode==netWorkErr?PKNetworkErr:code;
					[delegate_ accountManager:self registerAccount:NO errorCode:code];
				}
			}
		}
			break;
		case PKGetAuthCode:
		{
			if (flags_.getAuthCodeErrCode) 
			{
				if (isSuccess)
				{[delegate_ accountManager:self getAuthCode:YES errorCode:PKNoneErr];}
				else 
				{
					PKAccountErrorCode code = errCode==netWorkErr?PKNetworkErr:PKAuthCodeErr;
					[delegate_ accountManager:self getAuthCode:NO errorCode:code];
				}
			}
		}
			break;
		case PKLogIn:
		{
			if (flags_.logInErrorCode) 
			{
				if (isSuccess) 
				{
					//只有在第一次正常登录后才会调用此借口
					[self getPersonInfoFromSever];
				}
				else 
				{
					PKAccountErrorCode code = errCode==netWorkErr?PKNetworkErr:PKLogInErr;
					[delegate_ accountManager:self logInAccount:NO errorCode:code];
				}
			}
		}
			break;
		case PKGetPersonInfo:
		{
			if (flags_.logInErrorCode) 
			{
				[self resetDefaultsIfNeed];
				[self setAccountInfo];
				[[NSUserDefaults standardUserDefaults] setBool:YES forKey:kCheckShouldReloadPersonInfo];
				[delegate_ accountManager:self logInAccount:YES errorCode:0];
				/*
				if (isSuccess) 
				{
					[self resetDefaultsIfNeed];
					[self setAccountInfo];
					[[NSUserDefaults standardUserDefaults] setBool:YES forKey:kCheckShouldReloadPersonInfo];
					[delegate_ accountManager:self logInAccount:YES errorCode:0];
				}
				else 
				{
					PKAccountErrorCode code = errCode==netWorkErr?PKNetworkErr:PKLogInErr;
					[delegate_ accountManager:self logInAccount:NO errorCode:code];
				}*/
			}
		}
			break;
		case PKChangeAccount:
		{
			if (flags_.changeAccountErrCode) 
			{
				if (isSuccess) 
				{
					[delegate_ accountManager:self changeAccount:YES errorCode:PKNoneErr];
					self.account = self.tmpInfo;
					[self setAccountInfo];
				}
				else 
				{
					PKAccountErrorCode code = PKChangeAccountErr;
					code = errCode==netWorkErr?PKNetworkErr:code;
					code = errCode==1?PKHaveRegisterErr:code;
					[delegate_ accountManager:self changeAccount:NO errorCode:code];
				}
			}
		}
			break;
		case PKChangePassword:
		{
			if (flags_.changePasswordErrCode) 
			{
				if (isSuccess) 
				{
					[delegate_ accountManager:self changePassword:YES errorCode:PKNoneErr];
					self.passWord = self.tmpInfo;
					[self setAccountInfo];
					
				}
				else 
				{
					PKAccountErrorCode code = errCode==netWorkErr?PKNetworkErr:PKOldPasswordErr;
					[delegate_ accountManager:self changePassword:NO errorCode:code];
				}
			}
		}
			break;
		case PKRemoveAccount:
		{
			if (flags_.removeAccountErrCode) 
			{
				if (isSuccess) 
				{
					[self resetAccountInfo];
					[delegate_ accountManager:self removeAccount:YES errorCode:PKNoneErr];
				}
				else 
				{
					PKAccountErrorCode code = errCode==netWorkErr?PKNetworkErr:PKRemoveAccountErr;
					[delegate_ accountManager:self removeAccount:NO errorCode:code];
				}
			}
		}
			break;
		default:
			break;
	}
}

#pragma mark - PKNetworkProtocol Delegate

- (void) network:(PKNetwork*)network responseResult:(id)result
{
	NSData* tmpData = (NSData*)result;
	id  resultDict = [tmpData objectFromJSONData];
	if (resultDict&&[[resultDict allKeys] count]>0) 
	{
		id  result = [resultDict objectForKey:kURLResult];
		if(result&&[result isKindOfClass:[NSNumber class]]&&[self logicSuccessCode:[result integerValue]]) 
		{
			[self handlerDelegateMethods:YES errorCode:0];			
		}
		else 
		{
			if (type_==PKGetPersonInfo&&[result isKindOfClass:[NSArray class]])
			{
				[self savePersonInfo:result];
				[self handlerDelegateMethods:YES errorCode:0];			
			}
			else
			{
				NSInteger errCode = -1;
				errCode = [result isKindOfClass:[NSNumber class]]?[result integerValue]:-1;
				[self handlerDelegateMethods:NO errorCode:errCode];
			}
		}
	}
	
}

- (void) network:(PKNetwork *)network responseError:(PKNetWorkErrorCode)errorCode
{
	[self handlerDelegateMethods:NO errorCode:netWorkErr];
}


@end
