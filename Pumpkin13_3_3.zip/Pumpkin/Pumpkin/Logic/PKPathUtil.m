//
//  PKPathUtil.m
//  XXXXXIMLib
//
//  Created by lv on 2/27/12.
//  Copyright 2012 yunyi. All rights reserved.
//

#import "PKPathUtil.h"

@interface PKPathUtil() 
+ (NSString*)appPreferencesRootPath;
+ (NSString*)XXXXXIMSettingsAppRootPath;
+ (void)checkShouldMakeDirectory:(NSString*)fullPath;
@end

@implementation PKPathUtil


#pragma mark - Private Method



+ (NSString*)appPreferencesRootPath
{
#ifdef __API_HOOK__
		return  kAppPreferencesRootPath;
#else
		NSString* LibraryPath = [NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSUserDomainMask, YES) objectAtIndex:0];
		NSString* preferencePath = [LibraryPath stringByAppendingPathComponent:@"Preferences"];
		return preferencePath;
#endif
}

+ (NSString*)XXXXXIMSettingsAppRootPath
{
#ifdef __API_HOOK__
	return kXXXXXIMSettingAppRootPath;
#else
	return [NSHomeDirectory() stringByAppendingPathComponent:@"XXXXXIMSettings.app"];
#endif
}

+ (void)checkShouldMakeDirectory:(NSString*)fullPath
{
	//目录不存在则创建
	if (![[NSFileManager defaultManager] fileExistsAtPath:fullPath])
	{
		[[NSFileManager defaultManager] createDirectoryAtPath:fullPath withIntermediateDirectories:YES attributes:nil error:nil];
	}
}




#pragma mark - Public Method 

+ (NSString*)documentRootPath
{
	static NSString* documentPath = nil;
	if (documentPath==nil)
	{
		//documentPath = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
		documentPath = [[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0] retain];
	}
	return documentPath;
}

+ (NSString*)appResourcePath
{
	NSString* path = [[NSBundle mainBundle] resourcePath];
	return path;
}

+ (NSString*)ImageResourcePath
{
	NSString* path = nil;
	if (path==nil) {
		path = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"Image"];
	}
	return path;
}

+ (NSString*)commonImagePath
{
	NSString* path = [[self appResourcePath] stringByAppendingPathComponent:@"Image/Common/"];
	return path;
}

+ (NSString*)contactImagePath
{
	NSString* path = [[self appResourcePath] stringByAppendingPathComponent:@"Image/Contact/"];
	return path;
}

+ (NSString*)dialAnimationPath
{
	NSString* documentPath = [self documentRootPath];
	NSString* animationPath = [documentPath stringByAppendingPathComponent:@"dailAnimation/"];
	return animationPath;
}

+ (NSString*)settingsPath
{
	NSString* documentPath = [self documentRootPath];
	NSString* settingsPath = [documentPath stringByAppendingPathComponent:@"settings/"];
	[PKPathUtil checkShouldMakeDirectory:settingsPath];
	return settingsPath;
}

+ (NSString*)dialAnimationArchiverPath
{
	return [[self dialAnimationPath] stringByAppendingPathComponent:@"dailAnimationArichiver"];
}

+(NSString*)myCardPath
{
	NSString* myCardPath  = [[self documentRootPath] stringByAppendingPathComponent:@"MyCard"];
	[self checkShouldMakeDirectory:myCardPath];
	return myCardPath;
}

+(NSString*)contactPath
{
	static NSString* path = nil;
	static dispatch_once_t onceToken;
	dispatch_once(&onceToken, ^{
		path =  [[[self documentRootPath] stringByAppendingPathComponent:@"Contact/"] retain];
		[self checkShouldMakeDirectory:path];
	});
	return path;
}

@end
