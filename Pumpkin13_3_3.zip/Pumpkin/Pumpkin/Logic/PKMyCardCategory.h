//
//  PKMyCardCategory.h
//  Pumpkin
//
//  Created by lv on 3/17/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef	 enum{
	kPKMyCardGeneralInfo,
	kPKMyCardNameInfo,
	kPKMyCardContactPhoneInfo,
	kPKMyCardPersonalInfo,
	kPKMyCardInstantMessageInfo,
	kPKMyCardCharacterDesignInfo,
	kPKMyCardTemplateInfo,
	kPKMyCardEmailInfo,
	kPKMyCardCategoryCount
}PKMyCardCate;


@interface PKMyCardCategory : NSObject {
	PKMyCardCate    cate_;
    NSString*		cateName_;
	NSMutableArray*	itemNameArr_;	//包含的字段名
	NSMutableArray* itemContentArr_;//包含的字段名对应的内容
	NSMutableArray*	itemMaskArr_;	//该字段是否用于显示来电秀
	NSMutableArray* itemKeyBoardTypeArr_;

}
@property(nonatomic, retain) NSString*   cateName;

- (id)initWithCategoryStyle:(PKMyCardCate)style;
- (NSInteger)numberOfItems;
- (NSString*)itemNameOfIndex:(NSInteger)index;
- (BOOL)itemMaskOfIndex:(NSInteger)index;
- (UIKeyboardType)keyboardTypeOfIndex:(NSInteger)index;
- (void)setItemMask:(BOOL)mask index:(NSInteger)index;

@end
