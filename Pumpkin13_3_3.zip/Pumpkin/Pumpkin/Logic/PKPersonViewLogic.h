//
//  PKPersonViewLogic.h
//  Pumpkin
//
//  Created by lv on 4/15/12.
//  Copyright (c) 2012 XXXXX. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PKContactEngine.h"

enum
{
	kPKPersonsSearchBarSectionTag,
	kPKPersonsStartSectionTag,
	kPKPersonsContactSectionTag,
	kPKPersonsEndSectionTag,
	kPKPersonsSectionCountTag
};//sectionStyle_;

@interface PKPersonViewLogic : NSObject
{
	PKContactEngine*		contactEngine_;
	NSDictionary*			personsDict_;
	NSArray*				sectionArr_;
	BOOL					isSearching_;
}

@property(nonatomic, assign) BOOL isSearching;

- (NSInteger)numberOfSection;
- (NSInteger)numberOfRowsInSection:(NSInteger)section;
- (NSInteger)tagOfSectionAtIndexPath:(NSIndexPath *)indexPath;
- (NSString*)contentAtIndexPath:(NSIndexPath *)indexPath;
- (void)didSelectedAtIndex:(NSIndexPath*)indexPath;
- (NSString*)titleForHeaderInSection:(NSInteger)section;
- (NSArray*)sectionIndexTitlesArray;
- (UIImage*)imageAtIndexPath:(NSIndexPath *)indexPath;

- (void)refreshPersons;
- (PKContactPersion*)personRecordRefAtIndexPath:(NSIndexPath*)indexPath;

- (void)searchPersonsWithKeyStr:(NSString*)keyStr;
@end


