//
//  PKLogicEngine.h
//  Pumpkin
//
//  Created by lv on 3/3/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PKContactEngine.h"

enum
{
	kPKGroupsStartSectionTag,
	kPKGroupsContentSectionTag,
	kPKGroupsEndSectionTag,
	kPKGroupsSectionCountTag,
};//sectionStyle_;

@interface PKGroupViewLogic : NSObject 
{
	PKContactEngine*		contactEngine_;
	NSArray*				groupsArr_;
	NSArray*				sectionArr_;
}

- (NSInteger)numberOfSection;
- (NSInteger)numberOfRowsInSection:(NSInteger)section;
- (id)contentAtIndexPath:(NSIndexPath *)indexPath;
- (NSInteger)selGroupIndex;
- (NSString*)groupNameOfGroupIndex:(NSInteger)index;


- (NSInteger)tagAtIndexPath:(NSIndexPath *)indexPath;
- (void)didSelectedAtIndex:(NSIndexPath*)indexPath;

- (PKContactGroup*)groupRecordRefAtIndexPath:(NSIndexPath*)indexPath;

- (void)refreshGroups;

@end
