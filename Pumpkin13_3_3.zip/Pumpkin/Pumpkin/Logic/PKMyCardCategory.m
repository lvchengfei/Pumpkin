//
//  PKMyCardCategory.m
//  Pumpkin
//
//  Created by lv on 3/17/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import "PKMyCardCategory.h"
#import "PKDefine.h"


@interface PKMyCardCategory()
@property(nonatomic, retain) NSMutableArray*   itemNameArr;
@property(nonatomic, retain) NSMutableArray*   itemContentArr;
@property(nonatomic, retain) NSMutableArray*   itemMaskArr;

- (void)initGeneralInfo;
- (void)initNameInfo;
- (void)initContactPhoneInfo;
- (void)initPersonalInfo;
- (void)initInstantMessageInfo;
- (void)initCharacterDesignInfo;
- (void)initTemplateInfo;
@end

@implementation PKMyCardCategory
@synthesize cateName = cateName_;
@synthesize itemNameArr = itemNameArr_;
@synthesize itemContentArr = itemContentArr_;
@synthesize itemMaskArr = itemMaskArr_;

- (id)initWithCategoryStyle:(PKMyCardCate)style
{
	self = [super init];
	if (self) {

		itemContentArr_ = [[NSMutableArray alloc] initWithCapacity:0];
		itemMaskArr_    = [[NSMutableArray alloc] initWithCapacity:0];
		itemKeyBoardTypeArr_ = [[NSMutableArray alloc] initWithCapacity:0];
		cate_ = style;
		switch (style) {
			case kPKMyCardGeneralInfo:
				[self initGeneralInfo];
				break;
			case kPKMyCardNameInfo:
				[self initNameInfo];
				break;
			case kPKMyCardContactPhoneInfo:
				[self initContactPhoneInfo];
				break;
			case kPKMyCardPersonalInfo:
				[self initPersonalInfo];
				break;
			case kPKMyCardInstantMessageInfo:
				[self initInstantMessageInfo];
				break;
			case kPKMyCardCharacterDesignInfo:
				[self initCharacterDesignInfo];
				break;
			case kPKMyCardTemplateInfo:
				[self initTemplateInfo];
				break;
			default:
				break;
		}

	}
	return self;
}

- (void)dealloc
{
	[cateName_			release];
	[itemNameArr_		release];
	[itemContentArr_	release];
	[itemMaskArr_		release];
	[itemKeyBoardTypeArr_	release];
	[super dealloc];
}

#pragma mark - Public Method

- (NSInteger)numberOfItems
{
	return [itemNameArr_ count];
}

- (NSString*)itemNameOfIndex:(NSInteger)index
{
	return objectAtIndex(itemNameArr_,index);
}

- (BOOL)itemMaskOfIndex:(NSInteger)index
{
	return [objectAtIndex(itemMaskArr_,index) boolValue];
}

- (UIKeyboardType)keyboardTypeOfIndex:(NSInteger)index
{
	UIKeyboardType type = UIKeyboardTypeDefault;
	if ( objectAtIndex(itemKeyBoardTypeArr_,index)) {
		type =  [objectAtIndex(itemKeyBoardTypeArr_,index) intValue];
	}
	return type;
}

- (void)setItemMask:(BOOL)mask index:(NSInteger)index
{
	if(validateIndex(itemMaskArr_,index))
	{
		[itemMaskArr_ replaceObjectAtIndex:index withObject:[NSNumber numberWithBool:mask]];
	}
}

#pragma mark - Private Method

- (void)initGeneralInfo
{
	self.cateName = NSLocalizedString(@"kGeneralInfo", nil);
	self.itemNameArr = [NSMutableArray arrayWithObjects:NSLocalizedString(@"kAvatar", nil),NSLocalizedString(@"kCellPhone", nil),NSLocalizedString(@"kCompany", nil),NSLocalizedString(@"kQQ", nil),NSLocalizedString(@"kEmail", nil), nil];
	[itemMaskArr_ addObject:[NSNumber numberWithBool:NO]];
	[itemKeyBoardTypeArr_ addObject:[NSNumber numberWithInt:UIKeyboardTypeDefault]];

}

- (void)initNameInfo
{
	self.cateName = NSLocalizedString(@"kNameInfo", nil);
	self.itemNameArr = [NSMutableArray arrayWithObjects:NSLocalizedString(@"kName", nil), nil];
	[itemMaskArr_ addObject:[NSNumber numberWithBool:NO]];
	[itemKeyBoardTypeArr_ addObject:[NSNumber numberWithInt:UIKeyboardTypeDefault]];
}

- (void)initContactPhoneInfo
{
	self.cateName = NSLocalizedString(@"kContactPhone", nil);
	NSArray* rowInfo =[NSArray arrayWithObjects:NSLocalizedString(@"kCellPhone", nil),
					   NSLocalizedString(@"kWorkPhone", nil),NSLocalizedString(@"kHomePhone", nil),
					   NSLocalizedString(@"kEmail", nil),NSLocalizedString(@"kHomeFox", nil),
					   NSLocalizedString(@"kWorkFox", nil),nil];
	self.itemNameArr = [NSMutableArray arrayWithArray:rowInfo];
	for (NSInteger i=0; i<[itemNameArr_ count]; i++) {
		[itemMaskArr_ addObject:[NSNumber numberWithBool:YES]];
		[itemKeyBoardTypeArr_ addObject:[NSNumber numberWithInt:UIKeyboardTypeNumberPad]];
	}
	//email
	[itemKeyBoardTypeArr_ replaceObjectAtIndex:3 withObject:[NSNumber numberWithInt:UIKeyboardTypeEmailAddress]];
	
}

- (void)initPersonalInfo
{
	self.cateName = NSLocalizedString(@"kPersonInfo", nil);
	NSArray* rowInfo =[NSArray arrayWithObjects:NSLocalizedString(@"kCompany", nil),
					   NSLocalizedString(@"kTitle", nil),NSLocalizedString(@"kBirthday", nil),
					   NSLocalizedString(@"kNote", nil),NSLocalizedString(@"kHomeAddress", nil),
					   NSLocalizedString(@"kWorkAddress", nil),nil];
	self.itemNameArr = [NSMutableArray arrayWithArray:rowInfo];
	for (NSInteger i=0; i<[itemNameArr_ count]; i++) {
		[itemMaskArr_ addObject:[NSNumber numberWithBool:NO]];
		[itemKeyBoardTypeArr_ addObject:[NSNumber numberWithInt:UIKeyboardTypeDefault]];
	}
	//birthday
	[itemKeyBoardTypeArr_ replaceObjectAtIndex:2 withObject:[NSNumber numberWithInt:UIKeyboardTypeNumberPad]];

}

- (void)initInstantMessageInfo
{
	self.cateName = NSLocalizedString(@"kInstanctMessage", nil);
	NSArray* rowInfo =[NSArray arrayWithObjects:NSLocalizedString(@"kMSN", nil),
					   NSLocalizedString(@"kQQ", nil),NSLocalizedString(@"kGtalk", nil),nil];
	self.itemNameArr = [NSMutableArray arrayWithArray:rowInfo];
	for (NSInteger i=0; i<[itemNameArr_ count]; i++) {
		[itemMaskArr_ addObject:[NSNumber numberWithBool:NO]];
		[itemKeyBoardTypeArr_ addObject:[NSNumber numberWithInt:UIKeyboardTypeASCIICapable]];
	}
	[itemKeyBoardTypeArr_ replaceObjectAtIndex:1 withObject:[NSNumber numberWithInt:UIKeyboardTypeNumberPad]];

}


- (void)initCharacterDesignInfo
{
	self.cateName = NSLocalizedString(@"kCharacterDesign", nil) ;
	NSArray* rowInfo =[NSArray arrayWithObjects:NSLocalizedString(@"kNickName", nil),
					   NSLocalizedString(@"kSignature", nil),nil];
	self.itemNameArr = [NSMutableArray arrayWithArray:rowInfo];
	for (NSInteger i=0; i<[itemNameArr_ count]; i++) {
		[itemMaskArr_ addObject:[NSNumber numberWithBool:NO]];
		[itemKeyBoardTypeArr_ addObject:[NSNumber numberWithInt:UIKeyboardTypeDefault]];
	}
}

- (void)initTemplateInfo
{
	self.cateName = NSLocalizedString(@"kTemplate", nil) ;
	NSArray* rowInfo =[NSArray arrayWithObjects:NSLocalizedString(@"kTemplateOne", nil),
					   NSLocalizedString(@"kTemplateOne", nil),nil];
	self.itemNameArr = [NSMutableArray arrayWithArray:rowInfo];
	for (NSInteger i=0; i<[itemNameArr_ count]; i++) {
		[itemMaskArr_ addObject:[NSNumber numberWithBool:NO]];
	}
}


@end
