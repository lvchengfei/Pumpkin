//
//  PKShareWeiboAuth.h
//  Pumpkin
//
//  Created by lv on 7/14/12.
//  Copyright (c) 2012 XXX. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef	 enum
{
	kSinaWeibo,
	kTencentWeibo,
	kKaiXin,
	kNetEaseWeibo,
}PKWeiboAuthType;

@interface PKShareWeiboAuth : NSObject
{
	NSMutableArray*			weiboAuthoArr_;			//微博列表
	NSMutableDictionary*	weiboAuthoValueDict_;	//是否已授权
}

- (NSInteger)numberOfWeiboAutho;
- (NSString*)titleOfWeiboAuthoAtIndex:(PKWeiboAuthType)index;
- (BOOL)isWeiboAuthoAtIndex:(PKWeiboAuthType)index;
- (void)setWeiboAuthoAtIndex:(PKWeiboAuthType)index value:(BOOL)value;

@end
