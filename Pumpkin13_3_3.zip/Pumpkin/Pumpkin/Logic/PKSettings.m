//
//  PKSettings.m
//  Pumpkin
//
//  Created by lv on 5/8/12.
//  Copyright (c) 2012 XXXXX. All rights reserved.
//

#import "PKSettings.h"
#import "PKDefine.h"
#import "PKSectionObject.h"
#import "PKUtils.h"
#import "PKConst.h"
#import "PKJSONKit.h"
#import "PKPathUtil.h"
#import "PKContactEngine.h"



enum
{
    PKSettingAccount,
    PKSettingContact,
	PKSettingWeiboAuth,
    PKSettingAbout,
    PKSettingCount,
};



@interface PKSettings()
- (void)initSettingsItems;
- (void)updateAccountAuthManagerSection;
- (void)updateAccountAuthToSever;
@end


@implementation PKSettings
@synthesize account;
@synthesize passWord;
@synthesize delegate = delegate_;
//@synthesize openAccountAutho = openAccountAutho_;

- (id)init
{
	self = [super init] ;
	if (self)
	{
		settingsDict_ = [[NSMutableDictionary alloc] initWithCapacity:0];
		imageIconDict_= [[NSMutableDictionary alloc] initWithCapacity:0]; 
		sectionArr_   = [[NSMutableArray alloc] initWithCapacity:0];
		isShowCallInteractive_ = YES;
		isOpenAccountAuth_	   = YES;
		NSUserDefaults* userDefault = [NSUserDefaults standardUserDefaults];
		if ([userDefault objectForKey:kShowCallInteractive]) 
		{
			isShowCallInteractive_ = [userDefault boolForKey:kShowCallInteractive];
		}
		if ([userDefault objectForKey:kOpenAccountAuth]) 
		{
			isOpenAccountAuth_ = [userDefault boolForKey:kOpenAccountAuth];
		}
//		if ([userDefault objectForKey:kOpenAccountAuthDetail]) 
//		{
//			openAccountAutho_ = [[userDefault objectForKey:kOpenAccountAuthDetail] integerValue];
//		}
		[self initSettingsItems];
	}
	return self ;
}
- (void)dealloc
{
	[netWorkEngine_			release];
	[settingsDict_			release];
	[imageIconDict_			release];
	[sectionArr_			release];
	[account				release];
	[passWord				release];
	[super dealloc];
}

#pragma mark -
#pragma mark Public Methods 

- (NSInteger)numberOfSettings
{
	return [sectionArr_ count];
}

- (NSInteger)numberOfSettingsSection
{
	return [sectionArr_ count];
}

- (NSInteger)numberOfSettingsAtSection:(NSInteger)section
{
	PKSectionObject* sectionObj = objectAtIndex(sectionArr_, section);
	return [sectionObj numberOfRowsInSection];
}

- (NSString*)contentOfSettingsAtSection:(NSInteger)section
{	
	return nil;
	PKSectionObject* sectionObj = objectAtIndex(sectionArr_, section);
	return [sectionObj titleOfSection];	
}

- (NSString*)contentOfSettingsAtSection:(NSInteger)section row:(NSInteger)row
{
	PKSectionObject* sectionObj = objectAtIndex(sectionArr_, section);
	NSNumber* rowTag = [sectionObj rowItemAtIndex:row];
	return [settingsDict_ objectForKey:rowTag];
}

- (UIImage*)imageOfSettingsAtSection:(NSInteger)section row:(NSInteger)row
{
	PKSectionObject* sectionObj = objectAtIndex(sectionArr_, section);
	NSNumber* rowTag = [sectionObj rowItemAtIndex:row];
	return [imageIconDict_ objectForKey:rowTag];
}

- (NSInteger)tagOfSettingsAtSection:(NSInteger)section row:(NSInteger)row
{
	PKSectionObject* sectionObj = objectAtIndex(sectionArr_,section);
	NSNumber* rowTag = [sectionObj rowItemAtIndex:row];
	return  [rowTag integerValue];
}

- (BOOL)showSwitchOfSettingsAtSection:(NSInteger)section row:(NSInteger)row
{
	BOOL	result = NO;
	PKSectionObject* sectionObj = objectAtIndex(sectionArr_,section);
	NSNumber* rowTag = [sectionObj rowItemAtIndex:row];
	NSInteger tmpRow = [rowTag integerValue];
	switch (tmpRow) 
	{
		case PKShowCallInteractive:
		case PKAccountAuthManager:
			result = YES;
			break;
		default:
			break;
	}
	return result;
}

- (BOOL)showDisclosureIndicatorAtIndexPath:(NSIndexPath*)indexPath
{
	BOOL	result = NO;
	PKSectionObject* sectionObj = objectAtIndex(sectionArr_, indexPath.section);
	NSNumber* rowTag = [sectionObj rowItemAtIndex:indexPath.row];
	NSInteger row = [rowTag integerValue];
	switch (row) 
	{
		case PKShareWithFrineds:
		case PKWeiBoAuth:
		//case PKAccountAuthManagerDetail:
		//case PKAboutUs:
			result = YES;
			break;
		default:
			break;
	}
	return result;
}

- (void)didSeletedIndexPath:(NSIndexPath*)indexPath
{
	PKSectionObject* sectionObj = objectAtIndex(sectionArr_, indexPath.section);
	NSNumber* rowTag = [sectionObj rowItemAtIndex:indexPath.row];
	currentSelecteSet_ = [rowTag integerValue];
	switch (currentSelecteSet_) {
		case PKChangePhoneNumber:
			[delegate_ settings:self showLoginView:PKLogInChangeNumber];
			break;
		case PKChangePassword:
			[delegate_ settings:self showLoginView:PKLogInChangePassword];
			break;
		case PKContactBackup:
			[delegate_ settings:self showLoginView:PKLogInBackup];
			break;
		case PKContactResume:
			[delegate_ settings:self showLoginView:PKLogInResume];
			break;
		case PKLogOut:
			[delegate_ settings:self showLoginView:PKLogInRemoveAccount];
			break;
			
		default:
			break;
	}
}

- (BOOL)valueOfSwitchTag:(NSInteger)tag
{
	if (tag==PKShowCallInteractive) 
	{
		return isShowCallInteractive_;
	}
	else if(tag==PKAccountAuthManager)
	{
		return isOpenAccountAuth_;
	}
	return NO;
}


//返回值表示是否需要现实loading界面
- (BOOL)setSwitchTag:(NSInteger)tag value:(BOOL)value
{
	NSUserDefaults* userDefault = [NSUserDefaults standardUserDefaults];
	BOOL result = NO;
	if (tag==PKShowCallInteractive) 
	{
		if (isShowCallInteractive_!=value) 
		{
			isShowCallInteractive_ = value;
			[userDefault setBool:isShowCallInteractive_ forKey:kShowCallInteractive];
		}
	}
	else if(tag==PKAccountAuthManager)
	{
		//if (isOpenAccountAuth_!=value) 
		{
			isOpenAccountAuth_ = value;
			[self updateAccountAuthToSever];
			result = YES;
		}
	}
	[userDefault synchronize];
	return result;
}

- (void)setOpenList:(NSString*)phoneList
{
	if ([phoneList length]>0)
	{
		frinedsPhoneList_ = [phoneList retain];
		isOpenAccountAuth_ = YES;
	
		if (netWorkEngine_ == nil) 
		{
			netWorkEngine_ = [[PKNetwork alloc] init];
			netWorkEngine_.delegate = self;
		}
		//http://115.238.43.29/maike/setMyOpenList.action?ownerMobile=13866669999&oppositeMobile=13911112222~13866660001
		NSString* URLStr  = [NSString stringWithFormat:@"ownerMobile=%@&oppositeMobile=%@",self.account,phoneList];
		NSData* bodyData = [URLStr dataUsingEncoding:NSUTF8StringEncoding];
		NSString* URLPath = [kMaikeSeverURL stringByAppendingPathComponent:@"setMyOpenList.action"];
		NSMutableURLRequest* urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:URLPath]];
		[urlRequest setHTTPMethod:@"POST"];
		[urlRequest setHTTPBody:bodyData];
		
		netWorkEngine_.tag = PKAccountAuthManagerDetail;
		[netWorkEngine_ startConnectionWithURLRequest:urlRequest synchronise:NO];
		
	}
}

- (void)addFriendsToOpenList:(NSString*)phoneList
{
	if ([phoneList length]>0)
	{
		frinedsPhoneList_ = [phoneList retain];
		isOpenAccountAuth_ = YES;
		
		if (netWorkEngine_ == nil) 
		{
			netWorkEngine_ = [[PKNetwork alloc] init];
			netWorkEngine_.delegate = self;
		}
		//http://115.238.43.29/maike/setMyOpenList.action?ownerMobile=13866669999&oppositeMobile=13911112222~13866660001
		//http://202.91.233.108/mobile/addToMyOpenList.action?ownerMobile=13899990002&oppositeMobile=18217228641

		NSString* URLStr  = [NSString stringWithFormat:@"ownerMobile=%@&oppositeMobile=%@",self.account,phoneList];
		NSData* bodyData = [URLStr dataUsingEncoding:NSUTF8StringEncoding];
		NSString* URLPath = [kMaikeSeverURL stringByAppendingPathComponent:@"addToMyOpenList.action"];
		NSMutableURLRequest* urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:URLPath]];
		[urlRequest setHTTPMethod:@"POST"];
		[urlRequest setHTTPBody:bodyData];
		
		netWorkEngine_.tag = PKAccountAuthManagerDetail;
		[netWorkEngine_ startConnectionWithURLRequest:urlRequest synchronise:NO];
		
	}
}


- (NSString*)contentOfOpenAccountType:(PKOpenAccountType)type
{
	NSArray* contentArr = [NSArray arrayWithObjects:NSLocalizedString(@"kOpenAccountNone", nil),
													NSLocalizedString(@"kOpenAccountToFriend", nil),
													NSLocalizedString(@"kOpenAccountToAll", nil),nil];
	return  objectAtIndex(contentArr, type);
}



- (void)logout//退出登录
{
	NSUserDefaults* userDefault = [NSUserDefaults standardUserDefaults];
	NSString* oldAccount =  [userDefault objectForKey:kAccountInfo];
	[userDefault setObject:oldAccount forKey:koldAccountInfo];//设置保留号码
	[userDefault setBool:NO			 forKey:kisHaveRegisterAccount];
	//[userDefault removeObjectForKey:kHaveShowTutorial];
	[userDefault removeObjectForKey:kAccountInfo];
	[userDefault removeObjectForKey:kPassWordInfo];
	[userDefault synchronize];
}

-(void)importAllFriendsToOpenList
{
	if (![PKUtils checkNetWorkAvailable])
	{
		if (delegate_&&[delegate_ respondsToSelector:@selector(settings:accountOpen:errorCode:)])
		{
			[delegate_  settings:self accountOpen:NO errorCode:0];
		}	
		return;
	}
	NSMutableArray* phonesArray = [[NSMutableArray alloc] initWithCapacity:0];
	PKContactEngine* contactEngine = [PKContactEngine sharedContactEngine];
	NSDictionary* totalPersonsDict = [contactEngine getTotalValidatePersonsDictionary];
	if ([totalPersonsDict count]>0) 
	{
		NSArray* allKeys = [totalPersonsDict allKeys];
		for (NSString*key in allKeys)
		{
			NSArray* personsArray = [totalPersonsDict objectForKey:key];
			
			for (PKContactPersion* person in personsArray)
			{
				NSString* cellPhone = [PKUtils phoneNumber:person];
				if ([cellPhone length]>0)
				{
					[phonesArray addObject:cellPhone];
				}
			}
		}
	}
	
	NSString* phonesStr = [phonesArray componentsJoinedByString:@"~"];
	[phonesArray	release];
	//NSLog(@">>>importAllFriends =%@",phonesStr);
	if ([phonesStr length]>0)
	{
		[self setOpenList:phonesStr];
		isRuning_ = YES;
		while (isRuning_)
		{
			[[NSRunLoop currentRunLoop] runUntilDate:[NSDate dateWithTimeIntervalSinceNow:0.5]];
		}
	}
	else
	{
		if (delegate_&&[delegate_ respondsToSelector:@selector(settings:accountOpen:errorCode:)])
		{
			[delegate_  settings:self accountOpen:NO errorCode:0];
		}	
	}
}

#pragma mark - Private Method

- (void)initSettingsItems
{
	
	//init total settings
	[settingsDict_ setObject:NSLocalizedString(@"kContactBackup", nil)		forKey:[NSNumber numberWithInt:PKContactBackup ]];
	[settingsDict_ setObject:NSLocalizedString(@"kContactResume", nil)		forKey:[NSNumber numberWithInt:PKContactResume ]];
	[settingsDict_ setObject:NSLocalizedString(@"kWeiBoAuth", nil)			forKey:[NSNumber numberWithInt:PKWeiBoAuth ]];
	[settingsDict_ setObject:NSLocalizedString(@"kShareWithFrineds", nil)	forKey:[NSNumber numberWithInt:PKShareWithFrineds ]];
	[settingsDict_ setObject:NSLocalizedString(@"kShowCallAnimation", nil)  forKey:[NSNumber numberWithInt:PKShowCallInteractive ]];
	[settingsDict_ setObject:NSLocalizedString(@"kAccountAuthManager", nil) forKey:[NSNumber numberWithInt:PKAccountAuthManager ]];
	[settingsDict_ setObject:NSLocalizedString(@"kAccountAuthManagerDetail",nil) forKey:[NSNumber numberWithInt:PKAccountAuthManagerDetail ]];
	[settingsDict_ setObject:NSLocalizedString(@"kChangePhoneNumber", nil)	forKey:[NSNumber numberWithInt:PKChangePhoneNumber ]];
	[settingsDict_ setObject:NSLocalizedString(@"kChangePassword", nil)		forKey:[NSNumber numberWithInt:PKChangePassword ]];
	[settingsDict_ setObject:NSLocalizedString(@"kAboutUs", nil)			forKey:[NSNumber numberWithInt:PKAboutUs ]];
	[settingsDict_ setObject:NSLocalizedString(@"kLogOutAccount", nil)		forKey:[NSNumber numberWithInt:PKLogOut ]];

	
	//init total image icon
	UIImage* tmpImage = nil;
	tmpImage = [PKUtils settingImageWithName:@"setting_backAndResume.png"];
	[imageIconDict_ setObject:tmpImage forKey:[NSNumber numberWithInt:PKContactBackup ]];
	[imageIconDict_ setObject:tmpImage forKey:[NSNumber numberWithInt:PKContactResume ]];
	tmpImage = [PKUtils settingImageWithName:@"setting_weibo_authorize.png"];
	[imageIconDict_ setObject:tmpImage forKey:[NSNumber numberWithInt:PKWeiBoAuth ]];
	tmpImage = [PKUtils settingImageWithName:@"setting_friend_recommend.png"];
	[imageIconDict_ setObject:tmpImage forKey:[NSNumber numberWithInt:PKShareWithFrineds ]];
	tmpImage = [PKUtils settingImageWithName:@"setting_interactive_toggle.png"];
	[imageIconDict_ setObject:tmpImage forKey:[NSNumber numberWithInt:PKShowCallInteractive ]];
	[imageIconDict_ setObject:tmpImage forKey:[NSNumber numberWithInt:PKAccountAuthManager ]];
	tmpImage = [PKUtils settingImageWithName:@"setting_open_cards.png"];
	[imageIconDict_ setObject:tmpImage forKey:[NSNumber numberWithInt:PKAccountAuthManagerDetail ]];
	tmpImage = [PKUtils settingImageWithName:@"setting_replace_phone.png"];
	[imageIconDict_ setObject:tmpImage forKey:[NSNumber numberWithInt:PKChangePhoneNumber ]];
	tmpImage = [PKUtils settingImageWithName:@"setting_modify_password.png"];
	[imageIconDict_ setObject:tmpImage forKey:[NSNumber numberWithInt:PKChangePassword ]];
	tmpImage = [PKUtils settingImageWithName:@"setting_about.png"];
	[imageIconDict_ setObject:tmpImage forKey:[NSNumber numberWithInt:PKAboutUs ]];
	tmpImage = [PKUtils settingImageWithName:@"setting_logout_account.png"];
	[imageIconDict_ setObject:tmpImage forKey:[NSNumber numberWithInt:PKLogOut ]];

	
	NSString* sectionTitle  =  nil;
	NSMutableArray*  rowArr = nil;
	PKSectionObject*section = nil;
	//init backup and resume settings
	//init contact settings
	/*sectionTitle =  NSLocalizedString(@"kContactManager", nil);
	rowArr = [[NSMutableArray alloc] initWithCapacity:0];
	[rowArr addObject:[NSNumber numberWithInt:PKContactBackup ]];
	[rowArr addObject:[NSNumber numberWithInt:PKContactResume ]];
	section = [[PKSectionObject alloc] initWithSectionTag:PKSettingContact title:sectionTitle	rowsArray:rowArr];
	[sectionArr_ addObject:section];
	[section	release];
	[rowArr		release];
	*/
	
	
	//init kShareAndAuth settings
	sectionTitle =  NSLocalizedString(@"kShareAndAuth", nil);
	rowArr = [[NSMutableArray alloc] initWithCapacity:0];
	[rowArr addObject:[NSNumber numberWithInt:PKWeiBoAuth ]];
	[rowArr addObject:[NSNumber numberWithInt:PKShareWithFrineds ]];
	section = [[PKSectionObject alloc] initWithSectionTag:PKSettingWeiboAuth title:sectionTitle	rowsArray:rowArr];
	[sectionArr_ addObject:section];
	[section	release];
	[rowArr		release];
	
	
	//init account settings
	sectionTitle =  NSLocalizedString(@"kAccountManager", nil);
	rowArr = [[NSMutableArray alloc] initWithCapacity:0];
	[rowArr addObject:[NSNumber numberWithInt:PKShowCallInteractive ]];
	[rowArr addObject:[NSNumber numberWithInt:PKAccountAuthManager ]];
	if (isOpenAccountAuth_) 
	{
			[rowArr addObject:[NSNumber numberWithInt:PKAccountAuthManagerDetail ]];
	}
	section = [[PKSectionObject alloc] initWithSectionTag:PKSettingAccount title:sectionTitle	rowsArray:rowArr];
	[sectionArr_ addObject:section];
	[section	release];
	[rowArr		release];
	
	//init kAboutUs settings
	sectionTitle =  NSLocalizedString(@"kAboutUs", nil);
	rowArr = [[NSMutableArray alloc] initWithCapacity:0];
	[rowArr addObject:[NSNumber numberWithInt:PKChangePhoneNumber ]];
	[rowArr addObject:[NSNumber numberWithInt:PKChangePassword ]];
	[rowArr addObject:[NSNumber numberWithInt:PKLogOut ]];
	[rowArr addObject:[NSNumber numberWithInt:PKAboutUs ]];
	section = [[PKSectionObject alloc] initWithSectionTag:PKSettingAbout title:sectionTitle	rowsArray:rowArr];
	[sectionArr_ addObject:section];
	[section	release];
	[rowArr		release];
}

- (void)updateAccountAuthManagerSection
{
	NSMutableArray* rowArr = [[NSMutableArray alloc] initWithCapacity:0];
	[rowArr addObject:[NSNumber numberWithInt:PKShowCallInteractive ]];
	[rowArr addObject:[NSNumber numberWithInt:PKAccountAuthManager ]];
	if (isOpenAccountAuth_) 
	{
		[rowArr addObject:[NSNumber numberWithInt:PKAccountAuthManagerDetail ]];
	}
	PKSectionObject* secObj = nil;
	for (secObj in  sectionArr_)
	{
		if (secObj.tagOfSection ==PKSettingAccount)
		{
			break;
		}
	}
	secObj.rowItemsArr = [NSArray arrayWithArray:rowArr];
	[rowArr	release];
}

- (void)updateAccountAuthToSever
{
	if (netWorkEngine_ == nil) 
	{
		netWorkEngine_ = [[PKNetwork alloc] init];
		netWorkEngine_.delegate = self;
	}
	NSString* sw = isOpenAccountAuth_?@"on":@"off";
	//http://115.238.43.29/maike/doSwitchOpen.action?mobile=13866669999&onoff=on
	NSString* URLStr  = [NSString stringWithFormat:@"mobile=%@&onoff=%@",self.account,sw];
	NSData* bodyData = [URLStr dataUsingEncoding:NSUTF8StringEncoding];
	NSString* URLPath = [kMaikeSeverURL stringByAppendingPathComponent:@"doSwitchOpen.action"];
	NSMutableURLRequest* urlRequest = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:URLPath]];
	[urlRequest setHTTPMethod:@"POST"];
	[urlRequest setHTTPBody:bodyData];
	
	netWorkEngine_.tag = PKAccountAuthManager;
	[netWorkEngine_ startConnectionWithURLRequest:urlRequest synchronise:NO];
}


#pragma mark - PKNetworkProtocol Delegate

- (void) network:(PKNetwork*)network responseResult:(id)result
{
	isRuning_ = NO;
	NSData* tmpData = (NSData*)result;
	id  resultDict = [tmpData objectFromJSONData];
	NSInteger errCode = 0;
	BOOL netWrokResult = YES;
	if (resultDict&&[[resultDict allKeys] count]>0) 
	{
		id  result = [resultDict objectForKey:kURLResult];
		if(result&&[result isKindOfClass:[NSNumber class]]&&[result integerValue]==1)
		{
			if (network.tag == PKAccountAuthManager)
			{
				[self updateAccountAuthManagerSection];
				NSUserDefaults* userDefault = [NSUserDefaults standardUserDefaults];
				[userDefault setBool:isOpenAccountAuth_ forKey:kOpenAccountAuth];
				[userDefault synchronize];
			}
			else if(network.tag==PKAccountAuthManagerDetail)
			{
				if ([frinedsPhoneList_ length]>0)
				{
					NSString* filePath = [[PKPathUtil settingsPath] stringByAppendingPathComponent:kAccountOpenToFriendsFile];
					NSArray* phoneArray = [frinedsPhoneList_ componentsSeparatedByString:@"~"];
					[phoneArray writeToFile:filePath atomically:YES];
					[frinedsPhoneList_	release];
					frinedsPhoneList_ = nil;
				}
			}
		}
		else 
		{
			if (network.tag == PKAccountAuthManager)
			{
				isOpenAccountAuth_ = !isOpenAccountAuth_;
				[self updateAccountAuthManagerSection];
			}
			errCode = [result isKindOfClass:[NSNumber class]]?[result integerValue]:-1;
			netWrokResult = NO;
		}
		
		if (delegate_&&[delegate_ respondsToSelector:@selector(settings:accountOpen:errorCode:)])
		{
			[delegate_ settings:self accountOpen:netWrokResult errorCode:errCode];
		}
		
	}
	
}

- (void) network:(PKNetwork *)network responseError:(PKNetWorkErrorCode)errorCode
{
	isRuning_ = NO;
	if (network.tag == PKAccountAuthManager||network.tag==PKAccountAuthManagerDetail)
	{
		if (network.tag == PKAccountAuthManager)
		{
			isOpenAccountAuth_ = !isOpenAccountAuth_;
			[self updateAccountAuthManagerSection];
		}
		if (delegate_&&[delegate_ respondsToSelector:@selector(settings:accountOpen:errorCode:)])
		{
			[delegate_  settings:self accountOpen:NO errorCode:kNetWorkErr];
		}
	}

}


@end
