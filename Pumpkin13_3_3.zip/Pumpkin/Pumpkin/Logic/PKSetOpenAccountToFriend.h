//
//  PKSetOpenAccountToFriend.h
//  Pumpkin
//
//  Created by lv on 7/8/12.
//  Copyright (c) 2012 XXX. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PKAddMemToGroup.h"

@class PKSetOpenAccountToFriend;
@protocol PKSetOpenAccountToFriendProtocol <NSObject>
@optional

@end
@interface PKSetOpenAccountToFriend:PKAddMemToGroup
{
	NSMutableArray*								openToFriendsArray_;	//<对好友开放的好友列表>
	id <PKSetOpenAccountToFriendProtocol>		delegate_;
}
@property(nonatomic,assign) id <PKSetOpenAccountToFriendProtocol>	delegate;

- (NSString*)getSelectedFriendsPhoneNumber;
@end
