//
//  PKConst.h
//  Pumpkin
//
//  Created by lv on 3/3/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import "PKUtils.h"

#define kCallHistoryDataBase	@"/private/var/wireless/Library/CallHistory/call_history.db"
/*
 SString *path = @"/var/mobile/Library/Preferences/com.apple.mobilephone.plist";
 NSDictionary *dict = [NSDictionary dictionaryWithContentsOfFile:path];
 NSString *lastDialed = [NSString stringWithFormat:@"%@", [dict valueForKey:@"DialerSavedNumber"]];
 */



#define kDeviceType						2  //iphone
#define kScreenWith						320
#define kScreenHeight				   ([[UIScreen mainScreen] bounds].size.height)
#define kStatusHeight					20
#define kMaikeSeverURL					@"http://maike4i.97sng.com/mobile"//@"http://202.91.233.108/mobile"//@"http://115.238.43.29/maike"
#define kMaikeSeverDownloadURL			@"http://maike4i.97sng.com/"//@"http://202.91.233.108/"//@"http://115.238.43.29/maike"

#define kPushTypeOne					1
#define kPushTypeTwo					2
#define kPushTypeThree					3

#define kURLResult						@"result"
#define kNetWorkErr						0x11
#define kDefaultTimeOut					15
#define kUpdateAnimationTimeOut			10


#define kCheckAppBecomeActive			@"kCheckAppBecomeActive"
#define kCheckShouldGoBackSignature		@"kCheckShouldGoBackSignature"
#define kCheckShouldSynServerInfo		@"kCheckShouldSynServerInfo"
#define kCheckImportAllFriends			@"kCheckImportAllFriends"
#define kCheckShouldReloadPersonInfo	@"kCheckShouldReloadPersonInfo"
#define kHaveShowTutorial				@"kHaveShowTutorials"
#define kHaveShowUpdateAnimationPrompt	@"kHaveShowUpdateAnimationPrompt"
#define kisHaveRegisterAccount			@"kIsHaveRegisterAccount"
#define koldAccountInfo					@"koldAccountInfo"
#define kAccountInfo					@"kAccountInfo"
#define kPassWordInfo					@"kPassWordInfo"
#define kDialAnimationArray				@"kDialAnimationArray"
#define kShowCallInteractive			@"kShowCallInteractive"
#define kOpenAccountAuth				@"kOpenAccountAuth"
#define kOpenAccountAuthDetail			@"kOpenAccountAuthDetail"
#define kDialAnimationSetFile			@"animationSetting"				//保存来电动画的保存文件
#define kAuthSinaWeibo					@"kAuthSinaWeibo"
#define kAuthTencentWeibo				@"kAuthTencentWeibo"
#define kAuthNetEaseWeibo				@"kAuthNetEaseWeibo"
#define kAuthKaixin						@"kAuthKaixin"
#define kAccountOpenToFriendsFile		@"kAccountOpenToFriendsFile"	//保存对好友开放的好友列表文件

#define kAddGroupMembersBackNotification			@"kAddGroupMembersBackNotification"
#define kAddOpenAccountToFriendsNotification		@"kAddOpenAccountToFriendsNotification"


#define kAvatarImageName			@"kAvatarImageName.png"

//MyCard

typedef enum{
	kPKMyCardSectionHeadImage,
	kPKMyCardSectionDepartment,
	kPKMyCardSectionCellPhone,
	kPKMyCardSectionQQ,
	kPKMyCardSectionEmail,
	kPKMyCardSectionWebSite,
	kPKMyCardSectionCompanyAddress,
	kPKMyCardSectionAddItem,	//到这里是默认显示字段
	
	kPKMyCardSectionMSN,
	kPKMyCardSectionGTalk,
	kPKMyCardSectionHomeAddress,
	kPKMyCardSectionTitle,
	kPKMyCardSectionBirthday,
	kPKMyCardSectionWorkPhone,
	
	kPKMyCardSectionCount,		//到这里表示显示到添加项的内容
	kPKMyCardSectionSignatrue,
}PKMyCardSectionItem;

typedef enum{
	kPKMyCardRowAvatar,
	kPKMyCardRowName,
	kPKMyCardRowCellPhone,
	kPKMyCardRowCompany,
	kPKMyCardRowDepartment,
	kPKMyCardRowEmail,
	kPKMyCardRowQQ,
	kPKMyCardRowMSN,
	kPKMyCardRowGTalk,
	kPKMyCardRowCompanyAddress,
	kPKMyCardRowHomeAddress,
	kPKMyCardRowTitle,
	kPKMyCardRowBirthday,
	kPKMyCardRowWorkPhone,
	kPKMyCardRowWebSite,
	kPKMyCardRowSignatrue,
	kPKMyCardRowAddItems,
	
	kPKMyCardRowCount
}PKMyCardRowItem;

typedef enum{
	kPKDialAnimationSchool=1,
	kPKDialAnimationCount,
}PKDialAnimationType;

#define kAnimationDescription		 @"description"
#define	kAnimationDirectory			 @"dir"
#define kAnimationPath				 @"path"
#define kAnimationSN				 @"sn"
#define kAnimationType				 @"type"


#define kMyCardShowContactItems			@"kMyCardShowContactItems"
#define kMyCardTemplateName				@"kMyCardTemplateName"
//#define kMyCardTemplateIndex			@"kMyCardTemplateIndex"

#define kDefaultContactItemArray		[NSArray arrayWithObjects:[NSNumber numberWithInteger:kPKMyCardSectionHeadImage],[NSNumber numberWithInteger:kPKMyCardSectionCompany],[NSNumber numberWithInteger:kPKMyCardSectionDepartment],[NSNumber numberWithInteger:kPKMyCardSectionEmail],[NSNumber numberWithInteger:kPKMyCardSectionQQ],[NSNumber numberWithInteger:kPKMyCardSectionAddItem], nil]

#define kDefaultTemplateModelArray			[NSArray arrayWithObjects:@"template_small_01.jpg",@"template_small_02.jpg",@"template_small_03.jpg", @"template_small_04.jpg",@"template_small_05.jpg",@"template_small_06.jpg",nil]

#define kDefaultTemplateArray			[NSArray arrayWithObjects:@"template01.jpg",@"template02.jpg",@"template03.jpg", @"template04.jpg",@"template05.jpg",@"template06.jpg",nil]

#define kDefaultTemplateName			@"template02.jpg"
#define kDefaultTemplateIndex			1


//#define kDefaultDialAnimationArray [NSArray arrayWithObjects:@"an1",@"an2",@"an3",@"an4",nil]
#define kDefaultDialAnimationArray [NSArray arrayWithObjects:@"an1",@"an2",@"an3",nil]
#define kDefaultDialAnimationTitleArray [NSArray arrayWithObjects:@"水木年华",@"青春永恒",@"水上乐园",@"青春靓丽",nil]
#define kDefaultDialAnimationTypeArray  [NSArray arrayWithObjects:[NSNumber numberWithInteger:kPKDialAnimationSchool],[NSNumber numberWithInteger:kPKDialAnimationSchool],[NSNumber numberWithInteger:kPKDialAnimationSchool],[NSNumber numberWithInteger:kPKDialAnimationSchool],nil]

#define kRequestAddFriendsFile		@"kRequestAddFriendsFile"

