//
//  PKMyCardRow.m
//  Pumpkin
//
//  Created by lv on 6/27/12.
//  Copyright (c) 2012 XXX. All rights reserved.
//

#import "PKMyCardRow.h"

@implementation PKMyCardRow
@synthesize title = title_;
@synthesize value = value_;
@synthesize tag   = tag_;
@synthesize isValidate = isValidate_;

- (id)initWithTitle:(NSString*)title rowTag:(NSInteger)tag
{
	self = [super init];
	if (self) {
		title_ = title?[[NSString alloc] initWithString:title]:nil;
		tag_   = tag;
		isValidate_ = NO;
	}
	return self;
}

- (void)dealloc
{
	[title_			release];
	[super dealloc];
}


@end
