//
//  PKLogicEngine.h
//  Pumpkin
//
//  Created by lv on 7/3/12.
//  Copyright (c) 2012 XXX. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface PKLogicEngine : NSObject
{
	NSData* pushToken_;
}
@property(nonatomic,retain) NSData* pushToken;

+ (PKLogicEngine*)sharedInstance;
+ (void)releaseSharedInstance;
- (id)getBusinessInstance:(NSString*)className;

@end
