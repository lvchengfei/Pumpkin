//
//  PKUtils.h
//  Pumpkin
//
//  Created by lv on 3/18/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PKContactPersion.h"


@interface PKUtils : NSObject {
    
}
+(NSString*)firstWordPinYinOfChineseString:(NSString*)chineseStr;

#pragma mark - Image
+(UIImage*) imageWithFilePath:(NSString*)filePath;
+(UIImage*) tutorialImageWithName:(NSString*)imageName;
+(UIImage*) commonImageWithName:(NSString*)imageName;
+(UIImage*) contactImageWithName:(NSString*)imageName;
+(UIImage*) myCardImageWithName:(NSString*)imageName;
+(UIImage*) animationImageWithName:(NSString*)imageName;
+(UIImage*) settingImageWithName:(NSString*)imageName;


+(UIImage*) appRescontactImageWithName:(NSString*)imageName;
//根据颜色返回图片
+(UIImage*) imageWithColor:(UIColor*)color;
+(UIImage*) loadAvatarImage;
+(void) saveAvatarImage:(UIImage*)image;

+ (BOOL)checkShouldShowTutorialView;
+ (BOOL)shouldShowTutorialView;
+ (BOOL)isHaveRegisterAccount;
+ (BOOL)checkImportAllFriendsFlag;
+ (void)resetImportAllFriendsFlag;
+ (BOOL)shouldShowUpdateAnimationPrompt;
+ (BOOL)checkShouldReloadPersonInfo;
+ (BOOL)checkShouldSynServerInfo;//是否需要连服务器同步好友请求，好友更新，动画设置
+ (void)resetSynServerInfo;		 //设置需要同步标记
+ (BOOL)checkShouldGoBackSignature;//设置完微博授权后是否需要调回到同步签名
+ (void)resetGoBackSignature;	 //设置需要调回标记
+ (BOOL)checkAppIsBecomeActive;
+(void)resetAppActive;

+ (UIImage *)reSizeImage:(UIImage *)image toSize:(CGSize)reSize;

//我的名片字段
+ (NSDictionary*)myCardAllItemsTitleDictionary;
//我的名片上传对应的字段
+ (NSDictionary*)myCardAllItemsPostKeyDictionary;
//上传的字段对应本地保存的字段
+ (NSDictionary*)myCardAllPostKeyToItemsDictionary;
//IM 对应通讯录的字段
+(NSDictionary*)myCardImDictionary;
//返回手机号码
+ (NSString*)phoneNumber:(PKContactPersion*)person;
//检测是否有效的手机号码
+ (BOOL)isValidatePhoneNumber:(NSString*)phoneNumer;
//动画类别到名称的映射
+(NSDictionary*)dialAnimationTypeMapTitleDictionary;
//ret 1表示密码必须是4位以上，2表示密码必须是数字字母组合
+ (NSInteger)isValidatePassWord:(NSString*)passWord;

#pragma mark - NetWork
+ (BOOL)isNetWorkAvailable;
+ (BOOL)checkNetWorkAvailable;

#pragma mark - Debug
+ (void)showViewHierarchy:(UIView *)view level:(NSInteger)level ;
+ (void)showViewHierarchy:(UIView *)view ;


@end
