//
//  PKAddMemToGroup.m
//  Pumpkin
//
//  Created by lv on 3/18/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import "PKAddMemToGroup.h"
#import "PKDefine.h"

@interface PKAddMemToGroup()


@end

@implementation PKAddMemToGroup
@synthesize totalPersonsDict   = totalPersonsDict_;
@synthesize totalPersonsKeyArr = totalPersonsKeyArr_;

- (id)init
{
	self = [super init];
	if (self) 
	{
		contactEngine_ = [PKContactEngine sharedContactEngine];
		selectIndexArr_ = [[NSMutableArray  alloc] initWithCapacity:0];
		isSelectAll_   = NO;
		isSelectInArr_ = YES;
	}
	return self;
}

-(void)dealloc
{
	[totalPersonsDict_		release];
	[totalPersonsKeyArr_	release];
	[selectIndexArr_		release];
	[super dealloc];
}



#pragma mark - Public Method 

- (BOOL)isHaveCandidatePersons
{
	return [totalPersonsDict_ count]>0;
}

- (NSInteger)numberOfSection
{
	return [totalPersonsKeyArr_ count];
}

- (NSInteger)numberOfRowsInSection:(NSInteger)section
{
	NSString* key = objectAtIndex(totalPersonsKeyArr_, section);
	if (key) 
	{
		return [[totalPersonsDict_ objectForKey:key] count];
	}
	return 0;
}


- (NSString*)contentAtIndexPath:(NSIndexPath *)indexPath
{
	NSString* key = objectAtIndex(totalPersonsKeyArr_, indexPath.section);
	NSArray* personsArr = [totalPersonsDict_ objectForKey:key];
	return [objectAtIndex(personsArr, indexPath.row) contactName];			

}

- (NSString*)titleForHeaderInSection:(NSInteger)section
{
	return objectAtIndex(totalPersonsKeyArr_, section);
}

- (NSArray*)sectionIndexTitlesArray
{
	return [NSArray arrayWithArray:totalPersonsKeyArr_];
}




#pragma mark - Select Choose Method

- (void)allSelected 
{
    isSelectAll_ = YES;
	
}

- (void)reverseSelected
{
    if (isSelectAll_)
    {
		isSelectAll_   = NO;
		isSelectInArr_ = YES;
		[selectIndexArr_ removeAllObjects];
    }
    else
    {
		if (isSelectInArr_ &&  0==[selectIndexArr_ count])
		{
			//not object select 's revert is selectAll
			isSelectAll_ = YES ;
		}
		else
		{
			isSelectInArr_ = !isSelectInArr_ ;
		}
    }
}

- (void)cancelSelected
{
	isSelectAll_   = NO;
	isSelectInArr_ = YES;
	[selectIndexArr_ removeAllObjects];
}


- (BOOL)isSelectedAtindexpath:(NSIndexPath*)indexPath
{
	if (isSelectAll_)
	{
		return YES;
	}
	else 
	{
		BOOL result = [selectIndexArr_ containsObject:indexPath];
		return isSelectInArr_?result:!result ;
	}
	
	return NO;
}

- (void)setSelectedPerson:(BOOL)isSelected indexpath:(NSIndexPath*)index
{
	NSIndexPath* indexPath = [NSIndexPath indexPathForRow:index.row inSection:index.section];
	
	if (isSelected)
	{
		if (isSelectInArr_)
		{
			[selectIndexArr_ addObject:indexPath];
		}
		else
		{
			[selectIndexArr_ removeObject:indexPath];
		}
	}
	else
	{
		if (isSelectAll_)
		{
			isSelectAll_ = NO;
			isSelectInArr_ = NO;
			[selectIndexArr_ removeAllObjects];
			[selectIndexArr_ addObject:indexPath];
			
		}
		else
		{			
			if (isSelectInArr_)
			{
				[selectIndexArr_ removeObject:indexPath];
			}
			else
			{
				[selectIndexArr_ addObject:indexPath];
			}
		}
	}
}


- (void)saveSelectedPerson
{
	if (isSelectAll_)
    {
		for (NSString* key in self.totalPersonsKeyArr) 
		{
			NSArray* personArr = [self.totalPersonsDict	objectForKey:key];
			for (PKContactPersion* person in personArr)
			{
				[contactEngine_ addToSelGroupWithPerson:person];
			}
		}
    }
    else if (isSelectInArr_)
	{
		for (NSIndexPath* indexPath in selectIndexArr_) 
		{
			NSString* key = objectAtIndex(self.totalPersonsKeyArr, indexPath.section);
			NSArray* personArr = [self.totalPersonsDict objectForKey:key];
			PKContactPersion* person =objectAtIndex(personArr,indexPath.row);
			[contactEngine_ addToSelGroupWithPerson:person];
		}
	}
	else 
	{		
		NSInteger section=0,row=0;
		for (NSString* key in self.totalPersonsKeyArr) 
		{
			row = 0;
			NSArray* personArr = [self.totalPersonsDict	objectForKey:key];
			for (PKContactPersion* person in personArr)
			{
				NSIndexPath* indexPath = [NSIndexPath indexPathForRow:row inSection:section];
				if (![selectIndexArr_ containsObject:indexPath]) 
				{
					[contactEngine_ addToSelGroupWithPerson:person];
				}
				row++;
			}
			section++;
		}
	}
}


#pragma mark - Private Method

- (void)initCandidatePersons
{
	NSMutableDictionary* candidatePersonDict = [[NSMutableDictionary alloc] initWithCapacity:0];
	NSDictionary* totalPersonsDict    = [contactEngine_ getTotalPersonsDictionary];
	NSDictionary* curGroupPersonsDict = [contactEngine_ getPersonsDictionary];
	NSArray* allKeys = [totalPersonsDict allKeys];
	for (NSString* key in allKeys) 
	{
		NSMutableArray* tmpArr1 = [totalPersonsDict	objectForKey:key];
		NSMutableArray* tmpArr2 = [curGroupPersonsDict objectForKey:key];
		NSMutableArray* tmpArr3 = [NSMutableArray arrayWithArray:tmpArr1];
		[tmpArr3 removeObjectsInArray:tmpArr2];
		if ([tmpArr3 count]>0) 
		{
			[candidatePersonDict setObject:[NSArray arrayWithArray:tmpArr3] forKey:key];
		}
	}
	
	if ([candidatePersonDict count]>0) 
	{
		self.totalPersonsDict   = [NSDictionary dictionaryWithDictionary:candidatePersonDict];
		self.totalPersonsKeyArr = [[candidatePersonDict allKeys] sortedArrayUsingSelector:@selector(compare:)];
		if ([self.totalPersonsKeyArr count]>0) 
		{
			NSMutableArray* tmpArr = [NSMutableArray arrayWithArray:self.totalPersonsKeyArr];
			[tmpArr addObject:[tmpArr objectAtIndex:0]];
			[tmpArr removeObjectAtIndex:0];
			self.totalPersonsKeyArr = [NSArray arrayWithArray:tmpArr];
		}
	}
	[candidatePersonDict	release];
}

@end
