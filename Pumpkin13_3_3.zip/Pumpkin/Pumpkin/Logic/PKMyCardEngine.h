//
//  PKMyCardEngine.h
//  Pumpkin
//
//  Created by lv on 6/3/12.
//  Copyright (c) 2012 XXXXX. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PKMyCardSection.h"
#import "PKMyCardRow.h"
#import "PKConst.h"
#import "PKMyCardTemplate.h"
#import "PKNetwork.h"



@class PKMyCardEngine;
@protocol PKMyCardEngineProtocol <NSObject>
@optional
- (void)myCardEngine:(PKMyCardEngine*)myCardEngine uploadMyCard:(BOOL)isSuccess errorCode:(NSInteger)errCode;
- (void)myCardEngine:(PKMyCardEngine*)myCardEngine uploadAvatar:(BOOL)isSuccess errorCode:(NSInteger)errCode;

@end

@interface PKMyCardEngine : NSObject <PKMyCardTemplateDelegate,PKNetworkProtocol>
{
	NSMutableArray*			sectionArr_;
	NSMutableDictionary*	rowItemDict_;
	NSMutableDictionary*	rowTitleDict_;
	NSMutableDictionary*	rowValueDict_;
	NSMutableArray*			candidateSectionArr_;	//可以被添加的字段
	PKMyCardTemplate*		myCardTemplate_;
	NSString*				templateName_;
	NSInteger				selTemplateIndex_;
	PKNetwork*				netWorkEngine_;
	id<PKMyCardEngineProtocol>	delegate_;
	
	UIImage*				selAvatarImage_;

}
@property(nonatomic,assign) id<PKMyCardEngineProtocol>	delegate;
@property(nonatomic,readonly)NSMutableArray*	sectionArr;
@property(nonatomic,readonly)PKMyCardTemplate*  myCardTemplate;
@property(nonatomic,assign)	NSInteger	selTemplateIndex;

- (NSInteger)numberOfSection;
- (NSInteger)numberOfRowsInSection:(NSInteger)section;

- (PKMyCardSection*)sectionOfIndex:(NSInteger)index;
- (PKMyCardRow*)rowOfSectionIndex:(NSInteger)section rowIndex:(NSInteger)row;
- (UIKeyboardType)keyBoardTypeOfSectionIndex:(NSInteger)section rowIndex:(NSInteger)row;

- (NSInteger)numberOfCandidateSection;
- (PKMyCardRow*)firstRowOfCandidateSectionIndex:(NSInteger)index;
- (void)selectCandidateSectionIndex:(NSInteger)index;

- (void)saveAvatarImage:(UIImage*)image;
- (void)saveMyCardEdit;
- (void)cancelMyCardEdit;
//上传完成后保存选中模板
- (void)saveTemplateName:(NSString*)templateName;
//取消还未上传服务器的模板选择
- (void)cancelTemplateSelected;
//首次登录后需要重新载入信息
- (void)reloadPersonInfoIfNeed;
@end
