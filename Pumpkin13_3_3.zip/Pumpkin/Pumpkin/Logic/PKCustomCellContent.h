//
//  PKCustomCellContent.h
//  Pumpkin
//
//  Created by lv on 3/3/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface PKCustomCellContent : NSObject {
    UIImage*	image_;
	NSString*   text_;
}
@property(nonatomic, retain) UIImage* image;
@property(nonatomic, retain) NSString* text;

+ (id)cusCellContentWithImage:(UIImage*)image text:(NSString*)text;

@end
