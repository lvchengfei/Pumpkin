//
//  PKMyCardTemplate.h
//  Pumpkin
//
//  Created by lv on 7/1/12.
//  Copyright (c) 2012 XXX. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PKConst.h"
#import "PKUtils.h"
#import "PKNetwork.h"

@protocol PKMyCardTemplateDelegate <NSObject>
@required
- (id)valueOfMyCardRow:(PKMyCardRowItem)item;

@end
@class PKMyCardTemplate;
@protocol PKMyCardTemplateUpdateProtocol <NSObject>
@optional
- (void)cardTemplate:(PKMyCardTemplate*)cardTemplate updateTemplate:(BOOL)isSuccess errorCode:(NSInteger)errCode;

@end

@interface PKMyCardTemplate : NSObject<PKNetworkProtocol>
{
	NSString*   initTemplateName_;
	NSString*	selTemplateName_;
	NSArray*	displayMyCardItems_;	//titleRectArray_、valueRectArray_中的元素顺序要和displayMyCardItems_中元素一致
	NSArray*	titleRectArray_;
	NSArray*	valueRectArray_;
	UITextAlignment	 valueTextAlignment_;
	id <PKMyCardTemplateDelegate>			delegate_;
	id <PKMyCardTemplateUpdateProtocol>		updateDelegate_;
	PKNetwork*	netWorkEngine_;
	NSString*	templateNameNew_;

}
@property(nonatomic,assign) id <PKMyCardTemplateDelegate> delegate;
@property(nonatomic,assign) id <PKMyCardTemplateUpdateProtocol> updateDelegate;

@property(nonatomic,retain) NSString*   selTemplateName;
@property(nonatomic,retain) NSString*	account;
@property(nonatomic,retain) NSString*	passWord;

//- (id)initWithTemplateName:(NSString*)templateName;
- (NSInteger)numberOfDisplayMyCardItems;
- (NSString*)titleOfDisplayMyCardItems:(NSInteger)index;
- (UIFont*)valueFontOfDisplayMyCardItems:(NSInteger)index;
- (UIColor*)valueFontColorOfDisplayMyCardItems:(NSInteger)index;
- (UITextAlignment)valueTextAlignmentOfDisplayMyCardItems:(NSInteger)index;
- (id)valueOfDisplayMyCardItems:(NSInteger)index;
- (CGRect)titleRectOfDisplayMyCardItems:(NSInteger)index;
- (CGRect)valueRectOfDisplayMyCardItems:(NSInteger)index;
- (PKMyCardRowItem)tagOfDisplayMyCardItems:(NSInteger)index;

- (void)updateWithTemplateName:(NSString*)templateName;
- (BOOL)saveSelectedTemplate;
@end
