//
//  PKDialAnimation.m
//  Pumpkin
//
//  Created by lv on 6/10/12.
//  Copyright (c) 2012 XXXXX. All rights reserved.
//

#import "PKDialAnimation.h"
#import "PKConst.h"
#import "PKJSONKit.h"
#import "PKPathUtil.h"
#import "PKUtils.h"
#import "PKDefine.h"




static  NSString* kAnimationItemTitle				= @"KAMTitle";
static  NSString* kAnimationItemType				= @"kAMType";
static  NSString* kAnimationItemImageName			= @"kAMImageName";
static  NSString* kAnimationItemSn					= @"kAMSN";

@implementation PKAnimationItem
@synthesize title = title_;
@synthesize type  = type_;
@synthesize sn = sn_;
@synthesize imageName  = imageName_;
@synthesize smallImage = smallImage_;
@synthesize largeImage = largeImage_;

- (void)dealloc
{
	[title_			release];
	[type_			release];
	[sn_			release];
	[imageName_		release];
	[smallImage_	release];
	[largeImage_	release];
	[super dealloc];
}


- (void)encodeWithCoder:(NSCoder *)aCoder
{
	[aCoder encodeObject:self.title		forKey:kAnimationItemTitle];
	[aCoder encodeObject:self.type		forKey:kAnimationItemType];
	[aCoder encodeObject:self.imageName forKey:kAnimationItemImageName];
	[aCoder encodeObject:self.sn		forKey:kAnimationItemSn];
}
- (id)initWithCoder:(NSCoder *)aDecoder
{
	self = [super init];
	if (self) 
	{
		self.title = [aDecoder decodeObjectForKey:kAnimationItemTitle];
		self.type  = [aDecoder decodeObjectForKey:kAnimationItemType];
		self.sn    = [aDecoder decodeObjectForKey:kAnimationItemSn];
		self.imageName  = [aDecoder decodeObjectForKey:kAnimationItemImageName];
		self.largeImage = [PKUtils animationImageWithName:self.imageName];
		NSString* smallImageName = [[self.imageName stringByDeletingPathExtension] stringByAppendingString:@"_s.gif"];
		self.smallImage = [PKUtils animationImageWithName:smallImageName];
		self.smallImage = self.smallImage==nil?self.largeImage:self.smallImage;
	}
	return self;
}

- (NSString *)description
{
	NSMutableString* des = [NSMutableString stringWithCapacity:0];
	[des appendFormat:@"\n|---------PKAnimationItem-------|\n"];
	[des appendFormat:@"|title=%@\n",self.title];
	[des appendFormat:@"|type=%@\n",self.type];
	[des appendFormat:@"|imageName=%@\n",self.imageName];
	[des appendFormat:@"|sn=%@\n",self.sn];
	[des appendFormat:@"\n|-------------------------------|\n"];

	return des;
}
@end

@interface PKDialAnimation ()
@property(nonatomic,retain)NSMutableArray* curAnimationArr;
@property(nonatomic,retain)NSArray* updateAnimationArr;

- (void)copyDefaultDialAnimation;
- (void)loadCurrentAnimation;
- (void)updateAnimationFromSever;

@end

@implementation PKDialAnimation
@synthesize curAnimationArr = curAnimationArr_;
@synthesize updateAnimationArr = updateAnimationArr_;
@synthesize delegate = delegate_;

- (id)init
{
	self = [super init];
	if (self) {
		netWorkEngine_ = [[PKNetwork alloc] init];
		netWorkEngine_.delegate = self;
		curAnimationArr_ = [[NSMutableArray alloc] initWithCapacity:0];
		[self copyDefaultDialAnimation];
		[self loadCurrentAnimation];
	}
	return self;
}

- (void)dealloc
{
	[[self class] cancelPreviousPerformRequestsWithTarget:self];
	delegate_ = nil;
	[netWorkEngine_				cancelConnection];
	[netWorkEngine_				release];
	[curAnimationArr_			release];
	[updateAnimationArr_		release];
	[super dealloc];
}


#pragma mark - Public Method

- (void)updateAnimationNumbers
{
	NSMutableString* allSN = [NSMutableString stringWithCapacity:0];
	for (PKAnimationItem* item in self.curAnimationArr)
	{
		[allSN appendString:item.sn];
		[allSN appendString:@"~ng~"];
	}
	NSString* currentAnimation = allSN;
	currentAnimation = currentAnimation?currentAnimation:@"empty";
	NSString* URLStr  = [NSString stringWithFormat:@"checkNewAnimation.action?crtAns=%@",currentAnimation];
	NSString* URLPath = [kMaikeSeverURL stringByAppendingPathComponent:URLStr];
	NSURLRequest* urlRequest = [[NSURLRequest alloc] initWithURL:[NSURL URLWithString:URLPath]];
	netWorkEngine_.tag = 0; 
	netWorkEngine_.timeOutInterval = kUpdateAnimationTimeOut;
	[netWorkEngine_ startConnectionWithURLRequest:urlRequest synchronise:NO];
	[urlRequest	release];
}

- (NSInteger)numberOfAnimationSections
{
	return 1;
}

- (NSInteger)numberOfRowsInAnimationSection:(NSInteger)section
{
	return [self.curAnimationArr count];
}

- (NSString*)titleOfAnimationSection:(NSInteger)section
{
	return nil;
}

- (NSString*)titleOfAnimationSection:(NSInteger)section row:(NSInteger)row
{
	PKAnimationItem* item =  objectAtIndex(self.curAnimationArr, row);
	return item.title;
}

- (UIImage*)smallImageOfAnimationSection:(NSInteger)section row:(NSInteger)row
{
	PKAnimationItem* item =  objectAtIndex(self.curAnimationArr, row);
	return item.smallImage;
}

- (UIImage*)largeImageOfAnimationSection:(NSInteger)section row:(NSInteger)row
{
	PKAnimationItem* item =  objectAtIndex(self.curAnimationArr, row);
	return item.largeImage;
}

- (NSString*)imageNameOfAnimationSection:(NSInteger)section row:(NSInteger)row
{
	PKAnimationItem* item =  objectAtIndex(self.curAnimationArr, row);
	return item.imageName;
}

- (NSString*)detailTitleOfAnimationSection:(NSInteger)section row:(NSInteger)row
{
	PKAnimationItem* item =  objectAtIndex(self.curAnimationArr, row);
	NSString* detailTitle = [[PKUtils dialAnimationTypeMapTitleDictionary] objectForKey:item.type];
	detailTitle = detailTitle==nil?@"默认系列":detailTitle;
	return detailTitle;
}

- (NSString*)snOfAnimationSection:(NSInteger)section row:(NSInteger)row
{
	PKAnimationItem* item =  objectAtIndex(self.curAnimationArr, row);
	return item.sn;
}

//- (PKAnimationItem*)animationItemOfAnimationSection:(NSInteger)section row:(NSInteger)row
//{
//	PKAnimationItem* item =  objectAtIndex(self.curAnimationArr, row);
//	return item;
//}

#pragma mark - Private Method

- (void)copyDefaultDialAnimation
{
	NSString* srcPath = [[[NSBundle mainBundle] resourcePath]	stringByAppendingPathComponent:@"Image/dailAnimation"];
	NSString* dstPath = [PKPathUtil dialAnimationPath];
	if ([[NSFileManager defaultManager] fileExistsAtPath:dstPath]==NO)
	{
		[[NSFileManager defaultManager] copyItemAtPath:srcPath toPath:dstPath error:nil];
	}
}

- (void)loadCurrentAnimation
{
	NSArray* animationArr = [NSKeyedUnarchiver unarchiveObjectWithFile:[PKPathUtil dialAnimationArchiverPath]];
	[self.curAnimationArr removeAllObjects];
	[self.curAnimationArr addObjectsFromArray:animationArr];
	//如果第一次启动，则拷贝默认的来电动画
	if ([self.curAnimationArr count]==0) 
	{
		NSInteger count = [kDefaultDialAnimationArray count];
		NSMutableArray* itemArr = [NSMutableArray arrayWithCapacity:0];
		for (NSInteger i=0;i<count;i++) 
		{
			PKAnimationItem* item = [[PKAnimationItem alloc] init];
			item.title = [kDefaultDialAnimationTitleArray objectAtIndex:i];
			item.type  = [kDefaultDialAnimationTypeArray  objectAtIndex:i];
			item.sn    = [kDefaultDialAnimationArray      objectAtIndex:i];
			item.imageName  = [NSString stringWithFormat:@"callshow_%d.gif",i];
			item.largeImage = [PKUtils animationImageWithName:item.imageName];
			item.smallImage = [PKUtils animationImageWithName:[NSString stringWithFormat:@"callshow_%d_s.gif",i]];
			[itemArr addObject:item];
			[item		release];
		}
		[self.curAnimationArr addObjectsFromArray:itemArr];
		[NSKeyedArchiver archiveRootObject:self.curAnimationArr toFile:[PKPathUtil dialAnimationArchiverPath]];
	}
	
}

- (void)updateAnimationFromSever
{
	curUpdateIndex_ = 0 ;
	for (NSDictionary* animation in self.updateAnimationArr)
	{
		isRuning_ = YES;
		NSString* dir  = [animation objectForKey:kAnimationDirectory];
		NSString* path = [animation objectForKey:kAnimationPath];
		NSString* URLStr  = [NSString stringWithFormat:@"%@/%@",dir,path];
		NSString* URLPath = [kMaikeSeverDownloadURL stringByAppendingPathComponent:URLStr];
		NSURLRequest* urlRequest = [[NSURLRequest alloc] initWithURL:[NSURL URLWithString:URLPath]];
		netWorkEngine_.tag  = 1;
		netWorkEngine_.flag = path; 
		netWorkEngine_.timeOutInterval = kDefaultTimeOut;
		[netWorkEngine_ startConnectionWithURLRequest:urlRequest synchronise:NO];
		[urlRequest		release];
		while (isRuning_)
		{
			[[NSRunLoop currentRunLoop] runUntilDate:[NSDate dateWithTimeIntervalSinceNow:0.1]];
		}
		curUpdateIndex_++;
	}
	self.updateAnimationArr = nil;
}

#pragma mark - PKNetworkProtocol Delegate

- (void) network:(PKNetwork*)network responseResult:(id)result
{
	NSData* tmpData = (NSData*)result;
	//check animation list
	if (network.tag==0) 
	{
		NSDictionary* resultDict = [tmpData objectFromJSONData];
		if (resultDict&&[[resultDict allKeys] count]>0) 
		{
			id  result = [resultDict objectForKey:kURLResult];
			if (result&&[result isKindOfClass:[NSArray class]]) 
			{
				self.updateAnimationArr = result;
				//下载新的来电动画
				[self performSelector:@selector(updateAnimationFromSever)];
			}
			else if(result&&[result isKindOfClass:[NSNumber class]]) 
			{
				//NSInteger resultInt = [result integerValue];
				if (delegate_&&[delegate_ respondsToSelector:@selector(dialAnimation:updateAnimation:count:error:)]) 
				{
					[delegate_ dialAnimation:self updateAnimation:YES count:0 error:nil];
				}
			}
		}
	}
	//download animation 
	else if(network.tag==1)
	{
		NSDictionary* dict = objectAtIndex(self.updateAnimationArr , curUpdateIndex_);
		NSString* imageName = [dict objectForKey:kAnimationPath];
		NSString* path = [[PKPathUtil dialAnimationPath] stringByAppendingPathComponent:imageName];
		if([tmpData writeToFile:path atomically:YES])
		{
			PKAnimationItem* item = [[PKAnimationItem alloc] init];
			item.title = [dict objectForKey:kAnimationDescription];
			item.type  = [NSString stringWithFormat:@"animation%d" ,[[dict objectForKey:kAnimationType] integerValue]];
			item.sn    = [dict objectForKey:kAnimationSN];
			item.imageName  = [dict objectForKey:kAnimationPath];
			item.largeImage = [PKUtils animationImageWithName:item.imageName];
			item.smallImage = item.largeImage;
			[self.curAnimationArr addObject:item];
			[item			release];
			
			//At Last I save to the file
			if ((curUpdateIndex_+1)==[self.updateAnimationArr  count]) 
			{
				[NSKeyedArchiver archiveRootObject:self.curAnimationArr toFile:[PKPathUtil dialAnimationArchiverPath]];
				if (delegate_&&[delegate_ respondsToSelector:@selector(dialAnimation:updateAnimation:count:error:)]) 
				{
					[delegate_ dialAnimation:self updateAnimation:YES count:curUpdateIndex_+1 error:nil];
				}
			}
		}

		isRuning_ = NO;
	}

}

- (void) network:(PKNetwork *)network responseError:(PKNetWorkErrorCode)errorCode
{
	isRuning_ = NO;
	if (delegate_&&[delegate_ respondsToSelector:@selector(dialAnimation:updateAnimation:count:error:)])
	{
		NSError* err = [NSError errorWithDomain:@"updateAnErrDomain" code:kNetWorkErr userInfo:nil];
		[delegate_ dialAnimation:self updateAnimation:NO  count:0 error:err];
	}
}

@end
