//
//  PKDialAnimationDetailViewController.h
//  Pumpkin
//
//  Created by lv on 6/13/12.
//  Copyright (c) 2012 XXXXX. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PKDialAnimation.h"

@interface PKDialAnimationDetailViewController : UIViewController
{
	PKDialAnimation*		dialAnimation_;
	UIWebView*				webView_;
	UIButton*				setAniButton_;
	NSString*				imageName_;
	NSString*				sn_;
}
@property(nonatomic,assign)PKDialAnimation* dialAnimation;
@property(nonatomic,retain)NSString* imageName;
@property(nonatomic,retain)NSString* sn;

@end
