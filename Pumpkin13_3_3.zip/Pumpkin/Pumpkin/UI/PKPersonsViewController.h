//
//  PKPersonsViewController.h
//  TestDrag
//
//  Created by lv on 2/26/12.
//  Copyright  All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PKPersonViewLogic.h"

@class PKPersonsViewController;
@class PKContactViewController;
@class PKPersonViewLogic;

@protocol PKPersonsViewControllerDelegate <NSObject>
@required
- (void)PKtouchesBegan:(NSSet *)touches withEvent:(UIEvent *)event;
- (void)PKtouchesMoved:(NSSet *)touches withEvent:(UIEvent *)event;
- (void)PKtouchesEnded:(NSSet *)touches withEvent:(UIEvent *)event;
- (void)PKtouchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event;
- (void)personTableView:(PKPersonsViewController*)personTableView didSelectedPerson:(id)personObject;
- (void)personTableView:(PKPersonsViewController*)personTableView didSelectedAddMember:(id)object;
- (void)startSearchContactPerson;
- (void)stopSearchContactPerson;

@end



@interface PKPersonsViewController : UIViewController <UITableViewDelegate,UITableViewDataSource,UISearchBarDelegate,UISearchDisplayDelegate> 
{
	UITableView*				tableView_;
	PKPersonViewLogic*			logicEngine_;
	id <PKPersonsViewControllerDelegate> ctlDelegate_;
	UISearchBar*				searchBar_;
	UISearchDisplayController*  searchController_;
	UIImage*					addImage_;
	
	struct{
		unsigned int delegateDidSelectedPerson:1;
		unsigned int delegateDidSelectedAddMember:1;
		unsigned int delegateStartSearchContactPerson:1;
		unsigned int delegateStopSearchContactPerson:1;
		unsigned int delegatePKtouchesBegan:1;
		unsigned int delegatePKtouchesMoved:1;
		unsigned int delegatePKtouchesEnded:1;
		unsigned int delegatePKtouchesCancelled:1;
		//unsigned int __RESERVERED__:24;
	}flags_;
}

@property(nonatomic,readonly)id <PKPersonsViewControllerDelegate> ctlDelegate;
@property(nonatomic,readonly)UITableView*				tableView;

- (id)initWithDelegate:(id <PKPersonsViewControllerDelegate>) ctlDelegate;
- (void)setTableViewFrame:(CGRect)frame;

- (void)reloadWithContactData;
- (PKContactPersion*)personRecordAtIndexPath:(NSIndexPath*)indexPath;
@end

DEBUGCATEGROY(PKPersonsViewController)
