//
//  PKRegisterViewController.m
//  Pumpkin
//
//  Created by lv on 6/3/12.
//  Copyright (c) 2012 XXXXX. All rights reserved.
//

#import "PKRegisterViewController.h"
#import <QuartzCore/QuartzCore.h>
#import "PKUIConst.h"
#import "PKUtils.h"
#import "PKProtocalViewController.h"
#import "PKLogicEngine.h"
#import "PKToastView.h"


#define kSeprateSpace	10
#define kCellHiehgt		50
#define kFontSize		22
#define kCheckBoxWith	27

enum
{
	kAccountTextField,
	kPassWordTextField,
	kAuthorizedTextField,
	kProcotolTextButton,
	kRegisterNowButton,
}PKRegisterCell;

@interface PKRegisterViewController ()
@property(nonatomic,retain)NSArray* cellArr;

- (void)getAuthorizedCodeButtonPressed:(id)sender;
- (void)protocolCheckBoxPressed:(id)sender;
- (void)protocolTextButtonPressed:(id)sender;
- (void)registerNowButtonPressed:(id)sender;
@end

@implementation PKRegisterViewController
@synthesize cellArr = cellArr_;

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) 
	{
		backgroundView_ = [[UIImageView alloc] initWithFrame:CGRectZero];
		backgroundView_.layer.cornerRadius = 6.0;
		backgroundView_.layer.masksToBounds = YES;
		backgroundView_.backgroundColor = kBackgroundColor;
		accountTextField_	= [[UITextField alloc] initWithFrame:CGRectZero];
		passWordTextField_	= [[UITextField alloc] initWithFrame:CGRectZero];
		authorizeTextField_ = [[UITextField alloc] initWithFrame:CGRectZero];
		accountTextField_.placeholder   = NSLocalizedString(@"kAccountTextFieldPlaceHolder", nil);
		passWordTextField_.placeholder  = NSLocalizedString(@"kPasswordTextFieldPlaceHolder", nil);
		authorizeTextField_.placeholder = NSLocalizedString(@"kAuthorizedTextFieldPlaceHolder", nil);
		accountTextField_.contentVerticalAlignment   = UIControlContentVerticalAlignmentCenter;
		passWordTextField_.contentVerticalAlignment  = UIControlContentVerticalAlignmentCenter;
		authorizeTextField_.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
		accountTextField_.borderStyle   = UITextBorderStyleRoundedRect;
		passWordTextField_.borderStyle  = UITextBorderStyleRoundedRect;
		authorizeTextField_.borderStyle = UITextBorderStyleRoundedRect;
		accountTextField_.font   = [UIFont systemFontOfSize:kFontSize];
		passWordTextField_.font  = [UIFont systemFontOfSize:kFontSize];
		authorizeTextField_.font = [UIFont systemFontOfSize:kFontSize];
		accountTextField_.keyboardType  = UIKeyboardTypeNumberPad;
		passWordTextField_.keyboardType = UIKeyboardTypeASCIICapable;
		authorizeTextField_.keyboardType= UIKeyboardTypeNumberPad;
		[passWordTextField_ setSecureTextEntry:YES];
	
		getAuthoCodeButton_  = [[UIButton buttonWithType:UIButtonTypeCustom] retain];
		registerNowButton_   = [[UIButton buttonWithType:UIButtonTypeCustom] retain];
		protocolCheckButton_ = [[UIButton buttonWithType:UIButtonTypeCustom] retain];
		protocolTextButton_  = [[UIButton buttonWithType:UIButtonTypeCustom] retain];


		UIImage* norImage = [PKUtils commonImageWithName:@"login_button_normal.png"];
		norImage = [norImage stretchableImageWithLeftCapWidth:10 topCapHeight:10];
		UIImage* highLightImage = [PKUtils commonImageWithName:@"login_button_pressed.png"];
		highLightImage = [highLightImage stretchableImageWithLeftCapWidth:10 topCapHeight:10];
		normalImage_   = [[PKUtils commonImageWithName:@"ico_checkbox.png"] retain];
		selectedImage_ = [[PKUtils commonImageWithName:@"ico_choose.png"] retain];
		[getAuthoCodeButton_ setBackgroundImage:norImage   forState:UIControlStateNormal];
		[getAuthoCodeButton_ setBackgroundImage:highLightImage forState:UIControlStateHighlighted];
		[registerNowButton_  setBackgroundImage:norImage   forState:UIControlStateNormal];
		[registerNowButton_  setBackgroundImage:highLightImage forState:UIControlStateHighlighted];
		[getAuthoCodeButton_ setTitle:NSLocalizedString(@"kGetAuthorizedCode", nil) forState:UIControlStateNormal];
		[registerNowButton_  setTitle:NSLocalizedString(@"kRegisterNow", nil) forState:UIControlStateNormal];
		[protocolTextButton_ setTitle:NSLocalizedString(@"kProcotolText2", nil) forState:UIControlStateNormal];
		[protocolTextButton_ setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
		protocolTextButton_.titleLabel.font = [UIFont systemFontOfSize:16];
		protocolTextLabel_ = [[UILabel alloc] initWithFrame:CGRectZero];
		protocolTextLabel_.text = NSLocalizedString(@"kProcotolText1", nil);
		protocolTextLabel_.font = [UIFont systemFontOfSize:16];
		protocolTextLabel_.textColor = [UIColor grayColor];
		protocolTextLabel_.backgroundColor = [UIColor clearColor];
		
		[getAuthoCodeButton_ addTarget:self action:@selector(getAuthorizedCodeButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
		[protocolCheckButton_ addTarget:self action:@selector(protocolCheckBoxPressed:) forControlEvents:UIControlEventTouchUpInside];
		[protocolTextButton_ addTarget:self action:@selector(protocolTextButtonPressed:) forControlEvents:UIControlEventTouchUpInside];

		[registerNowButton_ addTarget:self action:@selector(registerNowButtonPressed:) forControlEvents:UIControlEventTouchUpInside];

		accountManager_ = [[PKLogicEngine sharedInstance] getBusinessInstance:@"PKAccountManager"];
		accountManager_.delegate = self;

	}
	return self;
}

- (void)dealloc
{
	accountManager_ = nil;
	accountManager_.delegate = nil;
	[accountTextField_		release];
	[passWordTextField_		release];
	[authorizeTextField_	release];
	[getAuthoCodeButton_	release];
	[registerNowButton_		release];
	[protocolCheckButton_	release];
	[protocolTextButton_	release];
	[protocolTextLabel_		release];
	[backgroundView_		release];
	[normalImage_			release];
	[selectedImage_			release];
	[super dealloc];
}

- (void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	self.navigationController.navigationBarHidden = NO;
	self.navigationController.navigationBar.tintColor = kNaviCtlColor;
}
- (void)viewDidLoad
{
    [super viewDidLoad];
	self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;//do not work when group style
	self.tableView.separatorColor = [UIColor clearColor];
	self.title = NSLocalizedString(@"kNewUserRegister", nil);
	self.view.backgroundColor = [UIColor whiteColor];//kBackgroundColor;
	self.cellArr = [NSArray arrayWithObjects:
				[NSNumber numberWithInteger:kAccountTextField],
				[NSNumber numberWithInteger:kPassWordTextField],
				[NSNumber numberWithInteger:kAuthorizedTextField],
				[NSNumber numberWithInteger:kProcotolTextButton],
				[NSNumber numberWithInteger:kRegisterNowButton],nil];
	UIView* view = [[UIView alloc] initWithFrame:CGRectZero];
	self.tableView.backgroundView = view;
	[view	release];
	[self.tableView.backgroundView addSubview:backgroundView_];
	[backgroundView_ setFrame:CGRectMake(kSeprateSpace,kSeprateSpace, 300, 380)];
	isConfirmProtocol_ = YES;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	return [cellArr_ count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	NSArray* tmpCellIdentifier = [NSArray arrayWithObjects:@"account",@"password",@"authorize",@"protocol",@"register", nil];
	UITableViewCell *cell = nil;	
	NSString* identifier = [tmpCellIdentifier objectAtIndex:indexPath.row];
	cell = [self.tableView dequeueReusableCellWithIdentifier:identifier];
	if (cell==nil) {
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier] autorelease];
	}
	switch (indexPath.row) 
	{
		case kAccountTextField:
			[cell.contentView   addSubview:accountTextField_];
			[accountTextField_	setFrame:CGRectMake(kSeprateSpace,kSeprateSpace/2,280, kCellHiehgt-kSeprateSpace)];
			break;
		case kPassWordTextField:
			[cell.contentView addSubview:passWordTextField_];
			[passWordTextField_	setFrame:CGRectMake(kSeprateSpace,kSeprateSpace/2,280, kCellHiehgt-kSeprateSpace)];
			break;
		case kAuthorizedTextField:
			[cell.contentView addSubview:authorizeTextField_];
			[cell.contentView addSubview:getAuthoCodeButton_];
			[authorizeTextField_	setFrame:CGRectMake(kSeprateSpace,kSeprateSpace/2,170,kCellHiehgt-kSeprateSpace)];
			[getAuthoCodeButton_	setFrame:CGRectMake(2*kSeprateSpace+170,kSeprateSpace/2,100,kCellHiehgt-kSeprateSpace)];
			break;
		case kProcotolTextButton:
			[cell.contentView addSubview:protocolCheckButton_];
			[cell.contentView addSubview:protocolTextLabel_];
			[cell.contentView addSubview:protocolTextButton_];
			UIImage* image = isConfirmProtocol_?selectedImage_:normalImage_;
			[protocolCheckButton_   setBackgroundImage:image   forState:UIControlStateNormal];
			[protocolCheckButton_	setFrame:CGRectMake(kSeprateSpace,(kCellHiehgt-kCheckBoxWith)/2,kCheckBoxWith,kCheckBoxWith)];
			[protocolTextLabel_		setFrame:CGRectMake(kCheckBoxWith+kSeprateSpace,kSeprateSpace/2,100,kCellHiehgt-kSeprateSpace)];
			[protocolTextButton_	setFrame:CGRectMake(kCheckBoxWith+kSeprateSpace+100,kSeprateSpace/2,150,kCellHiehgt-kSeprateSpace)];
			break;
		case kRegisterNowButton:
			[cell.contentView addSubview:registerNowButton_];
			[registerNowButton_	setFrame:CGRectMake(kSeprateSpace,kSeprateSpace/2,280, kCellHiehgt-kSeprateSpace)];
			break;
		default:
			break;
	}
	cell.backgroundColor = [UIColor clearColor];
	cell.selectionStyle  = UITableViewCellSelectionStyleNone;
    return cell;
}

#pragma mark - Table view delegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	return kCellHiehgt;
}


#pragma mark - UIButton Action Event

- (void)getAuthorizedCodeButtonPressed:(id)sender
{
	NSString* account = accountTextField_.text;
	if ([account length]!=11)
	{
		PKALERTVIEW(nil, NSLocalizedString(@"kAccountCannotEmpty", nil), nil,NSLocalizedString(@"kOK", nil) ,nil,nil);
	}
	else 
	{
		[accountTextField_		resignFirstResponder];
		[passWordTextField_		resignFirstResponder];
		[authorizeTextField_	resignFirstResponder];
		if ([PKUtils isNetWorkAvailable])
		{
			[PKToastView showWithTitle:@"正在发送中" animation:YES];
			[accountManager_ getAuthorizedCode:accountTextField_.text];
		}
	}
}

- (void)protocolCheckBoxPressed:(id)sender
{
	isConfirmProtocol_ = !isConfirmProtocol_;
	UIImage* image = isConfirmProtocol_?selectedImage_:normalImage_;
	[protocolCheckButton_ setBackgroundImage:image   forState:UIControlStateNormal];

	//NSIndexPath* indexPath = [NSIndexPath indexPathForRow:kProcotolTextButton inSection:0];
	//[self.tableView cellForRowAtIndexPath:indexPath].imageView.image = image;
}

- (void)protocolTextButtonPressed:(id)sender
{
	PKProtocalViewController* protocolViewCtl = [[PKProtocalViewController alloc] init];
	[self.navigationController pushViewController:protocolViewCtl animated:YES];
	[protocolViewCtl	release];
}

- (void)registerNowButtonPressed:(id)sender
{
	if (isConfirmProtocol_==NO) 
	{
		UIAlertView *tmpAlertView = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"kProtocolDisAgreeError", nil) 
															   message:nil 
															  delegate:self 
													 cancelButtonTitle:NSLocalizedString(@"kOK", nil) 
													 otherButtonTitles:nil];
		[tmpAlertView show];
		[tmpAlertView release];
		return;
	}
	NSString* userNameStr = accountTextField_.text;
	NSString* passwordStr = passWordTextField_.text;
	NSString* authCode    = authorizeTextField_.text;
	[accountTextField_		resignFirstResponder];
	[passWordTextField_		resignFirstResponder];
	[authorizeTextField_	resignFirstResponder];
	userNameStr = [userNameStr stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] ;
	
	if ([PKUtils isValidatePhoneNumber:userNameStr]==NO)
	{
		PKALERTVIEW(nil,@"请确认用户名正确！" , nil,NSLocalizedString(@"kOK", nil) ,nil,nil);
		return;
	}
	NSInteger passwordValidate = [PKUtils isValidatePassWord:passwordStr];
	if (passwordValidate!=0)
	{
		NSString* title = passwordValidate==1?@"密码位数须4位以上!":@"密码必须是字母和数字组合！";
		PKALERTVIEW(nil,title, nil,NSLocalizedString(@"kOK", nil) ,nil,nil);
		return;
	}
	
	
	if (authCode && [authCode length]>0) 
	{
		
		
		
		//[self addToKeyChain:userNameStr password:passwordStr];
		
		//		UIAlertView *tmpAlertView = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"kLogIning", nil) 
		//															   message:nil 
		//															  delegate:self 
		//													 cancelButtonTitle:NSLocalizedString(@"kCancel", nil) 
		//													 otherButtonTitles:nil];
		//		self.alertView = tmpAlertView;
		//		[tmpAlertView show];
		//		[tmpAlertView release];
		
		if ([PKUtils isNetWorkAvailable])
		{
			[PKToastView showWithTitle:@"正在上传中" animation:YES];
			accountManager_.delegate = self;
			[accountManager_  registerWithAccount:userNameStr password:passwordStr auth:authCode];
		}
	} 
	else if (userNameStr==nil || [userNameStr length]==0) 
	{
		
		PKALERTVIEW(nil, NSLocalizedString(@"kAccountCannotEmpty", nil) , nil,NSLocalizedString(@"kOK", nil) ,nil,nil);
	} 
	else if (passwordStr==nil || [passwordStr length]==0) 
	{
		PKALERTVIEW(nil, NSLocalizedString(@"kPassWordCannotEmpty", nil) , nil,NSLocalizedString(@"kOK", nil) ,nil,nil);
	}
	else if (authCode==nil || [authCode length]==0) 
	{
		PKALERTVIEW(nil, NSLocalizedString(@"kAuthCodeError", nil) , nil,NSLocalizedString(@"kOK", nil) ,nil,nil);
	}
	else 
	{
		PKALERTVIEW(nil,@"请确认用户名和验证码是否正确填写！" , nil,NSLocalizedString(@"kOK", nil) ,nil,nil);

	}
}

#pragma mark - UIAlertView Delegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	if (alertView.tag==0x0f) 
	{
		[[[UIApplication sharedApplication] delegate] performSelector:@selector(showTabBarController)];
	}
}
#pragma mark - PKAccountManagerProtocol

- (void)accountManager:(PKAccountManager*)accountManager getAuthCode:(BOOL)isSuccess errorCode:(PKAccountErrorCode)errCode
{
	[PKToastView dismissWithAnimation:YES];
	if (isSuccess) 
	{
		PKALERTVIEW(self, NSLocalizedString(@"kHaveSendAuthCode", nil) , nil,NSLocalizedString(@"kOK", nil) ,nil,nil);
	}
	else 
	{
		PKALERTVIEW(self, NSLocalizedString(@"kGetAuthCodeError", nil) , nil,NSLocalizedString(@"kOK", nil) ,nil,nil);
	}
}

- (void)accountManager:(PKAccountManager*)accountManager registerAccount:(BOOL)isSuccess errorCode:(PKAccountErrorCode)errCode
{
	[PKToastView dismissWithAnimation:YES];
	if (isSuccess) 
	{
		[[[UIApplication sharedApplication] delegate] performSelector:@selector(showTabBarController)];
//		UIAlertView *tmpAlertView = [[UIAlertView alloc] initWithTitle: NSLocalizedString(@"kRegisterSuccess", nil)
//															   message:nil 
//															  delegate:self 
//													 cancelButtonTitle:NSLocalizedString(@"kOK", nil)
//													 otherButtonTitles:nil];
//		tmpAlertView.tag = 0x0f;
//		[tmpAlertView show];
//		[tmpAlertView release];
	}
	else 
	{
		NSString* title =NSLocalizedString(@"kRegisterAuthCodeError", nil);
		title = errCode==PKHaveRegisterErr?NSLocalizedString(@"kRegisterSecondError", nil):title;
		PKALERTVIEW(self,title , nil,NSLocalizedString(@"kOK", nil) ,nil,nil);
	}
}

@end
