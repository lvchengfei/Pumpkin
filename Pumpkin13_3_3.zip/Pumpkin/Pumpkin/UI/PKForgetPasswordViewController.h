//
//  PKForgetPasswordViewController.h
//  Pumpkin
//
//  Created by lv on 11/10/12.
//  Copyright (c) 2012 Baidu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PKForgetPasswordViewController : UIViewController
{
	UIView*		contentView_;
}
@end
