//
//  PKSectionHeadView.m
//  Pumpkin
//
//  Created by lv on 3/17/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import "PKSectionHeadView.h"

#define kContentHeight 40
#define kLableWidth  150
#define kButtonWidth 25
#define KMargin	2


@interface PKSectionHeadView()
@property(nonatomic, retain) id <PKSectionHeadViewDelegate> delegate;
- (void)toggleChangeStatus:(id)sender;
@end

@implementation PKSectionHeadView
@synthesize delegate = delegate_;

-(id)initWithFrame:(CGRect)frame title:(NSString*)title section:(NSInteger)section delegate:(id <PKSectionHeadViewDelegate>)delegate
{
    self = [super initWithFrame:frame];
    if (self) {
		
		self.delegate = delegate ;
		sectionIndex_ = section ;

		CGFloat offsetY = (frame.size.height-kContentHeight)>0?(frame.size.height-kContentHeight)/2:0;
		CGRect buttonRect = CGRectMake(KMargin, offsetY, kButtonWidth, kContentHeight);
		CGRect labelRect  = CGRectMake(2*KMargin+kButtonWidth, offsetY, kLableWidth, kContentHeight);
		
		disclosureButton_ = [[UIButton buttonWithType:UIButtonTypeCustom] retain];
        disclosureButton_.frame = buttonRect;
        [disclosureButton_ setImage:[UIImage imageNamed:@"carat.png"] forState:UIControlStateNormal];
        [disclosureButton_ setImage:[UIImage imageNamed:@"carat-open.png"] forState:UIControlStateSelected];
        [disclosureButton_ addTarget:self action:@selector(toggleChangeStatus:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:disclosureButton_];

		sectionTitle_ = [[UILabel alloc] initWithFrame:labelRect];
        sectionTitle_.text = title;
        sectionTitle_.font = [UIFont boldSystemFontOfSize:17.0];
        sectionTitle_.textColor = [UIColor blackColor];
        sectionTitle_.backgroundColor = [UIColor clearColor];
        [self addSubview:sectionTitle_];

		self.userInteractionEnabled = YES;
//		// Set up the tap gesture recognizer.
//        UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(toggleChangeStatus:)];
//        [self addGestureRecognizer:tapGesture];
    }
    return self;
}


- (void)dealloc
{
	[sectionTitle_		release];
	[disclosureButton_	release];
    [super dealloc];
}

#pragma mark - Public Method

- (BOOL)status
{
	return disclosureButton_.selected;
}

#pragma mark - Private Method

- (void)toggleChangeStatus:(id)sender
{
	disclosureButton_.selected = !disclosureButton_.selected;
	
	if (disclosureButton_.selected) 
	{
		if ([self.delegate respondsToSelector:@selector(sectionHeaderView:sectionOpened:)]) 
		{
			[self.delegate sectionHeaderView:self sectionOpened:sectionIndex_];
		}
	}
	else
	{
		if ([self.delegate respondsToSelector:@selector(sectionHeaderView:sectionClosed:)]) 
		{
			[self.delegate sectionHeaderView:self sectionClosed:sectionIndex_];
		}
	}
	
}

@end
