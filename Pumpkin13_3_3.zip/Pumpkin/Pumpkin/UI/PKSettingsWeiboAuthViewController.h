//
//  PKSettingsWeiboAuthViewController.h
//  Pumpkin
//
//  Created by lv on 7/14/12.
//  Copyright (c) 2012 XXX. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PKMyCardTableViewCell.h"
#import "PKShareWeiboAuth.h"
#import "WBEngine.h"
#import "OpenSdkOauth.h"
#import "Kaixin.h"

@interface PKSettingsWeiboAuthViewController : UITableViewController<UIWebViewDelegate,PKMyCardTableViewCellDelegate,KaixinSessionDelegate,KaixinRequestDelegate,WBEngineDelegate>
{
	WBEngine*			sinaWeiboEngine_;
	OpenSdkOauth*		tencentWeiboEngine_;
	UIView*				tencentContainerView_;
	Kaixin*				kaixinEngine_;
}
@end
