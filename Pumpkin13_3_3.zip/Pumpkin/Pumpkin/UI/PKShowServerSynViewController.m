//
//  PKShowServerSynViewController.m
//  Pumpkin
//
//  Created by lv on 8/5/12.
//  Copyright (c) 2012 XXX. All rights reserved.
//

#import "PKShowServerSynViewController.h"
#import "PKUIConst.h"
#import "PKMyCardTableViewCell.h"
#import "PKShowStrangerPersonInfoViewController.h"
#import "PKToastView.h"
#import "PKDefine.h"
#import "PKShowAnimationInfoViewController.h"
#import "PKContactEngine.h"


#define kNameLabelTag 10
#define kPhoneLabelTag 11

#define kRequestFriendTableViewRect CGRectMake(0, 0, 320, 100)
#define kRequestFriendTableViewHeight		365


#define kAnimationTitle				@"浮面动画更新"
#define kUpdateFriendTitle			@"好友更新"
#define kRequestFriendTitle			@"好友请求"

@interface PKShowServerSynViewController ()
@property(nonatomic,assign) NSArray* showItemArray;
@property(nonatomic,retain) NSMutableArray* seletedArray;

- (void)showRequestFriendsInfo;
- (void)showUpdateFriendsInfo;
- (void)showUpdateAnimationInfo;
- (void)segmentButtonPressed:(UISegmentedControl*)segmentControl;
- (void)backButtonPressed:(id)sender;
- (void)confirmButtonPressed:(id)sender;
- (void)cancelButtonPressed:(id)sender;

@end

@implementation PKShowServerSynViewController
@synthesize serverSyn = serverSyn_;
@synthesize requestFriendsArray = requestFriendsArray_;
@synthesize updateFriendsArray = updateFriendsArray_;
@synthesize updateAnimationArray = updateAnimationArray_;
@synthesize showItemArray = showItemArray_;
@synthesize seletedArray  = seletedArray_;

- (id)init
{
    self = [super init];
    if (self) {
        // Custom initialization
		NSString* confirmStr =@"确定";
		NSString* cancelStr  =@"取消";
		CGFloat buttonWitdth=130 , buttonHeight=40 , spacSep=30;
		CGFloat leftMargin=(320-buttonWitdth*2-spacSep)/2,topMargin=kRequestFriendTableViewHeight+5;
		CGRect confirmRect = CGRectMake(leftMargin, topMargin, buttonWitdth, buttonHeight);
		CGRect cancelRect = confirmRect;
		cancelRect.origin.x = leftMargin+buttonWitdth+spacSep;

		
		confirmButton_ = [[UIButton buttonWithType:UIButtonTypeCustom] retain];
		UIImage* norImg= [PKUtils commonImageWithName:@"login_button_normal.png"];
		norImg = [norImg stretchableImageWithLeftCapWidth:norImg.size.width/2 topCapHeight:norImg.size.height/2];
		[confirmButton_ setBackgroundImage:norImg   forState:UIControlStateNormal];
		[confirmButton_ setTitle:confirmStr forState:UIControlStateNormal];
		[confirmButton_ setFrame:confirmRect];
		[confirmButton_ addTarget:self action:@selector(confirmButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
		cancelButton_  = [[UIButton buttonWithType:UIButtonTypeCustom] retain];
		[cancelButton_	setBackgroundImage:norImg forState:UIControlStateNormal];
		[cancelButton_ setTitle:cancelStr forState:UIControlStateNormal];
		[cancelButton_ setFrame:cancelRect];
		[cancelButton_ addTarget:self action:@selector(cancelButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
		
		tableView_ = [[UITableView alloc] initWithFrame:[UIScreen mainScreen].bounds];
		tableView_.backgroundColor = [UIColor clearColor];
		tableView_.separatorColor  = [UIColor lightGrayColor];
		//self.separatorStyle = UITableViewCellSeparatorStyleNone; 
		tableView_.dataSource = self;
		tableView_.delegate   = self;
		
		seletedArray_ = [[NSMutableArray alloc] initWithCapacity:0];		
		segmentArray_ = [[NSMutableArray alloc] initWithCapacity:0];

		segmentedControl_ = [[UISegmentedControl alloc] initWithItems:nil];  
		segmentedControl_.frame = CGRectMake(80, 0, 160.0, 30.0);
		segmentedControl_.selectedSegmentIndex = 0;
		segmentedControl_.segmentedControlStyle = UISegmentedControlStyleBar;
		[segmentedControl_ addTarget:self action:@selector(segmentButtonPressed:) forControlEvents:UIControlEventValueChanged];
		
    }
    return self;
}


- (void)dealloc
{
    [[self class] cancelPreviousPerformRequestsWithTarget:self];
	[requestFriendsArray_   release];
	[updateFriendsArray_	release];
	[showItemArray_			release];
	[seletedArray_			release];
	[confirmButton_			release];
	[cancelButton_			release];
	[tableView_				release];
	[segmentedControl_		release];
	[segmentArray_			release];
    [super dealloc];
}


- (void)viewDidLoad
{
    [super viewDidLoad];
	self.navigationController.navigationBar.tintColor = kNaviCtlColor;

	UIBarButtonItem* leftButton = [[UIBarButtonItem alloc] initWithTitle:@"返回" style:UIBarButtonItemStyleBordered target:self action:@selector(backButtonPressed:)];
	self.navigationItem.leftBarButtonItem = leftButton;
	
	NSMutableArray* mutArray = [NSMutableArray arrayWithCapacity:0];
	if ([self.updateAnimationArray count]>0)
	{
		[mutArray addObject:kAnimationTitle];
		[self showUpdateAnimationInfo];
	}
	if ([self.updateFriendsArray count]>0)
	{
		[mutArray addObject:kUpdateFriendTitle];
		[self showUpdateFriendsInfo];
	}
	if([self.requestFriendsArray count]>0)
	{
		[mutArray addObject:kRequestFriendTitle];
		[self showRequestFriendsInfo];
	}
	
	[segmentArray_	removeAllObjects];
	if ([mutArray count]>1)
	{
		[segmentedControl_ removeAllSegments];
		for (NSString* title in mutArray)
		{
			[segmentArray_ insertObject:title atIndex:0];
			[segmentedControl_ insertSegmentWithTitle:title atIndex:0 animated:NO];			
		}
		self.navigationItem.titleView = segmentedControl_;
		self.title = @"更新信息";	
	}
	else
	{
		[segmentArray_ addObjectsFromArray:mutArray];
		self.title = objectAtIndex(segmentArray_, 0);	
	}	
	segmentedControl_.selectedSegmentIndex=0;
	currentSeleted_ = 0;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Private Method

- (void)showRequestFriendsInfo
{
	[self.seletedArray removeAllObjects];
	[self.seletedArray setArray:requestFriendsArray_];
	self.showItemArray = requestFriendsArray_;
	[self.view addSubview:tableView_];
	[self.view addSubview:confirmButton_];
	[self.view addSubview:cancelButton_];
	CGRect rect = tableView_.frame;
	rect.size.height = kRequestFriendTableViewHeight;
	[tableView_ setFrame:rect];
	[tableView_ reloadData];
}

- (void)showUpdateFriendsInfo
{
	[self.seletedArray removeAllObjects];
	self.showItemArray = updateFriendsArray_;
	[confirmButton_ removeFromSuperview];
	[cancelButton_	removeFromSuperview];
	[self.view addSubview:tableView_];
	[tableView_ setFrame:[UIScreen mainScreen].bounds];
	[tableView_ reloadData];
}

//好友为我设置的浮面动画列表
- (void)showUpdateAnimationInfo
{
	[self.seletedArray removeAllObjects];
	self.showItemArray = updateAnimationArray_;
	[confirmButton_ removeFromSuperview];
	[cancelButton_	removeFromSuperview];
	[self.view addSubview:tableView_];
	[tableView_ setFrame:[UIScreen mainScreen].bounds];
	[tableView_ reloadData];
}

- (void)backButtonPressed:(id)sender
{
	if ([self respondsToSelector:@selector(dismissModalViewControllerAnimated:)]) {
		[self dismissModalViewControllerAnimated:YES];
	}
	else if ([self respondsToSelector:@selector(dismissViewControllerAnimated:completion:)])
	{
		[self dismissViewControllerAnimated:YES completion:nil];
	}
}

- (void)confirmButtonPressed:(id)sender
{
	[PKToastView showWithTitle:@"正在上传中" animation:YES];
	NSMutableArray* disAgree = [NSMutableArray arrayWithArray:requestFriendsArray_];
	[disAgree removeObjectsInArray:seletedArray_];
	serverSyn_.delegate = self;
	[serverSyn_ setAgreeRequestFriend:seletedArray_ disAgreeRequestFriends:disAgree];
}

- (void)cancelButtonPressed:(id)sender
{
	if ([self respondsToSelector:@selector(dismissModalViewControllerAnimated:)]) {
		[self dismissModalViewControllerAnimated:YES];
	}
	else if ([self respondsToSelector:@selector(dismissViewControllerAnimated:completion:)])
	{
		[self dismissViewControllerAnimated:YES completion:nil];
	}
}

-(void)PKServerSyn:(PKServerSyn*)serverSyn setRequestAddFriends:(BOOL)isSuccess error:(NSError*)error
{
	[PKToastView dismissWithAnimation:YES];
	if (isSuccess) 
	{
		if ([self respondsToSelector:@selector(dismissModalViewControllerAnimated:)]) {
			[self dismissModalViewControllerAnimated:YES];
		}
		else if ([self respondsToSelector:@selector(dismissViewControllerAnimated:completion:)])
		{
			[self dismissViewControllerAnimated:YES completion:nil];
		}
		PKALERTVIEW(nil, @"设置成功！", nil,@"确定",nil,nil);
	}
	else
	{
		PKALERTVIEW(nil, @"更新出错！", nil,@"确定",nil,nil);
	}
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [showItemArray_ count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
	CellIdentifier = currentSeleted_==0?@"cell1":@"cell2";
	PKMyCardTableViewCell* cell = (PKMyCardTableViewCell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	if (cell == nil) {
		cell = [[[PKMyCardTableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:CellIdentifier] autorelease];
		cell.selectionStyle = UITableViewCellSelectionStyleNone;
		UILabel* nameLabel  = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 120,  cell.frame.size.height)];
		UILabel* phoneLabel = [[UILabel alloc] initWithFrame:CGRectMake(120, 0, 200,  cell.frame.size.height)];
		nameLabel.tag = kNameLabelTag;
		phoneLabel.tag = kPhoneLabelTag;
		//nameLabel.textAlignment  = UITextAlignmentCenter;
		//phoneLabel.textAlignment = UITextAlignmentCenter;
		[cell.contentView addSubview:nameLabel];
		[cell.contentView addSubview:phoneLabel];
		[nameLabel	release];
		[phoneLabel	release];
	}
	UILabel* nameLabel  = (UILabel*)[cell.contentView viewWithTag:kNameLabelTag];
	UILabel* phoneLabel = (UILabel*)[cell.contentView viewWithTag:kPhoneLabelTag];
	id object = objectAtIndex(self.showItemArray, indexPath.row);
	NSString* title = objectAtIndex(segmentArray_, currentSeleted_);
	if ([title isEqualToString:kRequestFriendTitle])
	{
		nameLabel.text  = [NSString stringWithFormat:@" %@",[object objectForKey:@"name"]]; 
		phoneLabel.text = [NSString stringWithFormat:@" %@",[object objectForKey:@"mobile"]];
		cell.checked  = [self.seletedArray containsObject:object];
		cell.delegate = self;
		[cell showImageButton:YES];
	}
	else if ([title isEqualToString:kUpdateFriendTitle])
	{
		PKContactPersion* person = (PKContactPersion*)object;
		nameLabel.text  = [NSString stringWithFormat:@" %@",[person fullName]];
		phoneLabel.text = objectAtIndex([person phoneArray], 0);
	}
	else if ([title isEqualToString:kAnimationTitle])
	{
		nameLabel.text  = [NSString stringWithFormat:@" %@",[object objectForKey:@"ownerMobile"]]; 
		phoneLabel.text = [NSString stringWithFormat:@" %@",[object objectForKey:@"description"]];
	}

	cell.section = indexPath.section;
	cell.row = indexPath.row;
    return cell;
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	NSString* title = objectAtIndex(segmentArray_, currentSeleted_);

	if ([title isEqualToString:kRequestFriendTitle])
	{
		PKShowStrangerPersonInfoViewController* viewController = [[PKShowStrangerPersonInfoViewController alloc] initWithStyle:UITableViewStylePlain];
		[viewController setShowPersonInfo: objectAtIndex(self.showItemArray,indexPath.row)];
		[self.navigationController pushViewController:viewController animated:YES];
		[viewController	release];
	}
	else if ([title isEqualToString:kUpdateFriendTitle])
	{
		PKContactPersion* person = objectAtIndex(self.showItemArray, indexPath.row);

		ABPersonViewController *picker = [[[ABPersonViewController alloc] init] autorelease];
		//picker.personViewDelegate = self;
		PKContactEngine* contactEngine = [PKContactEngine sharedContactEngine];
		picker.addressBook = [contactEngine  contactAddressBook];
		picker.displayedPerson = ABAddressBookGetPersonWithRecordID([contactEngine contactAddressBook],person.recordID);
		picker.displayedPerson = person.record;
		NSArray *properties = [NSArray arrayWithObjects:[NSNumber numberWithInt:kABPersonEmailProperty], [NSNumber numberWithInt:kABPersonPhoneProperty],[NSNumber numberWithInt:kABPersonAddressProperty], [NSNumber numberWithInt:kABPersonInstantMessageProperty],[NSNumber numberWithInt:kABPersonURLProperty],[NSNumber numberWithInt:kABPersonOrganizationProperty],[NSNumber numberWithInt:kABPersonDepartmentProperty], [NSNumber numberWithInt:kABPersonBirthdayProperty], [NSNumber numberWithInt:kABPersonNoteProperty],[NSNumber numberWithInt:kABPersonPrefixProperty],[NSNumber numberWithInt:kABPersonSuffixProperty], [NSNumber numberWithInt:kABPersonNicknameProperty],nil ];  
		picker.displayedProperties = properties;
		// Allow users to edit the person’s information
		picker.allowsEditing = YES;
		picker.allowsActions = YES;
		[self.navigationController pushViewController:picker animated:YES];
	}
	else if([title isEqualToString:kAnimationTitle])
	{
		NSDictionary* dict = objectAtIndex(self.showItemArray,indexPath.row);
		PKShowAnimationInfoViewController* viewController = [[PKShowAnimationInfoViewController alloc] init];
		viewController.imageName = [dict objectForKey:kAnimationPath];
		[self.navigationController pushViewController:viewController animated:YES];
		[viewController	release];
	}
}

#pragma mark - PKMyCardTableViewCellDelegate

-(void)tableViewCell:(PKMyCardTableViewCell*)tableViewCell buttonStatusChanged:(BOOL)status
{
	id object = objectAtIndex(self.showItemArray, tableViewCell.row);
	if (!tableViewCell.checked)
	{
		[self.seletedArray removeObject:object];
	}
	else 
	{
		[self.seletedArray addObject:object];
	}
}

#pragma mark - UISegmentedControl Acction 

- (void)segmentButtonPressed:(UISegmentedControl*)segmentControl
{
	currentSeleted_ = segmentControl.selectedSegmentIndex;
	NSString* title = objectAtIndex(segmentArray_, currentSeleted_);
	if ([title isEqualToString:kRequestFriendTitle])
	{
		[self showRequestFriendsInfo];
	}
	else if ([title isEqualToString:kUpdateFriendTitle])
	{
		[self showUpdateFriendsInfo];
	}
	else if([title isEqualToString:kAnimationTitle])
	{
		[self showUpdateAnimationInfo];
	}	
	
}

//#pragma mark ABPersonViewControllerDelegate methods
//// Does not allow users to perform default actions such as dialing a phone number, when they select a contact property.
//- (BOOL)personViewController:(ABPersonViewController *)personViewController shouldPerformDefaultActionForPerson:(ABRecordRef)person property:(ABPropertyID)property identifier:(ABMultiValueIdentifier)identifier
//{
//	return NO;
//}

@end
