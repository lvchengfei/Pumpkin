//
//  PKGroupManagerViewController.m
//  Pumpkin
//
//  Created by lv on 3/2/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import "PKGroupManagerViewController.h"
#import "PKAddGroupViewController.h"

static NSInteger kModifyAlertTag = 100;

@interface PKGroupManagerViewController()
@property(nonatomic, retain) UITextField* groupNameTextField;

- (void)rightButtonPressed:(id)sender;
- (void)modifyGroupName:(NSString*)groupName;

@end

@implementation PKGroupManagerViewController
@synthesize groupNameTextField = groupNameTextField_;

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
		contactEngine_ = [PKContactEngine sharedContactEngine];
    }
    return self;
}

- (void)dealloc
{
	contactEngine_ = nil;
	[groupNameTextField_  release];
    [super dealloc];
}

#pragma mark - View lifecycle

- (void)viewWillAppear:(BOOL)animated
{
	[self.tableView reloadData];
}

- (void)viewWillDisappear:(BOOL)animated
{
	//[PKContactEngine saveAddressBook];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	UIBarButtonItem* rightButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(rightButtonPressed:)];
	self.navigationItem.rightBarButtonItem = rightButton;
	[rightButton release];
		
	self.editing = YES;
	self.tableView.allowsSelectionDuringEditing = YES;
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}



#pragma mark - Private Method

- (void)rightButtonPressed:(id)sender
{
	PKAddGroupViewController* groupAddViewController = [[PKAddGroupViewController alloc] initWithStyle:UITableViewStylePlain];
	UINavigationController* naviViewController = [[UINavigationController alloc] initWithRootViewController:groupAddViewController];
	if ([self respondsToSelector:@selector(presentModalViewController:animated:)]) {
		[self presentModalViewController:naviViewController animated:YES];
	}
	else if ([self respondsToSelector:@selector(presentViewController:animated:completion:)])
	{
		[self presentViewController:naviViewController animated:YES completion:nil];
	}
	[groupAddViewController release];
	[naviViewController		release];
}

- (void)modifyGroupName:(NSString*)groupName
{
	NSString* title   = NSLocalizedString(@"kModifyGroupName", nil); 
	NSString* confirm = NSLocalizedString(@"kOK",nil);
	NSString* cancel  = NSLocalizedString(@"kCancel", nil);
	
	UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title
														message:nil
													   delegate:self 
											  cancelButtonTitle:cancel 
											  otherButtonTitles:confirm, nil];
	alertView.tag = kModifyAlertTag;
	//Y offset
	//	CGAffineTransform mTransform = CGAffineTransformMakeTranslation(0.0, -80.0);
	//	[alertView setTransform:mTransform];
	//[alertView setCenter:CGPointMake(CGRectGetMidX(self.view.frame), CGRectGetMidY(self.view.frame))];
	
	CGRect rectName = CGRectMake(16, 50, 250, 30);
	UITextField *tmpGroupTextField = [[UITextField alloc] initWithFrame:rectName];
	tmpGroupTextField.placeholder = groupName;
	tmpGroupTextField.borderStyle = UITextBorderStyleRoundedRect;
	tmpGroupTextField.font = [UIFont systemFontOfSize:15];
	tmpGroupTextField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
	tmpGroupTextField.delegate = self ;
	tmpGroupTextField.clearsOnBeginEditing = YES;
	self.groupNameTextField = tmpGroupTextField;
	[tmpGroupTextField becomeFirstResponder];
	[tmpGroupTextField release];
	[alertView addSubview:tmpGroupTextField];
	[alertView show];
	[alertView release];
	
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
	return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
     return [contactEngine_ contactGroupsCount];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    }
    
	cell.textLabel.text = [contactEngine_ groupNameOfIndex:indexPath.row];
	cell.showsReorderControl = YES;
    
    return cell;
}



- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
	if (editingStyle == UITableViewCellEditingStyleDelete) 
	{
		[contactEngine_ removeGroupAtIndex:indexPath.row];
		[self.tableView reloadData];
	}
}

// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
	[contactEngine_ moveGroupFromIndex:fromIndexPath.row toIndex:toIndexPath.row];
	[self.tableView reloadData];
}



- (BOOL)tableView:(UITableView *)tableView shouldIndentWhileEditingRowAtIndexPath:(NSIndexPath *)indexPath
{
	return NO;
}


#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	curSelectedIndex_ = indexPath.row;
	[[tableView cellForRowAtIndexPath:indexPath] setSelected:NO animated:YES];
	NSString* groupName = [contactEngine_ groupNameOfIndex:curSelectedIndex_];
	[self modifyGroupName:groupName];
}

#pragma mark - UIAlertViewDelegate

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	if (alertView.tag == kModifyAlertTag) 
	{
		//确定
		if (buttonIndex == 1 && [groupNameTextField_.text length]>0)
		{
			[contactEngine_ modifyGroupName:groupNameTextField_.text atIndex:curSelectedIndex_];
			[self.tableView reloadData];
		}
		
//		if (buttonIndex == 1 && [groupNameTextField_.text length]==0)
//		{
//			NSString* title  = NSLocalizedString(@"kGroupNameEmpty", nil);
//			NSString* confim = NSLocalizedString(@"kOK", nil);
//			UIAlertView* alertView = [[UIAlertView alloc] initWithTitle:title 
//																message:nil 
//															   delegate:self 
//													  cancelButtonTitle:confim 
//													  otherButtonTitles:nil];
//			[alertView show];
//			[alertView release];
//		}
	}
}
@end
