//
//  PKContactViewController.h
//  Pumpkin
//
//  Created by lv on 2/27/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PKPersonsViewController.h"
#import "PKGroupsViewController.h"
#import "PKMovePopView.h"
#import "PKRemovePopView.h"
#import "PKInfoPopView.h"
#import "PKServerSyn.h"
#import "PKTutorialView.h"
#import "PKSettings.h"
#import "PKBadgeView.h"

@interface PKContactViewController : UIViewController <UITabBarControllerDelegate, ABNewPersonViewControllerDelegate , ABPersonViewControllerDelegate,UIAlertViewDelegate, PKGroupsViewControllerDelegate , PKPersonsViewControllerDelegate , PKServerSynDelegate,PKTutorialViewDelegate,PKSettingsDelegate>
{
	PKServerSyn*				serverSyn_;
	NSArray*					requestFriends_;
	NSArray*					updateFriends_;
	NSArray*					animationArray_;
	
	UIImageView*				backgroundView_; 
	PKContactEngine*			contactEngine_;
	PKPersonsViewController*	personsViewController_;
	PKGroupsViewController*		groupViewController_;
	CGRect						groupRect_;
	CGRect						personRect_;
	NSTimer*					longTouchTimer_;
	PKContactPersion*			selPerson_;
	
	PKMovePopView*				movePopView_;
	PKRemovePopView*			removePopView_;
	PKInfoPopView*				rmInfoPopView_;
	
	PKBadgeView *				badgeView_;
}

- (void)importAllFriendsToOpenListActiveByPush;
@end
