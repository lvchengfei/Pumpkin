//
//  PKInfoPopView.m
//  Pumpkin
//
//  Created by lv on 3/11/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import "PKInfoPopView.h"
#import <QuartzCore/QuartzCore.h>

static CGFloat kInfoPopViewSep = 10;
static CGFloat kInfoPopViewWidth = 160;
static CGFloat kInfoPopViewHight = 100;

@implementation PKInfoPopView

- (id)init
{
	self = [super initWithFrame:CGRectZero];
    if (self) {
        // Initialization code		
		label_ = [[UILabel alloc] initWithFrame:CGRectZero];
		label_.textColor = [UIColor whiteColor];
		label_.font = [UIFont systemFontOfSize:13];
		float version = [[[UIDevice currentDevice] systemVersion] floatValue];
		if (version >= 6.0)
		{
			label_.textAlignment = NSTextAlignmentCenter;
			label_.lineBreakMode = NSLineBreakByWordWrapping;
		}
		else
		{
			label_.textAlignment = UITextAlignmentCenter;
			label_.lineBreakMode = UILineBreakModeWordWrap;
		}
		label_.numberOfLines = 0;
		label_.backgroundColor = [UIColor clearColor];
		self.backgroundColor   = [UIColor clearColor];
		[self addSubview:label_];
		self.layer.cornerRadius = 9.0;
		self.layer.masksToBounds = YES;
    }
    return self;
}

- (void)dealloc
{
	[label_				release];
    [super dealloc];
}

- (void)showWithTitle:(NSString*)title
{
	if ([title length]>0) 
	{
		[[UIApplication sharedApplication].keyWindow addSubview:self];
		label_.text = title;
		//CGSize textSz  = [label_ sizeThatFits:CGSizeZero];
		CGFloat width  = kInfoPopViewWidth;
		CGFloat height = kInfoPopViewHight;
		CGRect rect = CGRectMake((320-width)/2, 30, width, height);
		
		if ([label_.text length]>0) 
		{
			CGRect labRt = CGRectMake((kInfoPopViewSep)/2,  (kInfoPopViewSep)/2, width-kInfoPopViewSep,height-kInfoPopViewSep);
			[label_ setFrame:labRt];
		}
		else
			[label_ setFrame:CGRectZero];
		
		[self setFrame:rect];
		self.hidden = YES;
		[UIView animateWithDuration:0.2 animations:^{self.hidden = NO;}];
	}
}

- (void)dismiss
{
	self.hidden = NO;
	[UIView animateWithDuration:0.2 animations:^{self.hidden = YES;} completion:^(BOOL finished){[self removeFromSuperview];}];
}


@end
