//
//  PKAddGroupViewController.h
//  Pumpkin
//
//  Created by lv on 3/3/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PKContactEngine.h"


@interface PKAddGroupViewController : UITableViewController <UITextFieldDelegate>{ 
	UITextField*		groupTextField_;
	UIButton*			addMembersButton_;
	PKContactEngine*    contactEngine_;
}

@end
