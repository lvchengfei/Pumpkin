//
//  PKContactViewController.m
//  Pumpkin
//
//  Created by lv on 2/27/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import "PKContactViewController.h"
#import "PKGroupManagerViewController.h"
#import "PKAddMemToGroupViewController.h"
#import "PKUIConst.h"
#import "PKUtils.h"
#import "PKTutorialView.h"
#import "PKLogicEngine.h"
#import "PKToastView.h"
#import "PKShowServerSynViewController.h"
#import "PKSettings.h"
#import "PKBadgeView.h"
#import "PKShowRequestAddFriendViewController.h"

DEBUGCATEGROY(PKContactViewController)

@interface PKContactViewController()
@property(nonatomic, retain) PKGroupsViewController* groupView;
@property(nonatomic, retain) PKPersonsViewController*personsView;
@property(nonatomic, retain) PKContactPersion*selPerson;
@property(nonatomic, retain) NSArray* requestFriends;
@property(nonatomic, retain) NSArray* updateFriends;
@property(nonatomic, retain) NSArray* animationArray;


- (void)showTutorialIfNeeded;
- (void)leftButtonPressed:(id)sender;
- (void)rightButtonPressed:(id)sender;
- (void)showPopView:(CGPoint)pt title:(NSString*)title;
- (void)dismissPopView;
- (BOOL)checkHaveMoveToRemoveView:(CGPoint)pt;
- (void)showRemoveMemberInfoView;
- (void)dismissRemoveMemberInfoView;
- (void)queryRemoveMemberFromGroup;
- (void)showServerSynInfo;
- (void)importAllFriendsToOpenList;

@end


@implementation PKContactViewController
@synthesize personsView = personsViewController_;
@synthesize groupView = groupViewController_;
@synthesize selPerson = selPerson_;
@synthesize requestFriends = requestFriends_;
@synthesize updateFriends  = updateFriends_; 
@synthesize animationArray = animationArray_;

- (id)init
{
	self = [super init];
	if (self)
	{
		contactEngine_ = [[PKContactEngine sharedContactEngine] retain];
		serverSyn_     = [[PKLogicEngine sharedInstance] getBusinessInstance:@"PKServerSyn"];
		serverSyn_.delegate = self;
		movePopView_   = [[PKMovePopView   alloc] init];
		removePopView_ = [[PKRemovePopView alloc] init];
		rmInfoPopView_ = [[PKInfoPopView   alloc] init];
		movePopView_.backgroundColor   = kMovePopViewColor;//[UIColor blackColor];//kMovePopViewColor; 
		rmInfoPopView_.backgroundColor = [UIColor blackColor];
		rmInfoPopView_.alpha = 0.9;
		
		personsViewController_ = [[PKPersonsViewController alloc] initWithDelegate:self];
		groupViewController_   = [[PKGroupsViewController alloc]  initWithDelegate:self];
		
	}
	return self;
}

- (void)dealloc
{
	serverSyn_ = nil;
	[requestFriends_				release];
	[updateFriends_					release];
	[selPerson_						release];
	[personsViewController_			release];
	[groupViewController_			release];
	[contactEngine_					release];
	[movePopView_					release];
	[removePopView_					release];
	[rmInfoPopView_			release];
	[backgroundView_		release];
	[badgeView_				release];
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewWillAppear:(BOOL)animated
{
	NSInteger count = [serverSyn_.requestAddFriendArray count];
	if (count>0)
	{
		badgeView_.hidden = NO;
		badgeView_.badgeText = [NSString stringWithFormat:@"%d",count];	
	}
	else
	{
		badgeView_.hidden = YES;
	}
	
	[groupViewController_   reloadWithContactData];
	[personsViewController_ reloadWithContactData];
	if (![PKUtils checkShouldShowTutorialView])//第一次显示教程
	{
		[self					showTutorialIfNeeded];
	}
	else if([PKUtils checkShouldSynServerInfo])//第二次联网check用户请求自己开放名片
	{
		self.requestFriends = nil;
		self.updateFriends  = nil;
		self.animationArray = nil;
		[PKToastView showWithTitle:@"正在载入" animation:YES];
		[serverSyn_ synRequestAddFriends];
	}

}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
	
	//NSLog(@">>>view=%@",NSStringFromCGRect(self.view.frame));
	
	groupRect_  = CGRectMake(0, 0, kgroupWidth, self.view.frame.size.height); 
	personRect_ = CGRectMake(kgroupWidth+krowMargin, 0, self.view.frame.size.width-kgroupWidth-krowMargin, self.view.frame.size.height);
	[personsViewController_	  setTableViewFrame:personRect_];
	[groupViewController_	  setTableViewFrame:groupRect_];

	[self.view addSubview:personsViewController_.view];
	[self.view addSubview:groupViewController_.view];
	self.navigationController.navigationBar.tintColor = kNaviCtlColor;
	

	NSString* rightButtonTitle= NSLocalizedString(@"kAddContact", nil);
	UIBarButtonItem* rightButtonItem = [[UIBarButtonItem alloc] initWithTitle:rightButtonTitle style:UIBarButtonItemStyleBordered target:self action:@selector(rightButtonPressed:)];
	self.navigationItem.rightBarButtonItem = rightButtonItem;
	[rightButtonItem		release];
	
	NSString* leftButtonTitle= NSLocalizedString(@"kAddFriendsRequest", nil);
	UIBarButtonItem* leftButtonItem = [[UIBarButtonItem alloc] initWithTitle:leftButtonTitle style:UIBarButtonItemStyleBordered target:self action:@selector(leftButtonPressed:)];
	self.navigationItem.leftBarButtonItem = leftButtonItem;
	[leftButtonItem		release];
	
	if (nil==badgeView_)
	{
		UIView* view = [[UIView alloc] initWithFrame:CGRectMake(60, 0, 30, 30)];
		view.backgroundColor = [UIColor clearColor];
		[self.navigationController.navigationBar addSubview:view];
		
		PKBadgeStyle* badgeStyle = [[PKBadgeStyle alloc] init];
		badgeStyle.badgeAlignment = BIBadgeAlignmentTopLeft;
		badgeView_ = [[PKBadgeView alloc] initWithParentView:view badgeStyle:badgeStyle];
		NSInteger count = [serverSyn_.requestAddFriendArray count];
		if (count>0)
		{
			badgeView_.hidden = NO;
			badgeView_.badgeText = [NSString stringWithFormat:@"%d",count];
		}
		else
		{
			badgeView_.hidden = YES;
		}
		badgeView_.frame = CGRectMake(0, 0, 40, 40);
		badgeView_.backgroundColor = [UIColor clearColor];
		[badgeStyle		release];
		[view			release];
	}
}


- (void)viewDidUnload
{
    [super viewDidUnload];
	[personsViewController_.view removeFromSuperview];
	[groupViewController_.view	 removeFromSuperview];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Public Method

- (void)importAllFriendsToOpenListActiveByPush
{
	[self importAllFriendsToOpenList];
}

#pragma mark - Private Method

- (void)showTutorialIfNeeded
{
	if ([PKUtils shouldShowTutorialView])
    {
		PKTutorialView* tutorialView = [[PKTutorialView alloc] initWithFrame:CGRectMake(0, kStatusHeight, kScreenWith, kScreenHeight-kStatusHeight)];
		tutorialView.tutorialDelegate = self;
		[tutorialView showInView:[UIApplication sharedApplication].keyWindow];
		[tutorialView autorelease];
    }
}

- (void)longTouch:(id)timer
{	
	//self.personsView.allowsSelection = NO;
	self.personsView.tableView.scrollEnabled = NO;
	
	NSSet* touch = [(NSTimer*)timer userInfo];
	[longTouchTimer_ invalidate];
	longTouchTimer_= nil;
	CGPoint personViewPoint =  [[touch anyObject] locationInView:self.personsView.tableView];
	CGPoint windowViewPoint =  [[touch anyObject] locationInView:self.view.window];
	
	NSIndexPath* indexPath= [self.personsView.tableView indexPathForRowAtPoint:personViewPoint];
	[[self.personsView.tableView cellForRowAtIndexPath:indexPath] setHighlighted:NO animated:YES ];
	
	self.selPerson =  [personsViewController_ personRecordAtIndexPath:indexPath];
	NSString* personName = [self.selPerson contactName]; 
	[self showPopView:windowViewPoint title:personName];
	
}


- (void)showPopView:(CGPoint)pt title:(NSString*)title
{
	if ([title length]>0) 
	{
		//show move pop view
		[movePopView_ showWithTitle:title];
		[movePopView_ updatePosition:pt];
		//[movePopView_ updateImage:[self.selPerson image]];
	
		//show remove pop view
		[removePopView_ show];
	}
}

- (void)dismissPopView
{
	[movePopView_		dismiss];
	[removePopView_		dismiss];
	[rmInfoPopView_		dismiss];
	[groupViewController_ dismissAddMemberPopView];
}

- (BOOL)checkHaveMoveToRemoveView:(CGPoint)pt
{
	BOOL result = NO;
	CGRectContainsPoint(removePopView_.frame, pt);
	if (CGRectContainsPoint(removePopView_.frame, pt)) 
	{
		result = YES;
		[self showRemoveMemberInfoView];
		[removePopView_ updateWithState:1];
	}
	else
	{
		[self dismissRemoveMemberInfoView];
		[removePopView_ updateWithState:0];
	}
	return result;
}


- (void)showRemoveMemberInfoView
{
	NSString* personName = [self.selPerson contactName]; 
	NSString* groupName = [contactEngine_ selGroupName];
	NSString* title = nil;
	if ([groupName length]>0)
	{
		title = [NSString stringWithFormat:NSLocalizedString(@"kRemovePersonFromGroup", nil),personName,groupName];
	}
	else 
	{
		title = [NSString stringWithFormat:NSLocalizedString(@"kRemovePerson", nil),personName];
	}
	[rmInfoPopView_ showWithTitle:title];
}

- (void)dismissRemoveMemberInfoView
{
	[rmInfoPopView_ dismiss];
}

- (void)queryRemoveMemberFromGroup
{
	NSString* personName = [self.selPerson contactName]; 
	NSString* groupName = [contactEngine_ selGroupName];
	NSString* title = nil;
	if ([groupName length]>0)
	{
		title = [NSString stringWithFormat:NSLocalizedString(@"kRemovePersonFromGroup", nil),personName,groupName];
	}
	else 
	{
		title = [NSString stringWithFormat:NSLocalizedString(@"kRemovePerson", nil),personName];
	}
	
	UIAlertView* alertView = [[UIAlertView alloc] initWithTitle:title message:nil delegate:self cancelButtonTitle:NSLocalizedString(@"kCancel", nil) otherButtonTitles:NSLocalizedString(@"kOK", nil), nil];
	[alertView	show];
	[alertView	release];
}

- (void)showServerSynInfo
{
	PKShowServerSynViewController* viewController = [[PKShowServerSynViewController alloc] init];
	viewController.requestFriendsArray = self.requestFriends;
	viewController.updateFriendsArray  = self.updateFriends; 
	viewController.updateAnimationArray= self.animationArray;
	viewController.serverSyn = serverSyn_ ;
	UINavigationController* naviController = [[UINavigationController alloc] initWithRootViewController:viewController];
	if ([self respondsToSelector:@selector(presentModalViewController:animated:)]) {
		[self presentModalViewController:naviController animated:YES];
	}
	else if ([self respondsToSelector:@selector(presentViewController:animated:completion:)])
	{
		[self presentViewController:naviController animated:YES completion:nil];
	}
	//[viewController		autorelease];
	//[naviController		autorelease];
}

- (void)importAllFriendsToOpenList
{
	if ([PKUtils checkImportAllFriendsFlag])
	{	
		[PKToastView showWithTitle:@"正在载入" animation:YES];
		PKSettings* settings = [[PKLogicEngine sharedInstance] getBusinessInstance:@"PKSettings"];
		settings.delegate = self;
		[settings importAllFriendsToOpenList];
	}
}
	
#pragma mark - UIButton Event

- (void)leftButtonPressed:(id)sender
{
	PKShowRequestAddFriendViewController* viewController = [[PKShowRequestAddFriendViewController alloc] initWithStyle:UITableViewStylePlain];
	viewController.serverSyn = serverSyn_;
	UINavigationController* naviController = [[UINavigationController alloc] initWithRootViewController:viewController];
	if ([self respondsToSelector:@selector(presentModalViewController:animated:)]) {
		[self presentModalViewController:naviController animated:YES];
	}
	else if ([self respondsToSelector:@selector(presentViewController:animated:completion:)])
	{
		[self presentViewController:naviController animated:YES completion:nil];
	}
	[viewController	autorelease];
}

- (void)rightButtonPressed:(id)sender
{
	PKContactPersion*person = [contactEngine_ createNewContactPerson];
	ABNewPersonViewController* npvc = [[ABNewPersonViewController alloc]init];
	npvc.displayedPerson = person.record;
	npvc.newPersonViewDelegate = self;
	UINavigationController* nvc = [[UINavigationController alloc] initWithRootViewController:npvc];
	//ABPeoplePickerNavigationController* ppnc = [[ABPeoplePickerNavigationController alloc] init];
	if ([self respondsToSelector:@selector(presentModalViewController:animated:)]) {
		[self presentModalViewController:nvc animated:YES];
	}
	else if ([self respondsToSelector:@selector(presentViewController:animated:completion:)])
	{
		[self presentViewController:nvc animated:YES completion:nil];
	}
	[npvc	release];
	[nvc	release];
	
}



#pragma mark - PKTutorialViewDelegate

- (void)tutorialViewDidDismiss
{
	[self importAllFriendsToOpenList];
}

#pragma mark - PKSettingsDelegate

- (void)settings:(PKSettings*)settings accountOpen:(BOOL)isSuccess errorCode:(NSInteger)errCode
{
	[PKToastView dismissWithAnimation:YES];
//	if (isSuccess)
//	{
//		NSLog(@">>>>importAllFriends success!!");
//	}
}


#pragma mark - UIALertViewDelegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	if (buttonIndex==1)
	{
		[contactEngine_ removeFromSelGroupWithPerson:self.selPerson];
		[self.personsView reloadWithContactData];
	}
}


#pragma mark - PKGroupsViewControllerDelegate

- (NSString*)currentSelectedPersonName
{
	return [self.selPerson contactName];
}

- (void)groupTableView:(PKGroupsViewController*)groupTableView didSelectedAtSectionTag:(NSInteger)secTag
{
	switch (secTag) {
		case kPKGroupsStartSectionTag:
		case kPKGroupsContentSectionTag:
			[self.personsView reloadWithContactData];
			break;
		case kPKGroupsEndSectionTag:
		{		
			PKGroupManagerViewController *detailViewController = [[PKGroupManagerViewController alloc] initWithStyle:UITableViewStylePlain];
			[self.navigationController pushViewController:detailViewController animated:YES];
			[detailViewController release];
		}
			break;
		default:
			break;
	}

}

#pragma mark - PKPersonsViewControllerDelegate

- (void)personTableView:(PKPersonsViewController*)personTableView didSelectedPerson:(id)personObject
{
	PKContactPersion*person = (PKContactPersion*)personObject;
	if (person&&[person isKindOfClass:[PKContactPersion class]]) 
	{
		
		ABPersonViewController *picker = [[[ABPersonViewController alloc] init] autorelease];
		picker.personViewDelegate = self;
		picker.addressBook = [contactEngine_  contactAddressBook];
		picker.displayedPerson = ABAddressBookGetPersonWithRecordID([contactEngine_ contactAddressBook],person.recordID);

		NSArray *properties = [NSArray arrayWithObjects:[NSNumber numberWithInt:kABPersonEmailProperty], [NSNumber numberWithInt:kABPersonPhoneProperty],[NSNumber numberWithInt:kABPersonAddressProperty]/*, [NSNumber numberWithInt:kABPersonInstantMessageProperty],[NSNumber numberWithInt:kABPersonURLProperty],[NSNumber numberWithInt:kABPersonOrganizationProperty],[NSNumber numberWithInt:kABPersonDepartmentProperty], [NSNumber numberWithInt:kABPersonBirthdayProperty], [NSNumber numberWithInt:kABPersonNoteProperty],[NSNumber numberWithInt:kABPersonPrefixProperty],[NSNumber numberWithInt:kABPersonSuffixProperty], [NSNumber numberWithInt:kABPersonNicknameProperty]*/,nil ];  
		picker.displayedProperties = properties;
		picker.allowsActions = YES;//可以短信和电话
		// Allow users to edit the person’s information
		picker.allowsEditing = YES;
		[self.navigationController pushViewController:picker animated:YES];
		//[self presentModalViewController:picker animated:YES];

		/*
		ABNewPersonViewController* npvc = [[ABNewPersonViewController alloc]init];
		npvc.displayedPerson = person.record;
		npvc.newPersonViewDelegate = self;
		UINavigationController* nvc = [[UINavigationController alloc] initWithRootViewController:npvc];
		//ABPeoplePickerNavigationController* ppnc = [[ABPeoplePickerNavigationController alloc] init];
		[self presentModalViewController:nvc animated:YES];
		[npvc	release];
		[nvc	release];*/
	}
}

- (void)personTableView:(PKPersonsViewController*)personTableView didSelectedAddMember:(id)object
{
	PKAddMemToGroupViewController* addMemberController = [[PKAddMemToGroupViewController alloc] initWithStyle:UITableViewStylePlain];
	UINavigationController* naviViewController = [[UINavigationController alloc] initWithRootViewController:addMemberController];
	if ([self respondsToSelector:@selector(presentModalViewController:animated:)]) {
		[self presentModalViewController:naviViewController animated:YES];
	}
	else if ([self respondsToSelector:@selector(presentViewController:animated:completion:)])
	{
		[self presentViewController:naviViewController animated:YES completion:nil];
	}
	[addMemberController	release];
	[naviViewController		release];
}

- (void)startSearchContactPerson
{
	[groupViewController_.view removeFromSuperview];
	[personsViewController_ setTableViewFrame:self.view.frame];
}

- (void)stopSearchContactPerson
{
	[personsViewController_ setTableViewFrame:personRect_];
	[groupViewController_   setTableViewFrame:groupRect_];
	[self.view addSubview:groupViewController_.view];
}


- (void)PKtouchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	self.selPerson = nil;
	longTouchTimer_ = [NSTimer scheduledTimerWithTimeInterval:0.5f 
													   target:self 
													 selector:@selector(longTouch:) 
													 userInfo:touches 
													  repeats:NO];
}

- (void)PKtouchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
	[longTouchTimer_ invalidate];
	longTouchTimer_ = nil;
	CGPoint windowPoint = [[touches anyObject] locationInView:self.view.window];
	CGPoint groupPoint  = [[touches anyObject] locationInView:groupViewController_.tableView];
	[movePopView_		  updatePosition:windowPoint];
	[groupViewController_ updateWithPoint:groupPoint];
	[self  checkHaveMoveToRemoveView:windowPoint];
}

- (void)PKtouchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
	[longTouchTimer_ invalidate];
	longTouchTimer_ = nil;
	self.personsView.tableView.scrollEnabled = YES;
	//self.personsView.allowsSelection = YES;
	
	CGPoint windowPoint = [[touches anyObject] locationInView:self.view.window];
	CGPoint groupPoint  = [[touches anyObject] locationInView:groupViewController_.tableView];
	PKContactGroup* tmpGroup  = [groupViewController_ groupRecordAtIndexPath:[groupViewController_.tableView indexPathForRowAtPoint:groupPoint]];
	//selPerson_ = [personsViewController_ personRecordAtIndexPath:self.selPersonIndexPath];
	if([self  checkHaveMoveToRemoveView:windowPoint])
	{
		[self queryRemoveMemberFromGroup];
	}
	else if(self.selPerson&&tmpGroup)
	{
		[contactEngine_ addPerson:self.selPerson toGroup:tmpGroup];
	}

	[self dismissPopView];
}

- (void)PKtouchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event
{
	[longTouchTimer_ invalidate];
	longTouchTimer_ = nil;
	self.personsView.tableView.scrollEnabled = YES;
	//self.personsView.allowsSelection = YES;
	[self dismissPopView];
	
}

#pragma mark - PKServerSynDelegate

-(void)PKServerSyn:(PKServerSyn*)serverSyn requestAddFriends:(NSArray*)requestArray error:(NSError*)error
{
	if ([requestArray isKindOfClass:[NSArray class]]&&[requestArray count]>0) 
	{
		self.requestFriends = [NSArray arrayWithArray:requestArray];
	}
	[serverSyn_ performSelector:@selector(synUpdateFriendsInfo) withObject:nil afterDelay:0.0];

}

-(void)PKServerSyn:(PKServerSyn*)serverSyn updateFriendsInfo:(NSArray*)updateArray error:(NSError*)error
{
	if ([updateArray isKindOfClass:[NSArray class]]&&[updateArray count]>0)
	{
		self.updateFriends = [NSArray arrayWithArray:updateArray];
	}
	[serverSyn_ performSelector:@selector(synMyAnimationInfo) withObject:nil afterDelay:0.0];
	
}

-(void)PKServerSyn:(PKServerSyn*)serverSyn synMyAnimationInfo:(NSArray*)animationArray error:(NSError*)error
{
	[PKToastView dismissWithAnimation:YES];

	if ([animationArray isKindOfClass:[NSArray class]]&&[animationArray count]>0)
	{
		self.animationArray = [NSArray arrayWithArray:animationArray];
	}
	if ([self.requestFriends count]>0||[self.updateFriends count]>0||[self.animationArray count]>0) 
	{
		[self performSelector:@selector(showServerSynInfo) withObject:nil afterDelay:0.0];
	}
	else 
	{
		[self importAllFriendsToOpenList];
	}
}


#pragma mark - ABNewPersonViewControllerDelegate
// Called when the user selects Save or Cancel. If the new person was saved, person will be
// a valid person that was saved into the Address Book. Otherwise, person will be NULL.
// It is up to the delegate to dismiss the view controller.
- (void)newPersonViewController:(ABNewPersonViewController *)newPersonView didCompleteWithNewPerson:(ABRecordRef)person
{
	if (person) 
	{
		[contactEngine_			addContactPerson:person];
		[personsViewController_	reloadWithContactData];
	}
	else
	{
		//self.title = @"cancel";
	}
	if ([self respondsToSelector:@selector(dismissModalViewControllerAnimated:)]) {
		[self dismissModalViewControllerAnimated:YES];
	}
	else if ([self respondsToSelector:@selector(dismissViewControllerAnimated:completion:)])
	{
		[self dismissViewControllerAnimated:YES completion:nil];
	}
}


#pragma mark ABPersonViewControllerDelegate methods
// Does not allow users to perform default actions such as dialing a phone number, when they select a contact property.
- (BOOL)personViewController:(ABPersonViewController *)personViewController shouldPerformDefaultActionForPerson:(ABRecordRef)person property:(ABPropertyID)property identifier:(ABMultiValueIdentifier)identifier
{
	return YES;
}



@end
