//
//  PKSettingsOpenAccountToFrinedsViewController.m
//  Pumpkin
//
//  Created by lv on 3/18/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import "PKSettingsOpenAccountToFrinedsViewController.h"
#import "PKUIConst.h"
#import "PKLogicEngine.h"

@interface PKSettingsOpenAccountToFrinedsViewController ()

- (void)leftButtonPressed:(id)sender;
- (void)rightButtonPressed:(id)sender;

@end

@implementation PKSettingsOpenAccountToFrinedsViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) 
	{
        // Custom initialization
		openAccountToFriends_ = [[PKSetOpenAccountToFriend alloc] init];
		
		NSInteger	width = 90;
		UIBarButtonItem *selectAllButton = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"kSelectAll", nil) 
																			style:UIBarButtonItemStyleBordered target:self action:@selector(allSelected)];
		UIBarButtonItem *reverseButton = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"kConverse", nil) 
																		  style:UIBarButtonItemStyleBordered target:self action:@selector(reverseSelected)];
		UIBarButtonItem *cancelSelectButton = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"kCancelSelect", nil) 
																			   style:UIBarButtonItemStyleBordered target:self action:@selector(cancelSelected)];
		selectAllButton.width	 = width;
		reverseButton.width		 = width;
		cancelSelectButton.width = width;
		toolButtonArr_ = [[NSArray arrayWithObjects:selectAllButton, reverseButton, cancelSelectButton, nil] retain];
		[selectAllButton	release];
		[reverseButton		release];
		[cancelSelectButton release];
		
		normalImage_ = [[UIImageView alloc]initWithImage:[PKUtils commonImageWithName:@"notchecked.png"]];
		selectImage_ = [[UIImageView alloc]initWithImage: [PKUtils commonImageWithName:@"checked.png"]];
    }
    return self;
}

- (void)dealloc
{
	[openAccountToFriends_	release];
	[normalImage_			release];
	[selectImage_			release];
	[toolButtonArr_			release];
	[super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	
	self.navigationController.navigationBar.tintColor = kNaviCtlColor;
	self.navigationController.toolbar.tintColor = kNaviCtlColor;

	// add toolbar at bottom page.
	self.navigationController.toolbar.barStyle = UIBarStyleDefault;
	[self.navigationController setToolbarHidden:NO animated:YES];
	[self setToolbarItems:toolButtonArr_ animated:YES];
	
	
	NSString* cancel = NSLocalizedString(@"kCancel", nil);
	NSString* confirm= NSLocalizedString(@"kOK", nil);
	UIBarButtonItem* leftButton = [[UIBarButtonItem alloc] initWithTitle:cancel style:UIBarButtonItemStyleBordered target:self action:@selector(leftButtonPressed:)];
	self.navigationItem.leftBarButtonItem = leftButton;
	[leftButton		release];
	UIBarButtonItem* rightButton = [[UIBarButtonItem alloc] initWithTitle:confirm style:UIBarButtonItemStyleBordered target:self action:@selector(rightButtonPressed:)];
	self.navigationItem.rightBarButtonItem = rightButton;
	[rightButton	release];
	
	if (![openAccountToFriends_ isHaveCandidatePersons]) 
	{
		UIAlertView* alertView = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"kHaveNonePersonsToAdd", nil) message:nil delegate:self cancelButtonTitle:confirm otherButtonTitles:nil];
		[alertView show];
		[alertView	release];
		
	}
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return [openAccountToFriends_ numberOfSection];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return [openAccountToFriends_ numberOfRowsInSection:section];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) 
	{
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
	}
	cell.textLabel.text = [openAccountToFriends_ contentAtIndexPath:indexPath];
	cell.accessoryType  = [openAccountToFriends_ isSelectedAtindexpath:indexPath]?UITableViewCellAccessoryCheckmark:UITableViewCellAccessoryNone;
    return cell;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return [openAccountToFriends_ titleForHeaderInSection:section];
}

- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView 
{
	return [openAccountToFriends_ sectionIndexTitlesArray];
}
/*
- (NSInteger)tableView:(UITableView *)tableView  sectionForSectionIndexTitle:(NSString *)title 
               atIndex:(NSInteger)index
{
		return index;
}
 */


#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{	
	UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
	[cell setSelected:NO animated:YES];
	BOOL isSelected = NO;
	if (cell.accessoryType == UITableViewCellAccessoryNone)
	{
		cell.accessoryType = UITableViewCellAccessoryCheckmark;
		isSelected = YES;
	}
	else
	{
		cell.accessoryType = UITableViewCellAccessoryNone;
	}
	
	[openAccountToFriends_ setSelectedPerson:isSelected indexpath:indexPath];
}


#pragma mark - Private Method
- (void)leftButtonPressed:(id)sender
{
	if ([self.parentViewController respondsToSelector:@selector(dismissModalViewControllerAnimated:)]) {
		[self.parentViewController dismissModalViewControllerAnimated:YES];
	}
	else if ([self.parentViewController respondsToSelector:@selector(dismissViewControllerAnimated:completion:)])
	{
		[self.parentViewController dismissViewControllerAnimated:YES completion:nil];
	}
}

- (void)rightButtonPressed:(id)sender
{
	if ([self.parentViewController respondsToSelector:@selector(dismissModalViewControllerAnimated:)]) {
		[self.parentViewController dismissModalViewControllerAnimated:NO];
	}
	else if ([self.parentViewController respondsToSelector:@selector(dismissViewControllerAnimated:completion:)])
	{
		[self.parentViewController dismissViewControllerAnimated:NO completion:nil];
	}
	NSString* selPhoneStr = [openAccountToFriends_ getSelectedFriendsPhoneNumber];
	if ([selPhoneStr length]>0)
	{
		[[NSNotificationCenter defaultCenter] postNotificationName:kAddOpenAccountToFriendsNotification object:selPhoneStr];
	}
}

#pragma mark - Toolbar Target Action 


- (void)allSelected
{
	[openAccountToFriends_	allSelected];
	[self.tableView reloadData] ;
}

- (void)reverseSelected
{
	[openAccountToFriends_	reverseSelected];
	[self.tableView reloadData] ;
}

- (void)cancelSelected
{
	[openAccountToFriends_	cancelSelected];
	[self.tableView reloadData] ;
}


#pragma mark - AlertView Delegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	if ([self respondsToSelector:@selector(dismissModalViewControllerAnimated:)]) {
		[self dismissModalViewControllerAnimated:YES];
	}
	else if ([self respondsToSelector:@selector(dismissViewControllerAnimated:completion:)])
	{
		[self dismissViewControllerAnimated:YES completion:nil];
	}
}

#pragma mark - PKDialSetAnimationProtocol


@end
