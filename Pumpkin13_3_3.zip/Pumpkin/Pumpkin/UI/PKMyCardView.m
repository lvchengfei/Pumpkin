//
//  PKMyCardEditView.m
//  Pumpkin
//
//  Created by lv on 6/17/12.
//  Copyright (c) 2012 XXXXX. All rights reserved.
//

#import "PKMyCardView.h"
#import "PKUtils.h"
#import "PKUIConst.h"

@interface PKMyCardView()
@property(nonatomic,assign) PKMyCardTemplate* templateEngine;

- (void)initMyCardView;
@end

@implementation PKMyCardView
@synthesize templateEngine = templateEngine_;

- (id)initWithTemplate:(PKMyCardTemplate*)templateEngine
{
    self = [super initWithFrame:CGRectZero];
    if (self) {
		self.templateEngine = templateEngine;
		templateView_ = [[UIImageView alloc] initWithFrame:CGRectZero];
		[self	addSubview:templateView_];
		
		avatarView_ = [[UIImageView alloc] initWithFrame:CGRectZero];
		[self	addSubview:avatarView_];
		
		titleLabelArray_ = [[NSMutableArray alloc] initWithCapacity:0];
		valueLabelArray_ = [[NSMutableArray alloc] initWithCapacity:0];
		[self initMyCardView];
    }
    return self;
}

- (void)dealloc
{
	[titleLabelArray_		release];
	[templateView_			release];
	[templateEngine_		release];
	[super dealloc];
}

- (void)setFrame:(CGRect)frame
{
	[super setFrame:frame];
	CGRect bgRect = frame;
	bgRect.origin.x = 0;
	bgRect.origin.y = 0;
	[templateView_	setFrame:bgRect];
	
	NSInteger labelCount = [self.templateEngine numberOfDisplayMyCardItems];
	for (NSInteger i=0; i<labelCount ; i++)
	{
		CGRect	titleRect = [self.templateEngine titleRectOfDisplayMyCardItems:i];
		CGRect	valueRect = [self.templateEngine valueRectOfDisplayMyCardItems:i];
		PKMyCardRowItem tag = [self.templateEngine tagOfDisplayMyCardItems:i];
		if (tag==kPKMyCardRowAvatar) 
		{
			[avatarView_ setFrame:valueRect];
		}
		else
		{
			UILabel* titleLabel = objectAtIndex(titleLabelArray_, i-1);
			UILabel* valueLabel = objectAtIndex(valueLabelArray_, i-1);
			[titleLabel	setFrame:titleRect];
			[valueLabel setFrame:valueRect];
		}
	}
	
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

#pragma mark - Public Method
- (void)reloadData
{
	[titleLabelArray_ makeObjectsPerformSelector:@selector(removeFromSuperview)];
	[valueLabelArray_ makeObjectsPerformSelector:@selector(removeFromSuperview)];
	[titleLabelArray_	removeAllObjects];
	[valueLabelArray_	removeAllObjects];
	[self	initMyCardView];
	[self	setNeedsDisplay];
}


#pragma mark - Private Method

- (void)initMyCardView
{
	templateView_.image  = [PKUtils myCardImageWithName:self.templateEngine.selTemplateName];

	NSInteger labelCount = [self.templateEngine numberOfDisplayMyCardItems];
	for (NSInteger i=0; i<labelCount ; i++)
	{
		PKMyCardRowItem tag = [self.templateEngine tagOfDisplayMyCardItems:i];
		if (tag==kPKMyCardRowAvatar) 
		{
			avatarView_.image = [self.templateEngine valueOfDisplayMyCardItems:i];
		}
		else 
		{
			//title
			UILabel* label = [[UILabel alloc] initWithFrame:CGRectZero];
			label.backgroundColor = [UIColor clearColor];
			//NSLog(@">>>title=%@\n",[self.templateEngine titleOfDisplayMyCardItems:i]);
			NSString* text = [self.templateEngine titleOfDisplayMyCardItems:i];
			label.text = [text length]>0?[text stringByAppendingString:@":"]:nil;
			label.font = [UIFont systemFontOfSize:12];
			label.textColor = kMyCardTitleFontColor;
			//label.backgroundColor = [UIColor blueColor];
			label.tag = i;
			[titleLabelArray_ addObject:label];
			[self addSubview:label];
			[label		release];
			//value
			UILabel* label1 = [[UILabel alloc] initWithFrame:CGRectZero];
			label1.backgroundColor = [UIColor clearColor];
			//NSLog(@">>>value=%@\n",[self.templateEngine valueOfDisplayMyCardItems:i]);
			label1.textAlignment = [self.templateEngine valueTextAlignmentOfDisplayMyCardItems:i];
			label1.text = [self.templateEngine valueOfDisplayMyCardItems:i];
			label1.font = [self.templateEngine valueFontOfDisplayMyCardItems:i];
			label1.textColor = [self.templateEngine valueFontColorOfDisplayMyCardItems:i];
			label1.tag = i;
			[valueLabelArray_ addObject:label1];
			[self addSubview:label1];
			[label1		release];
		}
	}
}



@end
