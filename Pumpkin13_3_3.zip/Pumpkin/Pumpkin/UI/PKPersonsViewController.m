//
//  PKPersonsViewController.m
//  TestDrag
//
//  Created by lv on 2/26/12.
//  Copyright  All rights reserved.
//

#import "PKPersonsViewController.h"
#import "PKPersonTableViewCell.h"
#import "PKPersonViewLogic.h"
#import "PKUtils.h"
#import "PKUIConst.h"

@interface PKPersonsViewController()
- (void)setDelegate:(id<PKPersonsViewControllerDelegate>)ctlDelegate;
@end

@implementation PKPersonsViewController
@synthesize ctlDelegate = ctlDelegate_;
@synthesize tableView = tableView_;

- (id)initWithDelegate:(id <PKPersonsViewControllerDelegate>) ctlDelegate
{
	self = [super init];
	if (self) 
	{
		tableView_ = [[UITableView alloc] initWithFrame:CGRectZero];
		//self.editing = YES;
		tableView_.allowsSelectionDuringEditing = YES;
		tableView_.dataSource = self;
		tableView_.delegate = self;
		[self.view addSubview:tableView_];
		[self	   setDelegate:ctlDelegate];
		tableView_.backgroundColor = [UIColor clearColor];
		self.view.backgroundColor = kContactColor;

		
		logicEngine_ = [[PKPersonViewLogic alloc] init];
		
		// Create a search bar
		searchBar_ = [[UISearchBar alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 320.0f, 44.0f)];
		searchBar_.tintColor = kSearchColor;//[UIColor clearColor];
		//searchBar_.backgroundColor = [UIColor clearColor];
		searchBar_.autocorrectionType = UITextAutocorrectionTypeNo;
		searchBar_.autocapitalizationType = UITextAutocapitalizationTypeNone;
		//searchBar_.keyboardType = UIKeyboardTypeAlphabet;
		//searchBar_.delegate = self;
		tableView_.tableHeaderView = searchBar_;
		// Create the search display controller
		searchController_ = [[UISearchDisplayController alloc] initWithSearchBar:searchBar_ contentsController:(UIViewController*)ctlDelegate_];
		searchController_.searchResultsDataSource = self;
		searchController_.searchResultsDelegate = self;
		searchController_.delegate = self;
		
		addImage_ = [[PKUtils contactImageWithName:@"add_person1.png"] retain];
		
	}
	return self;
}



-(void)dealloc
{
	ctlDelegate_ = nil;
	[searchBar_			release];
	[searchController_	release];
	[logicEngine_		release];
	[tableView_			release];
	[addImage_			release];
	[super dealloc];
}

#pragma mark - Public Method

- (void)setTableViewFrame:(CGRect)frame
{
	CGFloat offset =93;//tabBarHeight+navBarHeight ;
	CGRect rect = CGRectMake(0, 0, frame.size.width, frame.size.height-offset);
	[self.view		setFrame:frame];
	[self.tableView	setFrame:rect];
}

- (void)reloadWithContactData
{
	[logicEngine_ refreshPersons];
	[tableView_ reloadData];
}

- (PKContactPersion* )personRecordAtIndexPath:(NSIndexPath*)indexPath
{
	return [logicEngine_ personRecordRefAtIndexPath:indexPath];
}

#pragma mark - Private Method

- (void)setDelegate:(id<PKPersonsViewControllerDelegate>)ctlDelegate
{
	if ([ctlDelegate conformsToProtocol:@protocol(PKPersonsViewControllerDelegate)])
	{
		ctlDelegate_							 = ctlDelegate;
		flags_.delegateDidSelectedPerson		 = [ctlDelegate respondsToSelector:@selector(personTableView:didSelectedPerson:)];
		flags_.delegateDidSelectedAddMember		 = [ctlDelegate respondsToSelector:@selector(personTableView:didSelectedAddMember:)];
		flags_.delegateStartSearchContactPerson	 = [ctlDelegate respondsToSelector:@selector(startSearchContactPerson)];
		flags_.delegateStopSearchContactPerson	 = [ctlDelegate respondsToSelector:@selector(stopSearchContactPerson)];
		flags_.delegatePKtouchesBegan			 = [ctlDelegate respondsToSelector:@selector(PKtouchesBegan:withEvent:)];
		flags_.delegatePKtouchesMoved			 = [ctlDelegate respondsToSelector:@selector(PKtouchesMoved:withEvent:)];
		flags_.delegatePKtouchesEnded			 = [ctlDelegate respondsToSelector:@selector(PKtouchesEnded:withEvent:)];
		flags_.delegatePKtouchesCancelled		 = [ctlDelegate respondsToSelector:@selector(PKtouchesCancelled:withEvent:)];
	}
}



#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	if (tableView!=tableView_)
	{
		//NSLog(@"numberOfSectionsInTableView 00");
		[logicEngine_ searchPersonsWithKeyStr:searchBar_.text];
	}
	//NSLog(@"numberOfSectionsInTableView %d",[logicEngine_ numberOfSection]);
	return [logicEngine_ numberOfSection];

}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	//NSLog(@"numberOfRowsInSection section %d %d",section,[logicEngine_ numberOfRowsInSection:section]);
	return [logicEngine_ numberOfRowsInSection:section];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	//NSLog(@"cellForRowAtIndexPath %@",indexPath);

	static NSString *cellIdentifier  = @"Cell";

	PKPersonTableViewCell *cell = nil;
	cell = (PKPersonTableViewCell*)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
	if (cell == nil) {
		cell = [[[PKPersonTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
		cell.cellDelegate = self;
	}
	NSInteger tag = [logicEngine_ tagOfSectionAtIndexPath:indexPath];
	cell.imageView.image = (tag==kPKPersonsStartSectionTag)?addImage_:nil;//[logicEngine_ imageAtIndexPath:indexPath];
	cell.textLabel.text  = [logicEngine_ contentAtIndexPath:indexPath];

	return cell;
	
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return [logicEngine_ titleForHeaderInSection:section];
}

- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView 
{
	return [logicEngine_ sectionIndexTitlesArray];
}

- (NSInteger)tableView:(UITableView *)tableView  sectionForSectionIndexTitle:(NSString *)title 
               atIndex:(NSInteger)index
{
	//NSLog(@">>>> click index=%d ,title=%@, sec=%d" , index , title , index==0?NSNotFound:index-1);
	if (index==0)
	{
		[tableView setContentOffset:CGPointZero animated:NO];
		return NSNotFound;
	}
	else
	{
		return index-1;
	}
    
}


#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	[[tableView cellForRowAtIndexPath:indexPath] setSelected:NO animated:YES];
	PKContactPersion* person = [logicEngine_ personRecordRefAtIndexPath:indexPath];
	if (person) 
	{
		if (flags_.delegateDidSelectedPerson) 
		{
			[ctlDelegate_	personTableView:self didSelectedPerson:person];
		}
	}
	else 
	{
		if (flags_.delegateDidSelectedAddMember) 
		{
			[ctlDelegate_	personTableView:self didSelectedAddMember:nil];
		}
	}
}


#pragma mark -  UISearchDisplayDelegate

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
	[logicEngine_	searchPersonsWithKeyStr:nil];
	[tableView_		reloadData];
}

// when we start/end showing the search UI
- (void) searchDisplayControllerWillBeginSearch:(UISearchDisplayController *)controller
{
	//NSLog(@"searchDisplayControllerWillBeginSearch");
	logicEngine_.isSearching = YES;
	if (flags_.delegateStartSearchContactPerson)
	{
		[ctlDelegate_ startSearchContactPerson];
	}
}
- (void) searchDisplayControllerDidBeginSearch:(UISearchDisplayController *)controller
{	
	//NSLog(@"searchDisplayControllerDidBeginSearch");
}

- (void) searchDisplayControllerWillEndSearch:(UISearchDisplayController *)controller
{
	//NSLog(@"searchDisplayControllerWillEndSearch");
	logicEngine_.isSearching = NO;
	if (flags_.delegateStopSearchContactPerson)
	{
		[ctlDelegate_ stopSearchContactPerson];
	}	
	[logicEngine_ searchPersonsWithKeyStr:nil];
	[tableView_ reloadData];
}

/*
- (void) searchDisplayControllerDidEndSearch:(UISearchDisplayController *)controller
{	 NSLog(@"searchDisplayControllerDidEndSearch");
}

// called when the table is created destroyed, shown or hidden. configure as necessary.
- (void)searchDisplayController:(UISearchDisplayController *)controller didLoadSearchResultsTableView:(UITableView *)tableView
{
	NSLog(@"didLoadSearchResultsTableView");
}
- (void)searchDisplayController:(UISearchDisplayController *)controller willUnloadSearchResultsTableView:(UITableView *)tableView
{
	NSLog(@"willUnloadSearchResultsTableView");
}

// called when table is shown/hidden
- (void)searchDisplayController:(UISearchDisplayController *)controller willShowSearchResultsTableView:(UITableView *)tableView
{
	NSLog(@"willShowSearchResultsTableView");
}
- (void)searchDisplayController:(UISearchDisplayController *)controller didShowSearchResultsTableView:(UITableView *)tableView
{
	NSLog(@"didShowSearchResultsTableView");
}
- (void)searchDisplayController:(UISearchDisplayController *)controller willHideSearchResultsTableView:(UITableView *)tableView
{
	NSLog(@"willHideSearchResultsTableView");
}
- (void)searchDisplayController:(UISearchDisplayController *)controller didHideSearchResultsTableView:(UITableView *)tableView
{
	NSLog(@"didHideSearchResultsTableView");

}*/

@end
