//
//  PKAddGroupViewController.m
//  Pumpkin
//
//  Created by lv on 3/3/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import "PKAddGroupViewController.h"
#import "PKAddMemToGroupViewController.h"
#import "PKUIConst.h"
#import "PKUtils.h"

@interface PKAddGroupViewController ()
@property(nonatomic, retain) UITextField* groupTextField;
@property(nonatomic, retain) UIButton* addMembersButton;

- (void)addGroupMemberBackNotification:(NSNotification *)notification;

- (void)leftButtonPressed:(id)sender;
- (void)rightButtonPressed:(id)sender;
- (void)addMemeberButtonPressed:(id)sender;
- (BOOL)validateGroupName;
@end

@implementation PKAddGroupViewController
@synthesize groupTextField   = groupTextField_ ;
@synthesize addMembersButton = addMembersButton_;

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
		contactEngine_ = [PKContactEngine sharedContactEngine];
		
		groupTextField_ = [[UITextField alloc] init];
		groupTextField_.borderStyle = UITextBorderStyleRoundedRect;
		groupTextField_.placeholder = NSLocalizedString(@"kAddGroupNameHolder",nil);
		groupTextField_.textAlignment = UITextAlignmentCenter;
		float version = [[[UIDevice currentDevice] systemVersion] floatValue];
		if (version >= 6.0)
		{
			groupTextField_.textAlignment = NSTextAlignmentCenter;
		}
		else
		{
			groupTextField_.textAlignment = UITextAlignmentCenter;
		}
		groupTextField_.font = [UIFont systemFontOfSize:15];
		groupTextField_.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
		groupTextField_.delegate = self ;
		groupTextField_.clearsOnBeginEditing = YES;
		[groupTextField_ becomeFirstResponder];
	
		addMembersButton_ = [[UIButton buttonWithType:UIButtonTypeCustom] retain];
		[addMembersButton_ setTitle:NSLocalizedString(@"kAddGroupMember",nil) forState:UIControlStateNormal];
		[addMembersButton_ addTarget:self action:@selector(addMemeberButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
		UIImage* imageN = nil,*imageH = nil;
		imageN = [PKUtils commonImageWithName:@"login_button_normal.png"];
		imageH = [PKUtils commonImageWithName:@"login_button_pressed.png"];
		imageN = [imageN stretchableImageWithLeftCapWidth:(NSInteger)(imageN.size.width/2) topCapHeight:(NSInteger)(imageN.size.height/2)];
		imageH = [imageH stretchableImageWithLeftCapWidth:(NSInteger)(imageH.size.width/2)  topCapHeight:(NSInteger)(imageH.size.height/2)];
		[addMembersButton_ setBackgroundImage:imageN    forState:UIControlStateNormal];
		[addMembersButton_ setBackgroundImage:imageH	forState:UIControlStateHighlighted];
		
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(addGroupMemberBackNotification:) name:kAddGroupMembersBackNotification object:nil];
    }
    return self;
}

- (void)dealloc
{
	[[NSNotificationCenter defaultCenter] removeObserver:self];
	contactEngine_ = nil;
	[addMembersButton_	release];
	[groupTextField_	release];
    [super dealloc];
}


#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];

	NSString* cancel = NSLocalizedString(@"kCancel", nil);
	NSString* confirm= NSLocalizedString(@"kOK", nil);
	UIBarButtonItem* leftButton = [[UIBarButtonItem alloc] initWithTitle:cancel style:UIBarButtonItemStyleBordered target:self action:@selector(leftButtonPressed:)];
	self.navigationItem.leftBarButtonItem = leftButton;
	[leftButton		release];
	UIBarButtonItem* rightButton = [[UIBarButtonItem alloc] initWithTitle:confirm style:UIBarButtonItemStyleBordered target:self action:@selector(rightButtonPressed:)];
	self.navigationItem.rightBarButtonItem = rightButton;
	[rightButton	release];
	
	self.navigationController.navigationBar.tintColor = kNaviCtlColor;
	self.tableView.separatorStyle  = UITableViewCellSeparatorStyleNone;
	self.tableView.backgroundColor = kBackgroundColor;
}



- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 4;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
	static NSString *TextIdentifier = @"TextCell";
	static NSString *ButtonIdentifier = @"ButtonCell";

    UITableViewCell *cell = nil;
	switch (indexPath.row) {
		 case 0:
		 case 2:
		{
			 cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
			if (cell == nil) {
				cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
				cell.selectionStyle = UITableViewCellSelectionStyleNone;
			}
		}
			break;
		case 1:
		{
			cell = [tableView dequeueReusableCellWithIdentifier:TextIdentifier];
			if (cell == nil) {
				cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:TextIdentifier] autorelease];
				[cell.contentView addSubview:groupTextField_];
				cell.selectionStyle = UITableViewCellSelectionStyleNone;
			}
			CGFloat width = kAddGroupButtonSize.width, height = kAddGroupButtonSize.height;
			CGRect frame = cell.contentView.frame;
			CGRect rt = CGRectMake(frame.origin.x+(frame.size.width-width)/2, frame.origin.y+(frame.size.height-height)/2, width, height);
			[groupTextField_ setFrame:rt];
			
		}
			break;
		case 3:
		{
			 cell = [tableView dequeueReusableCellWithIdentifier:ButtonIdentifier];
			if (cell == nil) {
				cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:ButtonIdentifier] autorelease];
				[cell.contentView addSubview:addMembersButton_];
				cell.selectionStyle = UITableViewCellSelectionStyleNone;
			}
			
			CGRect frame = cell.contentView.frame;
			CGRect rt = CGRectMake(frame.origin.x+(frame.size.width-kAddGroupButtonSize.width)/2, frame.origin.y+(frame.size.height-kAddGroupButtonSize.height)/2, kAddGroupButtonSize.width, kAddGroupButtonSize.height);
			[addMembersButton_ setFrame:rt];
		}
			break;
			
		default:
			break;
	}
    
    return cell;
}


#pragma mark - Table view delegate


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	CGFloat height = 45.0f;
	switch (indexPath.row) {
		case 0:
		case 2:
			height = 25.0f;
			break;
		default:
			break;
	}
	return height;
}
#pragma mark - UIButton event 

- (void)leftButtonPressed:(id)sender
{
	if ([self respondsToSelector:@selector(dismissModalViewControllerAnimated:)]) {
		[self dismissModalViewControllerAnimated:YES];
	}
	else if ([self respondsToSelector:@selector(dismissViewControllerAnimated:completion:)])
	{
		[self dismissViewControllerAnimated:YES completion:nil];
	}
}

- (void)rightButtonPressed:(id)sender
{
	if ([self validateGroupName]) 
	{
		[contactEngine_ addGroupWithName:groupTextField_.text];
		if ([self respondsToSelector:@selector(dismissModalViewControllerAnimated:)]) {
			[self dismissModalViewControllerAnimated:YES];
		}
		else if ([self respondsToSelector:@selector(dismissViewControllerAnimated:completion:)])
		{
			[self dismissViewControllerAnimated:YES completion:nil];
		}
	}
}


#pragma mark - Private Method

- (void)addMemeberButtonPressed:(id)sender
{
	if ([self validateGroupName])
	{
		BOOL result = [contactEngine_ addGroupWithName:groupTextField_.text];
		if (result) 
		{
			[groupTextField_ resignFirstResponder];
			PKAddMemToGroupViewController* addMemberController = [[PKAddMemToGroupViewController alloc] initWithStyle:UITableViewStylePlain];
			UINavigationController* naviViewController = [[UINavigationController alloc] initWithRootViewController:addMemberController];
			if ([self respondsToSelector:@selector(presentModalViewController:animated:)]) {
				[self presentModalViewController:naviViewController animated:YES];
			}
			else if ([self respondsToSelector:@selector(presentViewController:animated:completion:)])
			{
				[self presentViewController:naviViewController animated:YES completion:nil];
			}
			[addMemberController	release];
			[naviViewController		release];
		}
	}
}

- (BOOL)validateGroupName
{
	BOOL result = YES;
	if ([groupTextField_.text length]==0)
	{
		NSString* title = NSLocalizedString(@"kGroupNameEmpty", nil);
		NSString* okStr = NSLocalizedString(@"kOK", nil);
		PKALERTVIEW(nil, title, nil,okStr,nil,nil);
		result = NO;
	}	
	return  result;
}

- (void)addGroupMemberBackNotification:(NSNotification *)notification
{
	NSNumber* number = notification.object;
	if (number&&[number intValue]==0)//取消
	{
		[contactEngine_ removeGroupAtIndex:contactEngine_.selGroupIndex];
	}
	if ([self.parentViewController respondsToSelector:@selector(dismissModalViewControllerAnimated:)]) {
		[self.parentViewController dismissModalViewControllerAnimated:YES];
	}
	else if ([self.parentViewController respondsToSelector:@selector(dismissViewControllerAnimated:completion:)])
	{
		[self.parentViewController dismissViewControllerAnimated:YES completion:nil];
	}
}

@end
