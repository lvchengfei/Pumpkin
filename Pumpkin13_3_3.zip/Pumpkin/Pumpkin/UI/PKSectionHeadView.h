//
//  PKSectionHeadView.h
//  Pumpkin
//
//  Created by lv on 3/17/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import <UIKit/UIKit.h>

@class PKSectionHeadView;
@protocol PKSectionHeadViewDelegate <NSObject>

@optional
-(void)sectionHeaderView:(PKSectionHeadView*)sectionHeaderView sectionOpened:(NSInteger)section;
-(void)sectionHeaderView:(PKSectionHeadView*)sectionHeaderView sectionClosed:(NSInteger)section;

@end

@interface PKSectionHeadView : UIView {
    UILabel*	sectionTitle_;
	UIButton*   disclosureButton_;
	NSInteger   sectionIndex_;
	id <PKSectionHeadViewDelegate> delegate_;
}
@property(nonatomic, readonly) BOOL status;

-(id)initWithFrame:(CGRect)frame title:(NSString*)title section:(NSInteger)section delegate:(id <PKSectionHeadViewDelegate>)delegate;

@end
