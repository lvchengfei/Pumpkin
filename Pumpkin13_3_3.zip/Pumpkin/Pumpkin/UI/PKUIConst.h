//
//  PKConst.h
//  Pumpkin
//
//  Created by lv on 3/3/12.
//  Copyright 2012 XXXXX. All rights reserved.
//
#import "PKDefine.h"
#import "PKConst.h"

#define kgroupWidth					60.0
#define krowMargin					0.0
#define kPopViewRigthMargin			5.0
#define kPopViewTopMargin			10.0
#define kPersonPopViewWidth			100.0
#define kPersonPopViewHeight		45.0
#define kPersonPopViewImgWidth		50.0
#define kGroupPopViewWidth			200.0
#define kGroupPopViewHeight			80.0

#define kSetAnimationForFriends			CGRectMake(30, 305, 260, 45)
#define kAddGroupButtonSize				CGSizeMake(260, 45)


#define kGroupSeletedColor		[UIColor grayColor]
//CGFloat Width = 100.0, Height = 45.0, ImgWidth = 50.0 , topMargin = 10.0;
//CGFloat largeWid = 200, largHeight =80;
#define kBackgroundColor		[UIColor colorWithRed:214.0/255 green:220.0/255 blue:225.0/255 alpha:1.0]
#define kContactColor			[UIColor colorWithRed:214.0/255 green:220.0/255 blue:225.0/255 alpha:1.0]
#define kGroupColor				[UIColor colorWithRed:193.0/255 green:211.0/255 blue:220.0/255 alpha:1.0]
#define kNaviCtlColor			[UIColor colorWithRed:39.0/255 green:160.0/255 blue:218.0/255 alpha:1.0]
#define kTabCtlColor			[UIColor colorWithRed:233.0/255 green:233.0/255 blue:231.0/255 alpha:1.0]
#define kSearchColor			[UIColor colorWithRed:206.0/255 green:205.0/255 blue:198.0/255 alpha:1.0]
#define kToolBarColor			[UIColor colorWithRed:43.0/255 green:43.0/255 blue:43.0/255 alpha:1.0]
//#define kMovePopViewColor		[UIColor colorWithRed:158.0/255 green:166.0/255 blue:177.0/255 alpha:0.9]
#define kMovePopViewColor		[UIColor colorWithRed:80.0/255 green:85.0/255 blue:90.0/255 alpha:0.9]
#define kSectionHeadViewColor   [UIColor colorWithRed:193.0/255 green:211.0/255 blue:220.0/255 alpha:1.0]
#define kMyCardBackgroundColor  [UIColor colorWithRed:247.0/255 green:243.0/255 blue:247.0/255 alpha:1.0]
#define kMyCardTitleFontColor   [UIColor colorWithRed:81.0/255 green:85.0/255 blue:169.0/255 alpha:1.0]
#define kMyCardValueFontColor   [UIColor colorWithRed:97.0/255 green:97.0/255 blue:255.0/255 alpha:1.0]


#define KLoginAccount				@"KLoginAccount"
#define KLoginPassword				@"KLoginPassword"

#define kTemplateHeight				200
#define KTemplateOffset				5.0
#define kSignatureBackHeight		90.0
#define kSignatureTextOrignX		10.0
#define kSignatureTextOrignY		10.0
#define kSignatureTextHeight		70.0
#define kSignatureBackRect	CGRectMake(0, 0, 320, kSignatureBackHeight)
#define kSignatureTextRect	CGRectMake(kSignatureTextOrignX, kSignatureTextOrignY, 320-2*kSignatureTextOrignX, kSignatureTextHeight)
#define kSignatureShareRect CGRectMake(20, 0, 280, 40)

#define kMyCardRect     CGRectMake(KTemplateOffset, KTemplateOffset, 320-2*KTemplateOffset, kTemplateHeight)

#define kTemplateImageOffsetW		5
#define kTemplateImageOffsetH		5
#define kTemplateImageWidth			160
#define kTemplateImageHeight		100
#define kTemplateOff				2
#define kPageControlRect			CGRectMake(0, 0, 320, 10)
#define kTemplateRect				CGRectMake(0, kTemplateTitleLabelRect.size.height, 320, kTemplateImageHeight+kTemplateImageOffsetH*2)
#define kTemplateTitleLabelRect		CGRectMake(0, 0, 320, 20)
#define kTemplateCellSepLineRect	CGRectMake(0, 0, 320, 30)

#define kProfileButtonHeight		50

#define kMyCardAvatarImageSize		CGSizeMake(60, 60)
#define kavaterCellHeight			127.0	//我的名片第一列
#define kHeadImageHeight			75.0	
#define kHeadBackOffset				10.0


enum
{
	kUploadMyCardItem,
	kUploadMyCardAvatar,
};

