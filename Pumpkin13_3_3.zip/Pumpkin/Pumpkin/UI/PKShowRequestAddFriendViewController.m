//
//  PKShowRequestAddFriendViewController.m
//  Pumpkin
//
//  Created by lv on 3/2/13.
//  Copyright (c) 2013 Baidu. All rights reserved.
//

#import "PKShowRequestAddFriendViewController.h"
#import "PKShowStrangerPersonInfoViewController.h"
#import "PKDefine.h"
#import "PKToastView.h"
#import "PKUIConst.h"


#define kNameLabelTag 10
#define kPhoneLabelTag 11

@interface PKShowRequestAddFriendViewController ()
@property(nonatomic,retain) NSArray* showItemArray;
@property(nonatomic,retain) NSMutableArray* seletedArray;

- (void)leftButtonPressed:(id)sender;
- (void)rightButtonPressed:(id)sender;

@end

@implementation PKShowRequestAddFriendViewController
@synthesize seletedArray = seletedArray_;
@synthesize showItemArray = showItemArray_;
@synthesize serverSyn = serverSyn_;

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
	serverSyn_ = nil;
	[seletedArray_  release];
	[showItemArray_ release];
	[super dealloc];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	self.navigationController.navigationBar.tintColor = kNaviCtlColor;
	self.title = @"请求您为好友";
	
	NSString* rightButtonTitle= @"同意请求";//NSLocalizedString(@"kAddContact", nil);
	UIBarButtonItem* rightButtonItem = [[UIBarButtonItem alloc] initWithTitle:rightButtonTitle style:UIBarButtonItemStyleBordered target:self action:@selector(rightButtonPressed:)];
	self.navigationItem.rightBarButtonItem = rightButtonItem;
	[rightButtonItem		release];
	
	NSString* leftButtonTitle= @"返回";//NSLocalizedString(@"kAddFriendsRequest", nil);
	UIBarButtonItem* leftButtonItem = [[UIBarButtonItem alloc] initWithTitle:leftButtonTitle style:UIBarButtonItemStyleBordered target:self action:@selector(leftButtonPressed:)];
	self.navigationItem.leftBarButtonItem = leftButtonItem;
	[leftButtonItem		release];
	
	if ([self.showItemArray count]==0)
	{
		PKALERTVIEW(nil, @"没有新的好友请求。", nil,@"确定",nil,nil);	
	}
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)setServerSyn:(PKServerSyn *)serverSyn
{
	if (serverSyn)
	{
		serverSyn_ = serverSyn;
		self.showItemArray = [NSArray arrayWithArray:serverSyn_.requestAddFriendArray];
		self.seletedArray  = [NSMutableArray arrayWithArray:serverSyn_.requestAddFriendArray];
	}
}
#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [showItemArray_ count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	static NSString *CellIdentifier = @"Cell";
	PKMyCardTableViewCell* cell = (PKMyCardTableViewCell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	if (cell == nil) {
		cell = [[[PKMyCardTableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:CellIdentifier] autorelease];
		cell.selectionStyle = UITableViewCellSelectionStyleNone;
		UILabel* nameLabel  = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 120,  cell.frame.size.height)];
		UILabel* phoneLabel = [[UILabel alloc] initWithFrame:CGRectMake(120, 0, 200,  cell.frame.size.height)];
		nameLabel.tag = kNameLabelTag;
		phoneLabel.tag = kPhoneLabelTag;
		//nameLabel.textAlignment  = UITextAlignmentCenter;
		//phoneLabel.textAlignment = UITextAlignmentCenter;
		[cell.contentView addSubview:nameLabel];
		[cell.contentView addSubview:phoneLabel];
		[nameLabel	release];
		[phoneLabel	release];
	}
	UILabel* nameLabel  = (UILabel*)[cell.contentView viewWithTag:kNameLabelTag];
	UILabel* phoneLabel = (UILabel*)[cell.contentView viewWithTag:kPhoneLabelTag];
	id object = objectAtIndex(self.showItemArray, indexPath.row);	
	nameLabel.text  = [NSString stringWithFormat:@" %@",[object objectForKey:@"name"]];
	phoneLabel.text = [NSString stringWithFormat:@" %@",[object objectForKey:@"mobile"]];
	cell.checked  = [self.seletedArray containsObject:object];
	cell.delegate = self;
	[cell showImageButton:YES];
	
	cell.section = indexPath.section;
	cell.row = indexPath.row;
    return cell;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
	return YES;
}


- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
	return UITableViewCellEditingStyleDelete;
	//return UITableViewCellEditingStyleNone;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
	
    if (UITableViewCellEditingStyleDelete == editingStyle)
    {
		id object = objectAtIndex(self.showItemArray, indexPath.row);
		[self.serverSyn.requestAddFriendArray removeObject:object];
		[self.serverSyn saveRequestAddArray];
		[self refreshData];
	}
}


#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	PKShowStrangerPersonInfoViewController* viewController = [[PKShowStrangerPersonInfoViewController alloc] initWithStyle:UITableViewStylePlain];
	[viewController setShowPersonInfo: objectAtIndex(self.showItemArray,indexPath.row)];
	[self.navigationController pushViewController:viewController animated:YES];
	[viewController	release];
}

#pragma mark - Private Method
- (void)refreshData
{
	self.showItemArray = [NSArray arrayWithArray:serverSyn_.requestAddFriendArray];
	self.seletedArray  = [NSMutableArray arrayWithArray:serverSyn_.requestAddFriendArray];
	[self.tableView reloadData];
}

#pragma mark - PKMyCardTableViewCellDelegate

-(void)tableViewCell:(PKMyCardTableViewCell*)tableViewCell buttonStatusChanged:(BOOL)status
{
	id object = objectAtIndex(self.showItemArray, tableViewCell.row);
	if (!tableViewCell.checked)
	{
		[self.seletedArray removeObject:object];
	}
	else
	{
		[self.seletedArray addObject:object];
	}

}

#pragma mark - Button Pressed 


- (void)leftButtonPressed:(id)sender
{
	if ([self respondsToSelector:@selector(dismissModalViewControllerAnimated:)]) {
		[self dismissModalViewControllerAnimated:YES];
	}
	else if ([self respondsToSelector:@selector(dismissViewControllerAnimated:completion:)])
	{
		[self dismissViewControllerAnimated:YES completion:nil];
	}
}

- (void)rightButtonPressed:(id)sender
{
	if ([self.showItemArray count]>0)
	{
		[PKToastView showWithTitle:@"正在上传中" animation:YES];
		NSMutableArray* disAgree = [NSMutableArray arrayWithArray:self.showItemArray];
		[disAgree removeObjectsInArray:self.seletedArray];
		serverSyn_.delegate = self;
		[serverSyn_ setAgreeRequestFriend:self.seletedArray disAgreeRequestFriends:disAgree];
	}
}

#pragma mark - PKServerSynDelegate

-(void)PKServerSyn:(PKServerSyn*)serverSyn setRequestAddFriends:(BOOL)isSuccess error:(NSError*)error
{
	[PKToastView dismissWithAnimation:YES];
	if (isSuccess)
	{
		//更新请求自己为好友的列表
		[self.serverSyn.requestAddFriendArray removeObjectsInArray:self.seletedArray];
		[self.serverSyn saveRequestAddArray];

		if ([self respondsToSelector:@selector(dismissModalViewControllerAnimated:)]) {
			[self dismissModalViewControllerAnimated:YES];
		}
		else if ([self respondsToSelector:@selector(dismissViewControllerAnimated:completion:)])
		{
			[self dismissViewControllerAnimated:YES completion:nil];
		}
		PKALERTVIEW(nil, @"设置成功！", nil,@"确定",nil,nil);
	}
	else
	{
		PKALERTVIEW(nil, @"设置出错！", nil,@"确定",nil,nil);
	}
	
	[self refreshData];
}



@end
