//
//  PKDialAnimationDetailViewController.m
//  Pumpkin
//
//  Created by lv on 6/13/12.
//  Copyright (c) 2012 XXXXX. All rights reserved.
//

#import "PKDialAnimationDetailViewController.h"
#import "PKPathUtil.h"
#import "PKUtils.h"
#import "PKUIConst.h"
#import "PKDialAnimationSetViewController.h"

@interface PKDialAnimationDetailViewController ()
- (void)setAnimationForFriendsButtonPressed:(id)sender;
@end

@implementation PKDialAnimationDetailViewController
@synthesize dialAnimation = dialAnimation_;
@synthesize imageName = imageName_;
@synthesize sn = sn_;

- (id)init
{
	self = [super init];
	if (self) {
		webView_ = [[UIWebView alloc] initWithFrame:CGRectZero];

		setAniButton_  = [[UIButton buttonWithType:UIButtonTypeCustom] retain];
		UIImage* norImage = [PKUtils commonImageWithName:@"login_button_normal.png"];
		norImage = [norImage stretchableImageWithLeftCapWidth:(NSInteger)(norImage.size.width/2) topCapHeight:(NSInteger)(norImage.size.height/2)];
		UIImage* highLightImage = [PKUtils commonImageWithName:@"login_button_pressed.png"];
		highLightImage = [highLightImage stretchableImageWithLeftCapWidth:(NSInteger)(highLightImage.size.width/2)  topCapHeight:(NSInteger)(highLightImage.size.height/2)];
		[setAniButton_ setBackgroundImage:norImage   forState:UIControlStateNormal];
		[setAniButton_ setBackgroundImage:highLightImage forState:UIControlStateHighlighted];
		[setAniButton_ setTitle:NSLocalizedString(@"kSetFriendsAnimation", nil) forState:UIControlStateNormal];
		setAniButton_.titleLabel.font = [UIFont systemFontOfSize:20];
		[setAniButton_	addTarget:self action:@selector(setAnimationForFriendsButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
	}
	return self;
}
- (void)dealloc
{
	dialAnimation_ = nil;
	[sn_			release];
	[webView_		release];
	[setAniButton_	release];
	[imageName_		release];
	[super dealloc];
}


- (void)viewDidLoad
{
    [super viewDidLoad];

	CGRect frameRect = CGRectZero;
	frameRect.size = [PKUtils animationImageWithName:imageName_].size;
	frameRect.origin.x = (NSInteger)(kScreenWith-frameRect.size.width)/2;
	frameRect.origin.y = 10;
	[webView_ setFrame:frameRect];
	
	NSString* imagePath = [[PKPathUtil dialAnimationPath] stringByAppendingPathComponent:imageName_];
	NSData* imageData = [[NSData alloc] initWithContentsOfFile:imagePath];
	[webView_ loadData:imageData MIMEType:@"image/gif" textEncodingName:nil baseURL:nil];
	[self.view addSubview:webView_];
	[imageData		release];
	
	[setAniButton_	setFrame:kSetAnimationForFriends];
	[self.view		addSubview:setAniButton_];

}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
	[webView_		removeFromSuperview];
	[setAniButton_	removeFromSuperview];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


#pragma mark - Private Method

- (void)setAnimationForFriendsButtonPressed:(id)sender
{
	PKDialAnimationSetViewController* dialAnimationSetViewController = [[PKDialAnimationSetViewController alloc] initWithStyle:UITableViewStylePlain animationSN:sn_];
	UINavigationController* naviViewController = [[UINavigationController alloc] initWithRootViewController:dialAnimationSetViewController];
	
	if ([self respondsToSelector:@selector(presentModalViewController:animated:)])
	{
		if ([self respondsToSelector:@selector(presentModalViewController:animated:)]) {
			[self presentModalViewController:naviViewController animated:YES];
		}
		else if ([self respondsToSelector:@selector(presentViewController:animated:completion:)])
		{
			[self presentViewController:naviViewController animated:YES completion:nil];
		}
	}
	else if ([self respondsToSelector:@selector(presentViewController:animated:completion:)])
	{
		[self presentViewController:naviViewController animated:YES completion:nil];
	}
	[dialAnimationSetViewController	release];
	[naviViewController				release];
}


@end
