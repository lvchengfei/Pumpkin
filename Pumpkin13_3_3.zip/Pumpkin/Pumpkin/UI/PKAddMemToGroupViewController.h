//
//  PKAddMemToGroupViewController.h
//  Pumpkin
//
//  Created by lv on 3/18/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PKAddMemToGroup.h"

@interface PKAddMemToGroupViewController : UITableViewController<UIAlertViewDelegate> 
{
    PKAddMemToGroup*	 addMemberEngine_;
	UIImageView*		 normalImage_;
	UIImageView*		 selectImage_;
	NSArray*			 toolButtonArr_;
	UIViewController*	 backViewController_;
}

@end
