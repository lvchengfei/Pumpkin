//
//  PKDialRefreshTableHeaderView.h
//  Pumpkin
//
//  Created by lv on 2/28/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import "PKDialRefreshTableHeaderView.h"
#import "PKUtils.h"


#define TEXT_COLOR	 [UIColor colorWithRed:124.0/255.0 green:124.0/255.0 blue:124.0/255.0 alpha:1.0]
#define DATE_COLOR   [UIColor colorWithRed:187.0/255.0 green:187.0/255.0 blue:187.0/255.0 alpha:1.0]
#define BORDER_COLOR [UIColor colorWithRed:249.0/255.0 green:249.0/255.0 blue:249.0/255.0 alpha:1.0]

@implementation PKDialRefreshTableHeaderView

@synthesize state=state_;


- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
		
		self.autoresizingMask = UIViewAutoresizingFlexibleWidth;
        
		lastUpdatedLabel_ = [[UILabel alloc] initWithFrame:CGRectMake(120.0f, frame.size.height - 25.0f, self.frame.size.width, 20.0f)];
		lastUpdatedLabel_.autoresizingMask = UIViewAutoresizingFlexibleWidth;
		lastUpdatedLabel_.font = [UIFont systemFontOfSize:11.0f];
		lastUpdatedLabel_.textColor = DATE_COLOR;
		lastUpdatedLabel_.backgroundColor = [UIColor clearColor];
		lastUpdatedLabel_.textAlignment = UITextAlignmentLeft;
		[self addSubview:lastUpdatedLabel_];
        
		if ([[NSUserDefaults standardUserDefaults] objectForKey:@"RefreshTableView_LastRefresh"]) {
			lastUpdatedLabel_.text = [[NSUserDefaults standardUserDefaults] objectForKey:@"RefreshTableView_LastRefresh"];
		} else {
			[self setCurrentDate];
		}
		
		statusLabel_ = [[UILabel alloc] initWithFrame:CGRectMake(120.0f, frame.size.height - 43.0f, self.frame.size.width, 20.0f)];

		statusLabel_.autoresizingMask = UIViewAutoresizingFlexibleWidth;
		statusLabel_.font = [UIFont boldSystemFontOfSize:14.0f];
		statusLabel_.textColor = TEXT_COLOR;
		statusLabel_.backgroundColor = [UIColor clearColor];
		statusLabel_.textAlignment = UITextAlignmentLeft;
		[self setState:PullRefreshNormal];
		[self addSubview:statusLabel_];
    
		arrowImage_ = [[CALayer alloc] init];
		arrowImage_.frame = CGRectMake(93.0f, frame.size.height - 45.0f, 20.0f, 40.0f);
		arrowImage_.contentsGravity = kCAGravityResizeAspect;
		arrowImage_.contents = (id)[PKUtils animationImageWithName:@"arrow.png"].CGImage;
		[[self layer] addSublayer:arrowImage_];
		
		activityView_ = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
		activityView_.frame = CGRectMake(93.0f, frame.size.height - 35.0f, 20.0f, 20.0f);
		activityView_.hidesWhenStopped = YES;
		[self addSubview:activityView_];
		
    }
    return self;
}

- (void)drawRect:(CGRect)rect{
	CGContextRef context = UIGraphicsGetCurrentContext();
	CGContextDrawPath(context,  kCGPathFillStroke);
	[BORDER_COLOR setStroke];
	CGContextBeginPath(context);
	CGContextMoveToPoint(context, 0.0f, self.bounds.size.height - 1);
	CGContextAddLineToPoint(context, self.bounds.size.width, self.bounds.size.height - 1);
	CGContextStrokePath(context);
}

- (void)setCurrentDate {
	NSDateFormatter* formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"MM月dd日  kk:mm"];
	lastUpdatedLabel_.text = [NSString stringWithFormat:@"更新于%@", [formatter stringFromDate:[NSDate date]]];
	[[NSUserDefaults standardUserDefaults] setObject:lastUpdatedLabel_.text forKey:@"RefreshTableView_LastRefresh"];
	[[NSUserDefaults standardUserDefaults] synchronize];
	[formatter release];
}

- (void)setState:(PullRefreshState)aState{
	
	switch (aState) {
		case PullRefreshPulling:
			
			statusLabel_.text = @"松开可以刷新";
			[CATransaction begin];
			[CATransaction setAnimationDuration:.18];
            arrowImage_.transform = CATransform3DIdentity;
			[CATransaction commit];
			
			break;
		case PullRefreshNormal:
			
			if (state_ == PullRefreshPulling) {
				[CATransaction begin];
				[CATransaction setAnimationDuration:.18];
				arrowImage_.transform = CATransform3DIdentity;
				[CATransaction commit];
			}
			
			statusLabel_.text = @"下拉可以刷新";
			[activityView_ stopAnimating];
			[CATransaction begin];
			[CATransaction setValue:(id)kCFBooleanTrue forKey:kCATransactionDisableActions]; 
			arrowImage_.hidden = NO;
            arrowImage_.transform = CATransform3DMakeRotation((M_PI / 180.0) * 180.0f, 0.0f, 0.0f, 1.0f);
			[CATransaction commit];
			
			break;
		case PullRefreshLoading:
			
			statusLabel_.text = @"加载中...";
			[activityView_ startAnimating];
			[CATransaction begin];
			[CATransaction setValue:(id)kCFBooleanTrue forKey:kCATransactionDisableActions]; 
			arrowImage_.hidden = YES;
			[CATransaction commit];
			
			break;
		default:
			break;
	}
	
	state_ = aState;
}

- (void)dealloc {
    [lastUpdatedLabel_ release];
    [statusLabel_ release];
    [arrowImage_ release];
    [activityView_ release];

    [super dealloc];
}


@end
