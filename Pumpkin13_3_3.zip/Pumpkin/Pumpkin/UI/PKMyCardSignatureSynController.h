//
//  PKMyCardSignatureSynController.h
//  Pumpkin
//
//  Created by lv on 3/17/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PKMyCardTableViewCell.h"

@interface PKMyCardSignatureSynController : UITableViewController<PKMyCardTableViewCellDelegate> {
	NSMutableArray* weiboSynchArr_;
    NSMutableArray* weiboSeleteArr_;
	UIView*			headView_;
	NSInteger		selectedCount_;
}
- (void)setSignatrueText:(NSString*)signature;
@end
