//
//  PKLogInOrRegisterViewController.h
//  Pumpkin
//
//  Created by lv on 6/3/12.
//  Copyright (c) 2012 XXXXX. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PKLogInOrRegisterViewController : UIViewController
{
	UIImageView* logImageView_;
	UILabel*	 logTextLabel_;
	UIButton*	 registerButton_;
	UIButton*	 logInButton_;
}
@end
