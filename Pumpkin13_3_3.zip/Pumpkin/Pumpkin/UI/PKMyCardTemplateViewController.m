//
//  PKMyCardTemplateViewController.m
//  Pumpkin
//
//  Created by lv on 6/18/12.
//  Copyright (c) 2012 XXX. All rights reserved.
//

#import "PKMyCardTemplateViewController.h"
#import "PKConst.h"
#import "PKUIConst.h"
#import <QuartzCore/QuartzCore.h>





@interface PKMyCardTemplateViewController ()

@end

@implementation PKMyCardTemplateViewController
@synthesize myCardEngine = myCardEngine_;

- (id)initWithMyCardEngine:(PKMyCardEngine*)myCardEngine
{
    self = [super init];
    if (self) {
		self.myCardEngine = myCardEngine;
		myCardView_   = [[PKMyCardView alloc] initWithTemplate:myCardEngine_.myCardTemplate];
		//pageControl_  = [[UIPageControl alloc] initWithFrame:CGRectZero];
		templateView_ = [[UIScrollView alloc] initWithFrame:CGRectZero]; 
		selectedView_ = [[UIView alloc] initWithFrame:CGRectZero];
		selectedView_.backgroundColor = [UIColor orangeColor];
		selectedView_.layer.cornerRadius  = 8.0;
		selectedView_.layer.masksToBounds = YES;
		[templateView_	addSubview:selectedView_];
		
		templateTitleLabel_ = [[UILabel alloc] initWithFrame:kTemplateTitleLabelRect];
		templateTitleLabel_.text = NSLocalizedString(@"kTemplateTitle", nil);
		templateTitleLabel_.backgroundColor = [UIColor clearColor];
		templateTitleLabel_.textAlignment = UITextAlignmentCenter;
		templateTitleLabel_.font = [UIFont systemFontOfSize:18];
		
		NSArray *templateArr = kDefaultTemplateModelArray;
		NSInteger originX = kTemplateImageOffsetW ;
        for (NSString *name in templateArr)
        {
            UIImageView* imageView = [[UIImageView alloc] initWithFrame:CGRectZero];            
            imageView.image = [PKUtils myCardImageWithName:name];
			imageView.frame = CGRectMake(originX,kTemplateImageOffsetH, kTemplateImageWidth, kTemplateImageHeight); 
            [templateView_ addSubview:imageView];
            [imageView release];
			originX += kTemplateImageWidth+kTemplateImageOffsetW; 

        }
		templateView_.contentSize = CGSizeMake((kTemplateImageWidth+kTemplateImageOffsetW)* [kDefaultTemplateArray count]+kTemplateImageOffsetW, kTemplateImageHeight);
		templateView_.showsVerticalScrollIndicator = NO;
		UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleSingleTap:)];
		[singleTap setNumberOfTapsRequired:1];
		[templateView_ addGestureRecognizer:singleTap];

		cellSeprateLineHeadView_ = [[UIImageView alloc] initWithFrame:kTemplateCellSepLineRect];
		cellSeprateLineHeadView_.image = [PKUtils myCardImageWithName:@"cell_separate_line.png"];
		cellSeprateLineHeadView_.contentMode = UIViewContentModeCenter;

		cellSeprateLineFootView_ = [[UIImageView alloc] initWithFrame:kTemplateCellSepLineRect];
		cellSeprateLineFootView_.image = [PKUtils myCardImageWithName:@"cell_separate_line.png"];
		cellSeprateLineFootView_.contentMode = UIViewContentModeCenter;

		
//		templateView_.showsHorizontalScrollIndicator = NO;
//		templateView_.userInteractionEnabled=YES;
//		templateView_.pagingEnabled = YES;

//		pageControl_.numberOfPages = [kDefaultTemplateArray count];
//		pageControl_.currentPage = 0;
//		pageControl_.backgroundColor = [UIColor blackColor];
		

    }
    return self;
}

- (void)dealloc
{
	[templateView_				release];
	[templateTitleLabel_		release];
	[cellSeprateLineHeadView_	release];
	[cellSeprateLineFootView_	release];
	[myCardEngine_				release];
	[myCardView_				release];
	[super dealloc];
}

- (void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	[self reloadMyCardViewData];
}


- (void)viewDidLoad
{
    [super viewDidLoad];
	self.view.backgroundColor = kMyCardBackgroundColor;
	self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
	[myCardView_	setFrame:kMyCardRect];
	[templateView_	setFrame:kTemplateRect];
	CGRect selRect = CGRectMake(myCardEngine_.selTemplateIndex*(kTemplateImageWidth+kTemplateImageOffsetW), 0, kTemplateImageWidth+2*kTemplateImageOffsetW, kTemplateImageHeight+2*kTemplateImageOffsetH); 
	[selectedView_	setFrame:selRect];

}



- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Public Method

- (BOOL)saveTemplateSelected
{
	return [myCardEngine_.myCardTemplate saveSelectedTemplate];
}

- (void)cancelTemplateSelected
{
	[myCardEngine_ cancelTemplateSelected];
	CGRect selRect = CGRectMake(myCardEngine_.selTemplateIndex*(kTemplateImageWidth+kTemplateImageOffsetW), 0, kTemplateImageWidth+2*kTemplateImageOffsetW, kTemplateImageHeight+2*kTemplateImageOffsetH); 
	[selectedView_	setFrame:selRect];
	[myCardView_	reloadData];
}

- (void)reloadMyCardViewData
{
	[myCardView_    reloadData];
	[myCardView_	setFrame:kMyCardRect];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	NSArray* identifierArr  = [NSArray arrayWithObjects:@"Cell1",@"Cell2", nil];
	NSString*CellIdentifier = [identifierArr objectAtIndex:indexPath.section];
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell==nil)
	{
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
		cell.selectionStyle = UITableViewCellSelectionStyleNone;
	}
	if (indexPath.section==0)
	{
		[cell addSubview:myCardView_];
	}
	else
	{
		[cell addSubview:templateView_];
		[cell addSubview:templateTitleLabel_];

		//[cell addSubview:pageControl_];
	}
	
	return cell;
	
}

#pragma mark - Table view delegate


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	if (indexPath.section==0) 
	{
		return kTemplateHeight+2*KTemplateOffset;
	}
	else if(indexPath.section==1)
	{
		return kTemplateRect.origin.y+kTemplateRect.size.height;//kPageControlRect.size.height+kTemplateImageHeight;
	}
	return 0;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
	return  cellSeprateLineHeadView_;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
	if (section==0)
	{
		return 20;
	}
	else if (section==1)
	{
		return kTemplateCellSepLineRect.size.height;
	}
	return 0;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
	return cellSeprateLineFootView_;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
	if (section==1)
	{
		return kTemplateCellSepLineRect.size.height;
	}
	return 0;
}

#pragma mark - GestureRecognizer

- (void) handleSingleTap:(UITapGestureRecognizer *) gestureRecognizer
{
	CGFloat pageWith = kTemplateImageWidth;
    
    CGPoint loc = [gestureRecognizer locationInView:templateView_];
    NSInteger touchIndex = floor(loc.x / pageWith) ;
	if (touchIndex>=0&&touchIndex<[kDefaultTemplateModelArray count]) 
	{
		if (myCardEngine_.selTemplateIndex!=touchIndex)
		{
			myCardEngine_.selTemplateIndex = touchIndex;
			CGRect selRect = CGRectMake(myCardEngine_.selTemplateIndex*(kTemplateImageWidth+kTemplateImageOffsetW), 0, kTemplateImageWidth+2*kTemplateImageOffsetW, kTemplateImageHeight+2*kTemplateImageOffsetH); 
			[selectedView_	setFrame:selRect];
			[myCardEngine_.myCardTemplate	updateWithTemplateName:[kDefaultTemplateArray objectAtIndex:touchIndex]];
			[self reloadMyCardViewData];

		}
	}
    //NSLog(@"touch index %d",touchIndex);  
}


@end
