//
//  PKShowAnimationInfoViewController.m
//  Pumpkin
//
//  Created by lv on 8/12/12.
//  Copyright (c) 2012 Baidu. All rights reserved.
//

#import "PKShowAnimationInfoViewController.h"
#import "PKUtils.h"
#import "PKConst.h"
#import "PKPathUtil.h"

@interface PKShowAnimationInfoViewController ()

@end

@implementation PKShowAnimationInfoViewController
@synthesize imageName = imageName_;
- (id)init
{
    self = [super init];
    if (self) {
        // Custom initialization
		webView_ = [[UIWebView alloc] initWithFrame:CGRectZero];
    }
    return self;
}

- (void)dealloc
{
	[webView_		release];
	[imageName_		release];
    [super dealloc];
}


- (void)viewDidLoad
{
    [super viewDidLoad];
	CGRect frameRect = CGRectZero;
	frameRect.size = [PKUtils animationImageWithName:imageName_].size;
	frameRect.origin.x = (NSInteger)(kScreenWith-frameRect.size.width)/2;
	frameRect.origin.y = 10;
	[webView_ setFrame:frameRect];
	
	NSString* imagePath = [[PKPathUtil dialAnimationPath] stringByAppendingPathComponent:imageName_];
	NSData* imageData = [[NSData alloc] initWithContentsOfFile:imagePath];
	[webView_ loadData:imageData MIMEType:@"image/gif" textEncodingName:nil baseURL:nil];
	[self.view addSubview:webView_];
	[imageData		release];

}

- (void)viewDidUnload
{
    [super viewDidUnload];
	[webView_		removeFromSuperview];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
