//
//  PKSettingsRootViewController.m
//  Pumpkin
//
//  Created by lv on 2/28/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import "PKSettingsRootViewController.h"
#import "PKUIConst.h"
#import "PKUtils.h"
#import "PKDefine.h"
#import "PKLogicEngine.h"
#import "PKSettingsOpenAccountViewController.h"
#import "PKSettingsWeiboAuthViewController.h"
#import "PKSettingsRecommendFriends.h"
#import "PumpkinAppDelegate.h"
#import "PKToastView.h"
#import "PKAboutViewController.h"
#import "PKSettingsOpenAccountToFrinedsViewController.h"


#define kOpenAccountToStrangerTag 0x11

@interface PKSettingsRootViewController()
@property (nonatomic, retain) UIAlertView*	alertView;
@property (nonatomic, retain) UITextField*	accountTextField;
@property (nonatomic, retain) UITextField*	passwordTextField;
@property (nonatomic, retain) UIButton*		passwordCheckBox;

- (void)showLogInAlertView:(NSInteger)tag;
- (void)showChangeNumberAlertView:(NSInteger)tag;
- (void)showChangePasswordAlertView:(NSInteger)tag;
- (void)showRemoveUserAlertView:(NSInteger)tag;
- (void)initPasswordCheckBoxState;
- (void)addAccountTextField:(NSString*)placeHolder;
- (void)addPasswordTextField:(NSString*)placeHolder;
- (void)addPasswordCheckBox;
- (void)switchValueChanged:(UISwitch*)sender;


@end


@implementation PKSettingsRootViewController
@synthesize alertView = alertView_;
@synthesize accountTextField  = accountTextField_;
@synthesize passwordTextField = passwordTextField_;
@synthesize passwordCheckBox  = passwordCheckBox_;

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization		
		settings_ =  [[PKLogicEngine sharedInstance] getBusinessInstance:@"PKSettings"];
		[settings_ setDelegate:self];
		accountManager_ = [[PKLogicEngine sharedInstance] getBusinessInstance:@"PKAccountManager"];
		accountManager_.delegate = self;
		
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(addOpenAccountToFriendsNotification:) name:kAddOpenAccountToFriendsNotification object:nil];
		
    }
    return self;
}

- (void)dealloc
{
	[[NSNotificationCenter defaultCenter] removeObserver:self];
	accountManager_ = nil;
	settings_	    = nil;
	[alertView_				release];
	[accountTextField_		release];
	[passwordTextField_		release];
	[passwordCheckBox_		release];
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	self.view.backgroundColor = kBackgroundColor;
	self.navigationController.navigationBar.tintColor = kNaviCtlColor;
	
}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
	settings_.delegate = self;
}


- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Public Method

- (void)gotoWeiboAuthViewController
{
	PKSettingsWeiboAuthViewController* ctl = [[PKSettingsWeiboAuthViewController alloc] initWithStyle:UITableViewStylePlain];
	[self.navigationController pushViewController:ctl animated:YES];
	[ctl		release];
}
#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return [settings_ numberOfSettingsSection];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return [settings_ numberOfSettingsAtSection:section];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"CellIdentifier";
	static NSString *SwitchIdentifier = @"SwitchIdentifier";
	BOOL showSwitch = [settings_ showSwitchOfSettingsAtSection:indexPath.section row:indexPath.row];   
	NSString* identifier = showSwitch?SwitchIdentifier:CellIdentifier;
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) 
	{
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier] autorelease];
		if (showSwitch)
		{
			UISwitch *tmpSwitch = [[UISwitch alloc] init];
			[tmpSwitch addTarget:self action:@selector(switchValueChanged:) forControlEvents:UIControlEventValueChanged];
			cell.accessoryView = tmpSwitch;
			[tmpSwitch release];
		}
	}

	NSInteger tag = [settings_ tagOfSettingsAtSection:indexPath.section row:indexPath.row];
	if (showSwitch) 
	{
		UISwitch *switchView =(UISwitch*) cell.accessoryView ;  
		switchView.tag = tag;
		switchView.on = [settings_ valueOfSwitchTag:tag];
	}
	cell.tag = tag;
	cell.accessoryType  = [settings_ showDisclosureIndicatorAtIndexPath:indexPath]?UITableViewCellAccessoryDisclosureIndicator:UITableViewCellAccessoryNone;
    cell.textLabel.text  = [settings_ contentOfSettingsAtSection:indexPath.section row:indexPath.row];
    cell.imageView.image = [settings_ imageOfSettingsAtSection:indexPath.section row:indexPath.row];
    return cell;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
	return [settings_ contentOfSettingsAtSection:section];
}


#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	[[tableView cellForRowAtIndexPath:indexPath] setSelected:NO animated:YES];
	PKSettingsType settingTag = [tableView cellForRowAtIndexPath:indexPath].tag;
	switch (settingTag) {
		case PKWeiBoAuth:
		{
			PKSettingsWeiboAuthViewController* ctl = [[PKSettingsWeiboAuthViewController alloc] initWithStyle:UITableViewStylePlain];
			[self.navigationController pushViewController:ctl animated:YES];
			[ctl		release];
		}
			break;
		case PKShareWithFrineds:
		{
			PKSettingsRecommendFriends* ctl = [[PKSettingsRecommendFriends alloc] initWithStyle:UITableViewStylePlain];
			[self.navigationController pushViewController:ctl animated:YES];
			[ctl		release];
			
		}
			break;
		case PKAccountAuthManagerDetail:
		{
			UIActionSheet* actionSheet = [[UIActionSheet alloc] initWithTitle:@"设置开放名片范围" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:@"开放名片给好友" otherButtonTitles:@"开放名片给陌生人", nil];
			[actionSheet showInView:self.view.superview];
			[actionSheet release];
			/*
			PKSettingsOpenAccountViewController* ctl = [[PKSettingsOpenAccountViewController alloc] initWithStyle:UITableViewStylePlain];
			ctl.settings = settings_;
			[self.navigationController pushViewController:ctl animated:YES];
			[ctl		release];*/
		}
			break;
		case PKAboutUs:
		{
			PKAboutViewController* aboutViewController = [[PKAboutViewController alloc] initWithStyle:UITableViewStyleGrouped];
			[self.navigationController pushViewController:aboutViewController animated:YES];
			[aboutViewController	release];
			break;
		}
		case PKLogOut:
		{
			UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"退出登录" 
															message:@"确认要退出吗？"
														   delegate:self 
												  cancelButtonTitle:NSLocalizedString(@"kOK",nil) 
												  otherButtonTitles:NSLocalizedString(@"kCancel",nil), nil];
			alert.tag = PKLogOut;
			self.alertView = alert;
			[alert show];
			[alert release];
		}
			break;
		default:
			[settings_ didSeletedIndexPath:indexPath];
			break;
	}

}


#pragma mark - Logic

- (void)initPasswordCheckBoxState 
{
	UIImage *checkImage   = [PKUtils commonImageWithName:@"checked.png"];
	UIImage *uncheckImage = [PKUtils commonImageWithName:@"notchecked.png"];
	
	NSString *userNameStr = [[NSUserDefaults standardUserDefaults] objectForKey:KLoginAccount];
	if ([userNameStr caseInsensitiveCompare:@""] != NSOrderedSame && userNameStr != nil) {
		accountTextField_.text = userNameStr;
	} else {
		accountTextField_.text = @"";
	}
	
	NSString *userPasswordStr = [[NSUserDefaults standardUserDefaults] objectForKey:KLoginPassword];
	if ([userPasswordStr caseInsensitiveCompare:@""] != NSOrderedSame && userPasswordStr != nil) {
		isPasswordChecked_ = YES;
		[passwordCheckBox_ setBackgroundImage:checkImage forState:UIControlStateNormal];
		passwordTextField_.text = userPasswordStr;
	} else {
		isPasswordChecked_ = NO;
		[passwordCheckBox_ setBackgroundImage:uncheckImage forState:UIControlStateNormal];
		passwordTextField_.text = @"";
	}
	
}

- (void)addAccountTextField:(NSString*)placeHolder
{
	CGRect rectName = CGRectMake(10, 50, 262, 30);
	UITextField *tmpUserTextField = [[UITextField alloc] initWithFrame:rectName];
	self.accountTextField = tmpUserTextField;
	self.accountTextField.delegate = self;
	tmpUserTextField.placeholder = placeHolder;
	tmpUserTextField.textColor = [UIColor blackColor];
	tmpUserTextField.borderStyle = UITextBorderStyleRoundedRect;
	tmpUserTextField.adjustsFontSizeToFitWidth = YES;
	tmpUserTextField.clearButtonMode = UITextFieldViewModeNever;
	tmpUserTextField.clearsOnBeginEditing = YES;
	[self.alertView addSubview:tmpUserTextField];
	[tmpUserTextField release];
}

- (void)addPasswordTextField:(NSString*)placeHolder
{
	CGRect rectPassword = CGRectMake(10, 87, 262, 30);
	UITextField *tmpPasswordTextField = [[UITextField alloc] initWithFrame:rectPassword];
	self.passwordTextField = tmpPasswordTextField;
	self.passwordTextField.delegate = self;
	tmpPasswordTextField.placeholder = placeHolder;
	tmpPasswordTextField.textColor = [UIColor blackColor];
	tmpPasswordTextField.borderStyle = UITextBorderStyleRoundedRect;
	tmpPasswordTextField.adjustsFontSizeToFitWidth = YES;
	tmpPasswordTextField.clearButtonMode = UITextFieldViewModeNever;
	tmpPasswordTextField.clearsOnBeginEditing = YES;
	[tmpPasswordTextField setSecureTextEntry:YES];
	[self.alertView addSubview:tmpPasswordTextField];
	[tmpPasswordTextField release];
}

- (void)addPasswordCheckBox
{
	CGRect rectPasswordCheckBox = CGRectMake(17, 132, 20, 20);
	UIButton *tmpPasswordCheckBox = [UIButton buttonWithType:UIButtonTypeCustom];
	self.passwordCheckBox = tmpPasswordCheckBox;
	tmpPasswordCheckBox.frame = rectPasswordCheckBox;
	tmpPasswordCheckBox.backgroundColor = [UIColor clearColor];
	[self.alertView addSubview:tmpPasswordCheckBox];
	[passwordCheckBox_ addTarget:self action:@selector(clickPasswordCheckBox) forControlEvents:UIControlEventTouchUpInside];

	CGRect rectPasswordLabel = CGRectMake(45, 127, 80, 30);
	UILabel *passwordLabel = [[UILabel alloc] initWithFrame:rectPasswordLabel];
	passwordLabel.text = NSLocalizedString(@"kStorePassword", nil);
	passwordLabel.textColor = [UIColor whiteColor];
	passwordLabel.adjustsFontSizeToFitWidth = YES;
	passwordLabel.backgroundColor = [UIColor colorWithHue:0 saturation:0 brightness:0 alpha:0];
	[self.alertView addSubview:passwordLabel];
	[passwordLabel release];
}


- (void)showLogInAlertView:(NSInteger)tag
{
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"用户登录\n\n\n\n\n" 
													message:nil 
												   delegate:self 
										  cancelButtonTitle:NSLocalizedString(@"kOK",nil) 
										  otherButtonTitles:NSLocalizedString(@"kCancel",nil), nil];
	alert.tag = tag;
	self.alertView = alert;
	[self addAccountTextField:NSLocalizedString(@"kLoginAccount", nil)];
	[self addPasswordTextField:NSLocalizedString(@"kLoginPassword", nil)];
	//[self addPasswordCheckBox];
	//[self initPasswordCheckBoxState];
	[accountTextField_  setSecureTextEntry:NO];
	[passwordTextField_ setSecureTextEntry:YES];
	alert.transform = CGAffineTransformMakeTranslation(0.0, -100.0);
	[alert show];
	[alert release];
}


- (void)showChangeNumberAlertView:(NSInteger)tag
{
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"更改号码\n\n\n\n\n" 
													message:nil 
												   delegate:self 
										  cancelButtonTitle:NSLocalizedString(@"kOK",nil) 
										  otherButtonTitles:NSLocalizedString(@"kCancel",nil), nil];
	
	alert.tag = tag;
	self.alertView = alert;
	[self addAccountTextField:NSLocalizedString(@"kOldNumber", nil)];
	[self addPasswordTextField:NSLocalizedString(@"kNewNumber", nil)];
	[accountTextField_  setSecureTextEntry:NO];
	[passwordTextField_ setSecureTextEntry:NO];
	alert.transform = CGAffineTransformMakeTranslation(0.0, -100.0);
	[alert show];
	[alert release];
}

- (void)showChangePasswordAlertView:(NSInteger)tag
{
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"修改密码\n\n\n\n\n" 
													message:nil 
												   delegate:self 
										  cancelButtonTitle:NSLocalizedString(@"kOK",nil) 
										  otherButtonTitles:NSLocalizedString(@"kCancel",nil), nil];
	alert.tag = tag;
	self.alertView = alert;
	[self addAccountTextField:NSLocalizedString(@"kOldPassword", nil)];
	[self addPasswordTextField:NSLocalizedString(@"kNewPassword", nil)];
	[accountTextField_  setSecureTextEntry:NO];
	[passwordTextField_ setSecureTextEntry:NO];
	alert.transform = CGAffineTransformMakeTranslation(0.0, -100.0);
	[alert show];
	[alert release];
}

- (void)showRemoveUserAlertView:(NSInteger)tag
{
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"注销用户\n\n\n\n\n" 
													message:nil 
												   delegate:self 
										  cancelButtonTitle:NSLocalizedString(@"kOK",nil) 
										  otherButtonTitles:NSLocalizedString(@"kCancel",nil), nil];
	alert.tag = tag;
	self.alertView = alert;
	[self addAccountTextField:NSLocalizedString(@"kLoginAccount", nil)];
	[self addPasswordTextField:NSLocalizedString(@"kLoginPassword", nil)];
	[accountTextField_  setSecureTextEntry:NO];
	[passwordTextField_ setSecureTextEntry:YES];
	alert.transform = CGAffineTransformMakeTranslation(0.0, -100.0);
	[alert show];
	[alert release];
}


- (void)showOpenAccoutToStranger
{
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"开放名片\n\n\n" 
													message:nil 
												   delegate:self 
										  cancelButtonTitle:NSLocalizedString(@"kOK",nil) 
										  otherButtonTitles:NSLocalizedString(@"kCancel",nil), nil];
	alert.tag = kOpenAccountToStrangerTag;
	self.alertView = alert;
	[self addAccountTextField:@"对方手机"];
	[accountTextField_  setSecureTextEntry:NO];
	//alert.transform = CGAffineTransformMakeTranslation(0.0, -100.0);
	[alert show];
	[alert release];
}

- (void)clickPasswordCheckBox 
{
	
	UIImage *checkImage   = [PKUtils commonImageWithName:@"checked.png"];
	UIImage *uncheckImage = [PKUtils commonImageWithName:@"notchecked.png"];
	if (isPasswordChecked_) 
	{
		isPasswordChecked_ = NO;
		[passwordCheckBox_ setBackgroundImage:uncheckImage forState:UIControlStateNormal];
	} 
	else 
	{
		isPasswordChecked_ = YES;
		[passwordCheckBox_ setBackgroundImage:checkImage forState:UIControlStateNormal];
	}
}

- (void)switchValueChanged:(UISwitch*)sender
{
	if (sender.tag==PKShowCallInteractive&&sender.on==NO)
	{
		UIAlertView* alert = [[UIAlertView alloc] initWithTitle:@"您将关闭与所有脉客好友的信息交互？！" message:nil delegate:self cancelButtonTitle:@"确定" otherButtonTitles:@"取消",nil];
		alert.tag = PKShowCallInteractive;
		[alert show];
		[alert release];
		return;
	}
//	if (sender.tag==PKAccountAuthManager&&sender.on==NO)
//	{
//		UIAlertView* alert = [[UIAlertView alloc] initWithTitle:@"您将取消的公开个人名片？！" message:nil delegate:self cancelButtonTitle:@"确定" otherButtonTitles:@"取消",nil];
//		alert.tag = PKAccountAuthManager;
//		[alert show];
//		[alert release];
//		return;
//	}
	if ([settings_ setSwitchTag:sender.tag value:sender.on])
	{
		[PKToastView showWithTitle:@"正在上传中" animation:YES];
	}
}

#pragma mark - Alert view delegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex 
{
	if(alertView.tag == kOpenAccountToStrangerTag)
	{
		NSString* phoneNumber = accountTextField_.text;
		if([PKUtils isValidatePhoneNumber:phoneNumber])
		{
			[PKToastView showWithTitle:@"正在上传中" animation:YES];
			settings_.delegate = self;
			[settings_ addFriendsToOpenList:phoneNumber];
		}
		else
		{
			PKALERTVIEW(nil, @"请输入正确手机号！", nil,@"确定",nil,nil);
		}
	}
	else if (alertView.tag == PKShowCallInteractive)
	{
		if (buttonIndex==0) 
		{
			[settings_ setSwitchTag:PKShowCallInteractive value:NO];
		}
		else 
		{
			[self.tableView reloadData];
		}
	}
	else if (alertView.tag ==PKLogOut)
	{
		if (buttonIndex==0)
		{
			[settings_ logout];
			PumpkinAppDelegate* appDelegate = (PumpkinAppDelegate*)[[UIApplication sharedApplication] delegate];
			[appDelegate showRegisterOrLoginViewController];
		}
	}
	else 
	{
		
	if (buttonIndex==0) 
	{
		if ([accountTextField_.text length]==0||[passwordTextField_.text length]==0) 
		{
			PKALERTVIEW(nil, NSLocalizedString(@"kTextFieldEmpty", nil), nil,NSLocalizedString(@"kOK", nil),nil,nil);
			return;
		}
		NSInteger style = alertView.tag;
		switch (style) 
		{
			case PKLogInResume:
				break;
			case PKLogInBackup:
				break;
			case PKLogInChangeNumber:
				if ([PKUtils  isValidatePhoneNumber:accountTextField_.text]&&[PKUtils isValidatePhoneNumber:passwordTextField_.text])
				{
					if([accountManager_ changeAccount:accountTextField_.text newAccount:passwordTextField_.text])
					{
						[PKToastView showWithTitle:@"正在上传中" animation:YES];
					}
				}
				else 
				{
					PKALERTVIEW(nil, @"请输入有效手机号码", nil,@"确定",nil,nil);
				}
				break;
			case PKLogInChangePassword:
				if([accountManager_ changePassword:accountTextField_.text newPassword:passwordTextField_.text])
				{
					[PKToastView showWithTitle:@"正在上传中" animation:YES];
				}
				break;
			case PKLogInRemoveAccount:
				if([accountManager_ removeUserWithAccount:accountTextField_.text password:passwordTextField_.text])
				{
					[PKToastView showWithTitle:@"正在上传中" animation:YES];
				}
				break;
			default:
				break;
		}
	}
	else 
	{
		
	}
	}
}



#pragma mark - ActionSheet Delegate

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
	if (buttonIndex==0)
	{
		PKSettingsOpenAccountToFrinedsViewController* openAccountViewController = [[PKSettingsOpenAccountToFrinedsViewController alloc] initWithStyle:UITableViewStylePlain];
		UINavigationController* naviViewController = [[UINavigationController alloc] initWithRootViewController:openAccountViewController];
		if ([self respondsToSelector:@selector(dismissModalViewControllerAnimated:)]) {
			[self dismissModalViewControllerAnimated:YES];
		}
		else if ([self respondsToSelector:@selector(dismissViewControllerAnimated:completion:)])
		{
			[self dismissViewControllerAnimated:YES completion:nil];
		}

		
		if ([self respondsToSelector:@selector(presentModalViewController:animated:)]) {
			[self presentModalViewController:naviViewController animated:YES];
		}
		else if ([self respondsToSelector:@selector(presentViewController:animated:completion:)])
		{
			[self presentViewController:naviViewController animated:YES completion:nil];
		}
		
		[openAccountViewController		release];
		[naviViewController				release];
	}
	else if(buttonIndex==1)
	{
		[self showOpenAccoutToStranger];
	}
}



#pragma mark - Notification

- (void)addOpenAccountToFriendsNotification:(NSNotification *)notification
{
	[PKToastView showWithTitle:@"正在上传中" animation:YES];
	NSString* phoneStr = notification.object;
	settings_.delegate = self;
	[settings_ setOpenList:phoneStr];
}


#pragma mark - PKSettingsDelegate

- (void)settings:(PKSettings*)settings showLoginView:(PKLogInType)style
{
	if (style==PKLogInResume||style==PKLogInBackup) 
	{
		[self showLogInAlertView:style];
	}
	else if (style==PKLogInChangeNumber) 
	{
		[self showChangeNumberAlertView:style];
	}
	else if(style==PKLogInChangePassword)
	{
		[self showChangePasswordAlertView:style];
	}
	else if(style==PKLogInRemoveAccount)
	{
		[self showRemoveUserAlertView:style];
	}
}

- (void)settings:(PKSettings *)settings accountOpen:(BOOL)isSuccess errorCode:(NSInteger)errCode
{

	[PKToastView dismissWithAnimation:NO];
	if (!isSuccess)
	{
		NSString* title = (errCode==kNetWorkErr)?NSLocalizedString(@"kNetWorkError", nil):NSLocalizedString(@"kAccountOpenSetError", nil);
		PKALERTVIEW(nil, title, nil,@"确定",nil,nil);
	}
	[self.tableView reloadData];
}

#pragma mark -  PKAccountManagerProtocol

- (void)accountManager:(PKAccountManager*)accountManager changeAccount:(BOOL)isSuccess errorCode:(PKAccountErrorCode)errCode
{
	[PKToastView dismissWithAnimation:YES];
	if (isSuccess) 
	{
		PKALERTVIEW(nil, NSLocalizedString(@"kChangeAccountSuc", nil), nil,NSLocalizedString(@"kOK", nil),nil);
	}
	else
	{
		NSString* title =NSLocalizedString(@"kChangeAccountErr", nil);
		title = errCode==PKNetworkErr?NSLocalizedString(@"kChangeAccountNetwork", nil):title;
		title = errCode==PKOldAccountErr?NSLocalizedString(@"kChangeAccountOldAccountErr", nil):title;
		title = errCode==PKHaveRegisterErr?NSLocalizedString(@"kChangeAccountNewAccountErr", nil):title;
		PKALERTVIEW(nil,title , nil,NSLocalizedString(@"kOK", nil) ,nil,nil);
		
	}
	
}

- (void)accountManager:(PKAccountManager*)accountManager changePassword:(BOOL)isSuccess errorCode:(PKAccountErrorCode)errCode
{
	[PKToastView dismissWithAnimation:YES];
	if (isSuccess) 
	{
		PKALERTVIEW(nil, NSLocalizedString(@"kChangePasswordSuc", nil), nil,NSLocalizedString(@"kOK", nil),nil,nil);
	}
	else
	{
		NSString* title =NSLocalizedString(@"kChangePasswordErr", nil);
		title = errCode==PKNetworkErr?NSLocalizedString(@"kChangePasswordNetwork", nil):title;
		title = errCode==PKOldPasswordErr?NSLocalizedString(@"kChangePasswordOldPassWordErr", nil):title;
		PKALERTVIEW(nil,title , nil,NSLocalizedString(@"kOK", nil) ,nil,nil);

	}
}

- (void)accountManager:(PKAccountManager*)accountManager removeAccount:(BOOL)isSuccess errorCode:(PKAccountErrorCode)errCode
{
	[PKToastView dismissWithAnimation:YES];
	if (isSuccess)
	{	
		PumpkinAppDelegate* appDelegate = (PumpkinAppDelegate*)[[UIApplication sharedApplication] delegate];
		[appDelegate showRegisterOrLoginViewController];
		//PKALERTVIEW(nil, NSLocalizedString(@"kRemoveAccountSuc", nil), nil,NSLocalizedString(@"kOK", nil),nil,nil);
	}
	else 
	{
		NSString* title =NSLocalizedString(@"kRemoveAccountErr", nil);
		title = errCode==PKNetworkErr?NSLocalizedString(@"kRemoveAccountNetWorkErr", nil):title;
		PKALERTVIEW(nil,title , nil,NSLocalizedString(@"kOK", nil) ,nil,nil);
	}
}

@end
