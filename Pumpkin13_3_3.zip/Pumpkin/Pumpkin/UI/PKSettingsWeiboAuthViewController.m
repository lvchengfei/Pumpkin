//
//  PKSettingsWeiboAuthViewController.m
//  Pumpkin
//
//  Created by lv on 7/14/12.
//  Copyright (c) 2012 XXX. All rights reserved.
//

#import "PKSettingsWeiboAuthViewController.h"
#import "PKLogicEngine.h"
#import "PKUIConst.h"
#import "WeiboKey.h"
#import "PKToastView.h"
#import "PumpkinAppDelegate.h"

static PKShareWeiboAuth* shareWeiboAutho_ = nil;

@interface PKSettingsWeiboAuthViewController ()

- (void)authoriseSinaWeibo;
//- (void)authoriseSinaWeiboSuccess:(NSData*)data;
//- (void)authoriseSinaWeiboError:(NSError*)error;
- (void)authoriseTencentWeibo;
//- (void)authoriseTencentWeiboSuccess:(NSData*)data;
//- (void)authoriseTencentWeiboError:(NSError*)error;
//- (void)authoriseNetEaseWeibo;
//- (void)authoriseNetEaseWeiboSuccess:(NSData*)data;
//- (void)authoriseNetEaseWeiboError:(NSError*)error;

- (void)authoriseKaiXin;

- (CGAffineTransform)transformForOrientation;
- (void)showWebViewWith:(UIWebView*)webView;
- (void)dismissWebView;

@end

@implementation PKSettingsWeiboAuthViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
		shareWeiboAutho_ = [[PKLogicEngine sharedInstance] getBusinessInstance:@"PKShareWeiboAuth"];
		sinaWeiboEngine_ = [WBEngine WBEngineWithAppKey:SINAAPPKEY appSecret:SINAAPPSECRET];
		tencentWeiboEngine_ = [OpenSdkOauth openSdkOauth:[OpenSdkBase getAppKey]  appSecret:[OpenSdkBase getAppSecret]];
		tencentContainerView_ = [[UIView alloc] initWithFrame:[UIScreen mainScreen].bounds];
		kaixinEngine_ = [Kaixin kaixinInstanceWithAppId:KXAPPKEY reDirectURL:KXRedirectURL secretKey:KXAPPSECRET];
    }
    return self;
}

- (void)dealloc
{
	shareWeiboAutho_  = nil;
	sinaWeiboEngine_  = nil;
	tencentWeiboEngine_ = nil;
	[tencentContainerView_ release];
	tencentContainerView_ = nil;
	[super dealloc];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
	self.navigationController.navigationBar.tintColor = kNaviCtlColor;

}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [shareWeiboAutho_ numberOfWeiboAutho];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	static NSString *CellIdentifier = @"showWeiboAuthoCell";
    
	PKMyCardTableViewCell* cell = (PKMyCardTableViewCell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	if (cell == nil) {
		cell = [[[PKMyCardTableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:CellIdentifier] autorelease];
		cell.selectionStyle = UITableViewCellSelectionStyleNone;
	}
	cell.textLabel.text = [shareWeiboAutho_ titleOfWeiboAuthoAtIndex:indexPath.row];
    cell.checked  = [shareWeiboAutho_ isWeiboAuthoAtIndex:indexPath.row];
	cell.delegate = self;
	cell.section = indexPath.section;
	cell.row = indexPath.row;
    [cell showImageButton:YES];
    return cell;
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
}

-(void)tableViewCell:(PKMyCardTableViewCell*)tableViewCell buttonStatusChanged:(BOOL)status
{
	NSIndexPath* indexPath = [self.tableView indexPathForCell:tableViewCell];
	switch (indexPath.row)
	{
		case kSinaWeibo:
			//取消授权
			if (!tableViewCell.checked)
			{
				[shareWeiboAutho_  setWeiboAuthoAtIndex:kSinaWeibo value:NO];
			}
			else
			{
				[self authoriseSinaWeibo];
			}
			break;
		case kTencentWeibo:
			//取消授权
			if (!tableViewCell.checked)
			{
				[shareWeiboAutho_ setWeiboAuthoAtIndex:kTencentWeibo value:NO];
			}
			else
			{
				[self authoriseTencentWeibo];
			}
			break;
		case kKaiXin:
			//取消授权
			if (!tableViewCell.checked)
			{
				[shareWeiboAutho_ setWeiboAuthoAtIndex:kKaiXin value:NO];
			}
			else 
			{
				[self authoriseKaiXin];
			}
			
			break;
		default:
			break;
	}
	
}


#pragma mark - WeiBoShare Sina

- (void)authoriseSinaWeibo
{
	if ([sinaWeiboEngine_ isLoggedIn]) 
	{
		[shareWeiboAutho_  setWeiboAuthoAtIndex:kSinaWeibo value:YES];
	}
	else 
	{
		[PKToastView showWithTitle:@"正在载入" animation:YES];
		sinaWeiboEngine_.delegate = self;
		[sinaWeiboEngine_ logIn];		
	}
}

// Log in successfully.
- (void)engineDidLogIn:(WBEngine *)engine
{
	[PKToastView dismissWithAnimation:NO];
	[shareWeiboAutho_  setWeiboAuthoAtIndex:kSinaWeibo value:YES];
	[self.tableView reloadData];
}

// Failed to log in.
// Possible reasons are:
// 1) Either username or password is wrong;
// 2) Your app has not been authorized by Sina yet.
- (void)engine:(WBEngine *)engine didFailToLogInWithError:(NSError *)error
{
	[PKToastView dismissWithAnimation:NO];
	PKALERTVIEW(nil, @"授权出错！", nil,@"确定",nil,nil);
	[self.tableView	reloadData];
}

//cancel opertion
- (void)engine:(WBEngine *)engine cancelAuthorized:(NSError *)error
{
	[self.tableView	reloadData];
}


#pragma mark - WeiBoShare Tencent

- (void)authoriseTencentWeibo
{
	
	if ([tencentWeiboEngine_ isLogIn]) 
	{
		[shareWeiboAutho_  setWeiboAuthoAtIndex:kTencentWeibo value:YES];
	}
	else 
	{
		[PKToastView showWithTitle:@"正在载入" animation:YES];
		UIWebView *webView = [[UIWebView alloc] initWithFrame:CGRectMake(0, 44, 320,  ([[UIScreen mainScreen] bounds].size.height)-64)];
		webView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
		webView.delegate = self;
		webView.tag = 5;
		[self showWebViewWith:webView];
		[tencentWeiboEngine_ doWebViewAuthorize:webView];
		[webView	release];
	}
	
}


#define kTransitionDuration 0.3
- (CGAffineTransform)transformForOrientation 
{
	UIInterfaceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation;
	if (orientation == UIInterfaceOrientationLandscapeLeft) {
		return CGAffineTransformMakeRotation(M_PI*1.5);
	} else if (orientation == UIInterfaceOrientationLandscapeRight) {
		return CGAffineTransformMakeRotation(M_PI/2);
	} else if (orientation == UIInterfaceOrientationPortraitUpsideDown) {
		return CGAffineTransformMakeRotation(-M_PI);
	} else {
		return CGAffineTransformIdentity;
	}
}

- (void)showWebViewWith:(UIWebView*)webView
{
	//Enable show Message
	[OpenSdkBase setCancel:NO];
	
	if ([tencentContainerView_.subviews count] == 0) 
	{
		//添加一个头
		UIButton *titleBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 320, 44)];
		[titleBtn setBackgroundImage:[UIImage imageNamed:@"head"]
							forState:UIControlStateHighlighted];
		[titleBtn setBackgroundImage:[UIImage imageNamed:@"head"]
							forState:UIControlStateNormal];
		[tencentContainerView_ addSubview:titleBtn];
		[titleBtn release];
		
		UIButton *backBtn = [[UIButton alloc] initWithFrame:CGRectMake(10, 0, 60, 45)];
		[backBtn setTitle:@"取消" forState:UIControlStateNormal];
		backBtn.titleLabel.font = [UIFont systemFontOfSize:14];
		backBtn.titleLabel.adjustsFontSizeToFitWidth = TRUE;
		[backBtn addTarget:self
					action:@selector(dismissWebView)
		  forControlEvents:UIControlEventTouchUpInside];
		[backBtn setBackgroundImage:[UIImage imageNamed:@"bianji.png"] 
						   forState:UIControlStateNormal];
		[backBtn setBackgroundImage:[UIImage imageNamed:@"bianjidown.png"] 
						   forState:UIControlStateHighlighted];
		[tencentContainerView_ addSubview:backBtn];
		[backBtn release];
	
	}

	[tencentContainerView_ addSubview:webView];

	
	UIWindow *window = [UIApplication sharedApplication].keyWindow;
	if (!window) {
		window = [[UIApplication sharedApplication].windows objectAtIndex:0];
	}
	tencentContainerView_.frame = CGRectMake(0, 20, 320, [[UIScreen mainScreen] bounds].size.height);
	[window addSubview:tencentContainerView_];
	
	
//	tencentContainerView_.transform = CGAffineTransformScale([self transformForOrientation], 0.001, 0.001);
//	[UIView beginAnimations:nil context:nil];
//	[UIView setAnimationDuration:kTransitionDuration/1.5];
//	[UIView setAnimationDelegate:self];
//	[UIView setAnimationDidStopSelector:@selector(bounce1AnimationStopped)];
//	tencentContainerView_.transform = CGAffineTransformScale([self transformForOrientation], 1.1, 1.1);
//	[UIView commitAnimations];
}

- (void)dismissWebView
{
	[PKToastView dismissWithAnimation:NO];
	//disable show message when cancel
	[OpenSdkBase setCancel:YES];
	[tencentContainerView_ removeFromSuperview];
	UIView *_curWebView = [tencentContainerView_ viewWithTag:5];
	[(UIWebView *)_curWebView loadHTMLString:@"" baseURL:nil];
	[self.tableView reloadData];
}

#pragma mark - UIWebView Delegate Methods
/*
 * 当前网页视图被指示载入内容时得到通知，返回yes开始进行加载
 */
- (BOOL) webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {
    
	[PKToastView dismissWithAnimation:NO];

    NSURL* url = request.URL;
	
	NSRange start = [[url absoluteString] rangeOfString:oauth2TokenKey];
    
    //如果找到tokenkey,就获取其他key的value值
	if (start.location != NSNotFound)
	{
        NSString *accessToken = [OpenSdkBase getStringFromUrl:[url absoluteString] needle:oauth2TokenKey];
        NSString *openid = [OpenSdkBase getStringFromUrl:[url absoluteString] needle:oauth2OpenidKey];
        NSString *openkey = [OpenSdkBase getStringFromUrl:[url absoluteString] needle:oauth2OpenkeyKey];
		NSString *expireIn = [OpenSdkBase getStringFromUrl:[url absoluteString] needle:oauth2ExpireInKey];
        
		NSDate *expirationDate =nil;
		if (tencentWeiboEngine_.expireIn != nil) {
			int expVal = [tencentWeiboEngine_.expireIn intValue];
			if (expVal == 0) {
				expirationDate = [NSDate distantFuture];
			} else {
				expirationDate = [NSDate dateWithTimeIntervalSinceNow:expVal];
			} 
		} 
        
        //NSLog(@"token is %@, openid is %@, expireTime is %@", accessToken, openid, expirationDate);
        
        if ((accessToken == (NSString *) [NSNull null]) || (accessToken.length == 0) 
            || (openid == (NSString *) [NSNull null]) || (openkey.length == 0) 
            || (openkey == (NSString *) [NSNull null]) || (openid.length == 0))
		{
            [tencentWeiboEngine_ oauthDidFail:InWebView success:YES netNotWork:NO];
        }
        else 
		{
            [tencentWeiboEngine_ oauthDidSuccess:accessToken accessSecret:nil openid:openid openkey:openkey expireIn:expireIn];
			[shareWeiboAutho_  setWeiboAuthoAtIndex:kTencentWeibo value:YES];
        }
		
		[self dismissWebView];
        
		return NO;
	}
	else
	{
        start = [[url absoluteString] rangeOfString:@"code="];
        if (start.location != NSNotFound)
		{
            [tencentWeiboEngine_ refuseOauth:url];
        }
	}
    return YES;
}


/*
 * 页面加载失败时得到通知，可根据不同的错误类型反馈给用户不同的信息
 */
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error {
    //NSLog(@"no network:errcode is %d, domain is %@", error.code, error.domain);
    
	[PKToastView dismissWithAnimation:NO];

    if (!([error.domain isEqualToString:@"WebKitErrorDomain"] && error.code == 102)) 
	{
        [tencentWeiboEngine_ oauthDidFail:InWebView success:NO netNotWork:YES];
		[self dismissWebView];
	}
}

#pragma mark - WeiBoShare KaiXin

- (void)authoriseKaiXin
{
	if ([kaixinEngine_ isSessionValid]) 
	{
		[shareWeiboAutho_  setWeiboAuthoAtIndex:kKaiXin value:YES];
	}
	else
	{
		[kaixinEngine_ authorizeDelegate:self];
		[kaixinEngine_ authorizeWithKXAppAuth];
	}

}

/**
 * Called when the user has logged in successfully.
 */
- (void)KaixinDidLogin 
{
	[PKToastView dismissWithAnimation:NO];
    [shareWeiboAutho_ setWeiboAuthoAtIndex:kKaiXin value:YES];
	[self.tableView reloadData];
}


/**
 * Called when the user dismissed the dialog without logging in.
 */
- (void)KaixinDidNotLogin:(BOOL)cancelled
{
	[PKToastView dismissWithAnimation:NO];
	[self.tableView	reloadData];
}

/**
 * Called when an error prevents the request from completing successfully.
 */
- (void)request:(KaixinRequest *)request didFailWithError:(NSError *)error
{
	[PKToastView dismissWithAnimation:NO];
	[self.tableView	reloadData];
}
/*
- (void)authoriseTencentWeiboSuccess:(NSData*)data
{
	[shareWeiboAutho_ setWeiboAuthoAtIndex:kTencentWeibo value:YES];
}

- (void)authoriseTencentWeiboError:(NSError*)error
{
	
}

#pragma mark - WeiBoShare NetEase

- (void)authoriseNetEaseWeibo
{
    [[WBShareKit mainShare] setDelegate:self];
	[[WBShareKit mainShare] startWyOauthWithSelector:@selector(authoriseNetEaseWeiboSuccess:) withFailedSelector:@selector(authoriseNetEaseWeiboError:)];
	
}

- (void)authoriseNetEaseWeiboSuccess:(NSData*)data
{
	[shareWeiboAutho_ setWeiboAuthoAtIndex:kNetEaseWeibo value:YES];
}

- (void)authoriseNetEaseWeiboError:(NSError*)error
{
	
}

*/
@end
