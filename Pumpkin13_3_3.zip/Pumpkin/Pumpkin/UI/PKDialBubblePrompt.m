//
//  PKDialRefreshTableHeaderView.h
//  Pumpkin
//
//  Created by lv on 2/28/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import "PKDialBubblePrompt.h"

@interface PKDialBubblePrompt ()
- (void)bubbleDismiss;
@end

@implementation PKDialBubblePrompt

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        proLabel_=[[UILabel alloc]initWithFrame:CGRectMake(0, 0,frame.size.width,frame.size.height)];

    }
    return self;
}
- (void)bubblePrompt:(NSString*)message
{
    proLabel_.backgroundColor=[UIColor colorWithRed:0 green:0.5 blue:1 alpha:1];

    //proLabel_.layer.cornerRadius=(CGFloat)8.0f;
    proLabel_.textColor=[UIColor whiteColor];
    proLabel_.textAlignment = UITextAlignmentCenter;
    proLabel_.text=message;
    
    proLabel_.alpha = 0.0;
	[UIView animateWithDuration:0.3 animations:^(void){proLabel_.alpha =1.0; [self addSubview:proLabel_];}];
//    CATransition *transition=[CATransition animation];
//    transition.timingFunction=UIViewAnimationCurveEaseInOut;
//    transition.type=kCATransitionPush;
//    transition.subtype=kCATransitionFromBottom;
//    transition.duration=0.3;
//    
//    [proLabel_.layer addAnimation:transition forKey:nil];
//    [self addSubview:proLabel_ ];
    [self performSelector:@selector(bubbleDismiss) withObject:nil afterDelay:1.5];
    
    
}
- (void)bubbleDismiss
{
    if (self) {
        [UIView beginAnimations:nil context:nil];//启动动画
        [UIView setAnimationDuration:0.5];
        [UIView setAnimationDelegate:self];
		[self removeFromSuperview];
        [UIView commitAnimations];//动画提交 
    }
}


-(void)dealloc
{
    [proLabel_ release];
    [super dealloc];
}
@end
