//
//  PKMyCardSignatureEditController.m
//  Pumpkin
//
//  Created by lv on 7/3/12.
//  Copyright (c) 2012 XXX. All rights reserved.
//

#import "PKMyCardSignatureEditController.h"
#import "PKUIConst.h"
#import "PKLogicEngine.h"
#import "PKMyCardSignatureSynController.h"
#import "PKToastView.h"
#import "PumpkinAppDelegate.h"

//#import "WBShareKit.h"

@interface PKMyCardSignatureEditController ()
- (void)signatureUpdateButtonPressed:(id)sender;
- (void)signatureSharedButtonPressed:(id)sender;

//- (void)sendRecordTicket:(OAServiceTicket *)ticket finishedWithData:(NSMutableData *)data;
//- (void)sendRecordTicket:(OAServiceTicket *)ticket failedWithError:(NSError *)error;
- (void)sendSinaWeibo;
- (void)sendTencentWeibo;
- (void)sendKaixinMessage;
//- (void)sendNetEaseWeibo;
//- (void)showWeiBoPrompt:(PKWeiboAuthType)weiboType;
@end

@implementation PKMyCardSignatureEditController
@synthesize myCardEngine = myCardEngine_;

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
		signatureBackView_ = [[UIView alloc] initWithFrame:CGRectZero];		
		UIImageView* bgView = [[UIImageView alloc] initWithFrame:kSignatureBackRect];
		bgView.contentMode = UIViewContentModeCenter;
		bgView.image = [PKUtils myCardImageWithName:@"signature_back.png"];
		
		signatureTextView_ = [[UITextView alloc] initWithFrame:CGRectZero];
		signatureTextView_.backgroundColor = [UIColor whiteColor];
		signatureTextView_.font = [UIFont systemFontOfSize:20];
		signatureTextView_.textAlignment = UITextAlignmentLeft;
		[signatureBackView_		addSubview:bgView];
		[signatureBackView_		addSubview:signatureTextView_];
		[bgView					release];
		
		[signatureBackView_	setFrame:kSignatureBackRect];
		[signatureTextView_	setFrame:kSignatureTextRect];
		
		shareSignatureButton_  = [[UIButton buttonWithType:UIButtonTypeCustom] retain];
		UIImage* norImage = [PKUtils commonImageWithName:@"login_button_normal.png"];
		norImage = [norImage stretchableImageWithLeftCapWidth:(NSInteger)(norImage.size.width/2) topCapHeight:(NSInteger)(norImage.size.height/2)];
		UIImage* highLightImage = [PKUtils commonImageWithName:@"login_button_pressed.png"];
		highLightImage = [highLightImage stretchableImageWithLeftCapWidth:(NSInteger)(highLightImage.size.width/2)  topCapHeight:(NSInteger)(highLightImage.size.height/2)];
		[shareSignatureButton_ setBackgroundImage:norImage   forState:UIControlStateNormal];
		[shareSignatureButton_ setBackgroundImage:highLightImage forState:UIControlStateHighlighted];
		[shareSignatureButton_ setTitle:NSLocalizedString(@"kSignatureSynchronize", nil) forState:UIControlStateNormal];
		shareSignatureButton_.titleLabel.font = [UIFont systemFontOfSize:20];
		[shareSignatureButton_	addTarget:self action:@selector(signatureSharedButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
		[shareSignatureButton_	setFrame:kSignatureShareRect];
    
		clearHeadView_ = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.tableView.bounds.size.width, 45)];
		clearHeadView_.backgroundColor = [UIColor clearColor];
		
		signatureEngine_ = [[PKLogicEngine sharedInstance] getBusinessInstance:@"PKMyCardSignature"];
		signatureEngine_.delegate = self;
		
		shareAuth_ = [[PKLogicEngine sharedInstance] getBusinessInstance:@"PKShareWeiboAuth"];

		sinaEngine_ = [WBEngine WBEngineWithAppKey:SINAAPPKEY appSecret:SINAAPPSECRET];
		sinaEngine_.delegate = self;
		
		tencentAuthEngine_ = [OpenSdkOauth openSdkOauth:[OpenSdkBase getAppKey]  appSecret:[OpenSdkBase getAppSecret]];
		kaixinEngine_ = [Kaixin kaixinInstanceWithAppId:KXAPPKEY reDirectURL:KXRedirectURL secretKey:KXAPPSECRET];

	}
    return self;
}

-(void)dealloc
{
	shareAuth_		 = nil;
	myCardEngine_	 = nil;
	signatureEngine_ = nil;
	kaixinEngine_	 = nil;
	[signatureBackView_			release];
	[signatureTextView_			release];
	[clearHeadView_				release];
	[shareSignatureButton_		release];	
	[super dealloc];
}

- (void)viewDidLoad
{
    [super viewDidLoad];

	self.navigationController.navigationBar.tintColor = kNaviCtlColor;
	self.view.backgroundColor = kMyCardBackgroundColor;
	self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
	self.title = NSLocalizedString(@"kSignatureEdit", nil);
	
	UIBarButtonItem* rightButton = [[UIBarButtonItem alloc] initWithTitle:@"保存" style:UIBarButtonItemStylePlain target:self action:@selector(signatureUpdateButtonPressed:)];
	self.navigationItem.rightBarButtonItem = rightButton;
	[rightButton	release];
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	NSArray* identifierArr  = [NSArray arrayWithObjects:@"Cell1",@"Cell2", nil];
	NSString*CellIdentifier = [identifierArr objectAtIndex:indexPath.section];
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell==nil)
	{
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
		cell.selectionStyle = UITableViewCellSelectionStyleNone;
	}
	if (indexPath.section==0)
	{
		signatureTextView_.text = [signatureEngine_ signatureOfMyCard];
		[cell addSubview:signatureBackView_];
	}
	else
	{
		[cell addSubview:shareSignatureButton_];
	}
    
    return cell;
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{

}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	if (indexPath.section==0) 
	{
		return kSignatureTextHeight+kSignatureTextOrignY*2;
	}
	else if(indexPath.section==1)
	{
		return kSignatureShareRect.size.height;
	}
	return 0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
	
	if (section==0) {
		return 10;
	}
	else if (section==1){
		return clearHeadView_.frame.size.height;
	}
	return 0;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{

	return  clearHeadView_;	
}

#pragma mark - Private Method

- (void)signatureUpdateButtonPressed:(id)sender
{
	if ([signatureTextView_.text length]>0) 
	{
		[signatureTextView_ resignFirstResponder];
		signatureEngine_.delegate = self;
		BOOL result = [signatureEngine_	syncMyCardSignature:signatureTextView_.text];
		if (result) 
		{
			[PKToastView showWithTitle:@"正在上传签名" animation:YES];
		}
	}	
}

- (void)signatureSharedButtonPressed:(id)sender
{
//	PKMyCardSignatureSynController* signatureSynCtl = [[PKMyCardSignatureSynController alloc] initWithStyle:UITableViewStylePlain];
//	[signatureSynCtl setSignatrueText:signatureTextView_.text];
//	[self.navigationController pushViewController:signatureSynCtl animated:YES];
//	[signatureSynCtl	release];
	
	[signatureTextView_ resignFirstResponder];
	
	UIActionSheet* actionSheet = [[UIActionSheet alloc] initWithTitle:@"分享到" delegate:self cancelButtonTitle:nil destructiveButtonTitle:nil otherButtonTitles:nil, nil];
	for (NSInteger i=0; i< [shareAuth_ numberOfWeiboAutho]; i++)
	{
		NSString* title = [shareAuth_ titleOfWeiboAuthoAtIndex:i];
		[actionSheet addButtonWithTitle:title];
	}
	[actionSheet addButtonWithTitle:NSLocalizedString(@"kCancel", nil)];
	[actionSheet showFromTabBar:self.tabBarController.tabBar];
	[actionSheet release];
}

- (void)showWeiBoPrompt:(PKWeiboAuthType)weiboType
{
	NSString* weibo = [shareAuth_ titleOfWeiboAuthoAtIndex:weiboType];
	NSString* title = [NSString stringWithFormat:@"您还未开启%@授权，请到设置项设置！",weibo];
	UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title message:nil delegate:nil cancelButtonTitle:NSLocalizedString(@"kOK", nil)  otherButtonTitles:NSLocalizedString(@"kCancel", nil),nil];
	alertView.delegate = self;
	[alertView show];
	[alertView release];
}

#pragma mark - PKMyCardSignatureProtocol

- (void)signature:(PKMyCardSignature *)signature uploadSignature:(BOOL)isSuccess errorCode:(NSInteger)errCode
{
	[PKToastView dismissWithAnimation:YES];
	isRuning_ = NO;	
	if (isAutoSaveSignature_)
	{
		return;
	}
	if (isSuccess)
	{
		[self.navigationController popViewControllerAnimated:YES];
	}
	else 
	{
		NSString* errTitle = nil;
		if (errCode==kNetWorkErr) 
		{
			errTitle = NSLocalizedString(@"kNetWorkError", nil);
		}
		else 
		{
			errTitle = NSLocalizedString(@"kSignatureSynError", nil);

		}	
		
		UIAlertView *tmpAlertView = [[UIAlertView alloc] initWithTitle:errTitle
															   message:nil 
															  delegate:self 
													 cancelButtonTitle:NSLocalizedString(@"kOK", nil) 
													 otherButtonTitles:nil];
		[tmpAlertView show];
		[tmpAlertView release];
	}

}

#pragma mark - UIActionSheetDelegate

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{

	switch (buttonIndex) {
		case kSinaWeibo:
			[self sendSinaWeibo];
			break;
		case kTencentWeibo:
			[self sendTencentWeibo];
			break;
		case kKaiXin:
			[self sendKaixinMessage];
			break;
		default:
			break;
	}
}


#pragma mark - UIAlertVeiw Delegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
		if (buttonIndex==0)
		{
			/*
			if ([signatureTextView_.text length]>0) 
			{
				isAutoSaveSignature_ = YES;
				isRuning_ = YES;
				[signatureTextView_ resignFirstResponder];
				signatureEngine_.delegate = self;
				BOOL result = [signatureEngine_	syncMyCardSignature:signatureTextView_.text];
				if (result) 
				{
					[PKToastView showWithTitle:@"正在保存签名" animation:YES];
				}
			}	
			
			while (isRuning_)
			{
				[[NSRunLoop currentRunLoop] runUntilDate:[NSDate dateWithTimeIntervalSinceNow:0.5]];
			}
			 */
				
			PumpkinAppDelegate* appDelegate = (PumpkinAppDelegate*)[[UIApplication sharedApplication] delegate];
			[appDelegate tabBarControllerSeleted:3];
			
			//[PKUtils resetGoBackSignature];
			
			//[self.tabBarController setSelectedIndex:3];
			//[self.navigationController popViewControllerAnimated:NO];
		}
}


#pragma mark - WeiBoShare Sina

- (void)sendSinaWeibo
{
	NSString* text = signatureTextView_.text;
	if ([text length]>0)
	{
		if (![shareAuth_ isWeiboAuthoAtIndex:kSinaWeibo]||(![sinaEngine_ isLoggedIn])) 
		{
			[self showWeiBoPrompt:kSinaWeibo];
			return;
		}
		if ([PKUtils isNetWorkAvailable]) 
		{
			sinaEngine_.delegate = self;
			[sinaEngine_ sendWeiBoWithText:text image:nil];
		}
	}
}

- (void)engine:(WBEngine *)engine requestDidFailWithError:(NSError *)error
{
	PKALERTVIEW(nil, @"发布失败", nil,@"确定",nil,nil);
}

- (void)engine:(WBEngine *)engine requestDidSucceedWithResult:(id)result
{
	NSString* message = signatureTextView_.text;
	PKALERTVIEW(nil, @"发送微博成功", message,@"确定",nil,nil);
}


#pragma mark - WeiBoShare Tencent

- (void)sendTencentWeibo
{
	NSString* text = signatureTextView_.text;
	if ([text length]>0)
	{
		if (![shareAuth_ isWeiboAuthoAtIndex:kTencentWeibo]||![tencentAuthEngine_ isLogIn]) 
		{
			[self showWeiBoPrompt:kTencentWeibo];
			return;
		}
		if ([PKUtils isNetWorkAvailable]) 
		{
		[tencentEngine_	release];
		tencentEngine_ = [[OpenApi alloc] initForApi:tencentAuthEngine_.appKey appSecret:tencentAuthEngine_.appSecret];
		[tencentEngine_ publishWeibo:text jing:@"112.123456" wei:@"33.111252" format:@"json" clientip:@"113.108.76.195" syncflag:@"0"]; //发表微博
		}
	}
}


#pragma mark - Kaixin

- (void)sendKaixinMessage
{
	NSString* text = signatureTextView_.text;
	if ([text length]>0)
	{
		if (![shareAuth_ isWeiboAuthoAtIndex:kKaiXin]||![kaixinEngine_ isSessionValid]) 
		{
			[self showWeiBoPrompt:kKaiXin];
			return;
		}
		if ([PKUtils isNetWorkAvailable]) 
		{
			//记得在请求toaken时要请求records/add.json权限，否则不能使用该接口
			NSMutableDictionary* params = [NSMutableDictionary dictionaryWithCapacity:0];
			[params setObject:text forKey:@"content"];
			[kaixinEngine_ requestWithSeparateURL:@"https://api.kaixin001.com/records/add.json" params:params andHttpMethod:@"POST" andDelegate:self];
		}
	}
}

/**
 * Called when an error prevents the request from completing successfully.
 */
- (void)request:(KaixinRequest *)request didFailWithError:(NSError *)error
{
	PKALERTVIEW(nil, @"发布失败", nil,@"确定",nil,nil);
}

/**
 * Called when a request returns and its response has been parsed into
 * an object.
 *
 * The resulting object may be a dictionary, an array, a string, or a number,
 * depending on thee format of the API response.
 */
- (void)request:(KaixinRequest *)request didLoad:(id)result
{
	NSString* message = signatureTextView_.text;
	PKALERTVIEW(nil, @"发送开心网记录成功", message,@"确定",nil,nil);

}

/**
 * Called when a request returns a response.
 *
 * The result object is the raw response from the server of type NSData
 */
- (void)request:(KaixinRequest *)request didLoadRawResponse:(NSData *)data
{
	//Just For Debug
	//NSString* dataStr = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
	//NSLog(@">>>didLoadRawResponse %@\n\n%@",data,dataStr);
}

/*
#pragma mark - WeiBoShare NetEase 163
- (void)sendNetEaseWeibo
{
	NSString* text = signatureTextView_.text;
	if ([text length]>0)
	{
		if (![shareAuth_ isWeiboAuthoAtIndex:kTencentWeibo]) 
		{
			[self showWeiBoPrompt:kNetEaseWeibo];
			return;
		}
		[[WBShareKit mainShare] sendWyRecordWithStatus:text lat:0 lng:0 delegate:self successSelector:@selector(sendRecordTicket:finishedWithData:) failSelector:@selector(sendRecordTicket:failedWithError:)];
	}
}
*/
@end
