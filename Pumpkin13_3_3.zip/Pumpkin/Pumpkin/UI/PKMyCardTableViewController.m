//
//  PKMyCardTableViewController.m
//  Pumpkin
//
//  Created by lv on 2/27/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import "PKMyCardTableViewController.h"
#import "PKMyCardSignatureSynController.h"
#import "PKUIConst.h"
#import "PKUtils.h"
#import "PKPathUtil.h"
#import "PKToastView.h"


@interface PKMyCardTableViewController()
- (void)showTabBarDelay;
- (void)dismissTabBar;
- (UIImage*)saveAsAvatarImage:(UIImage*)image;

//- (void)keyboardWillShow:(NSNotification*)notification;
//- (void)keyboardWillHide:(NSNotification*)notification;

@end

static	CGFloat secHeadHeight= 45.0;
//static	CGFloat secFootHeight= 35.0;

@implementation PKMyCardTableViewController
@synthesize parentController = parentController_;
@synthesize myCardEngine = myCardEngine_;

- (id)init
{
	self = [super init];
	if (self) {
		cellDict_ = [[NSMutableDictionary alloc] initWithCapacity:0]; 
		clearHeadView_ = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.tableView.bounds.size.width, secHeadHeight)];
		clearHeadView_.backgroundColor = [UIColor clearColor];
		
		//[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
		//[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
	}
	return self;
}

- (void)dealloc
{
	//[[NSNotificationCenter defaultCenter] removeObserver:self];
	myCardEngine_ = nil;
	[clearHeadView_			release];
	[cellDict_				release];
    [super dealloc];
}


#pragma mark - View lifecycle

- (void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	[self.tableView reloadData];
}

- (void)viewDidLoad
{
    [super viewDidLoad];	
	self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
	self.view.backgroundColor = kBackgroundColor;
	self.navigationController.navigationBar.tintColor = kNaviCtlColor;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [myCardEngine_ numberOfSection];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	return [myCardEngine_	numberOfRowsInSection:section];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	UITableViewCell *cell =nil;
	PKMyCardSection* section = [myCardEngine_ sectionOfIndex:indexPath.section];
	switch (section.tagOfSection) {
		case kPKMyCardSectionHeadImage:
			{
				static NSString *kCellIdentifier = @"kPKMyCardAvatarInfoIdentifier";
				PKMyCardAvatarTableViewCell* tmpCell = (PKMyCardAvatarTableViewCell*)[tableView dequeueReusableCellWithIdentifier:kCellIdentifier];
				if (tmpCell == nil) 
				{
					PKMyCardSection* section = [myCardEngine_ sectionOfIndex:kPKMyCardSectionHeadImage];
					PKMyCardRow* row1 = [[section rowItemsArr] objectAtIndex:0];
					PKMyCardRow* row2 = [[section rowItemsArr] objectAtIndex:1];
					tmpCell = [[[PKMyCardAvatarTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:kCellIdentifier backType:kCellBackStyle4] autorelease];
					tmpCell.delegate = self;
					tmpCell.selectionStyle = UITableViewCellSelectionStyleNone;
					tmpCell.backgroundColor = [UIColor blueColor];
					tmpCell.lable1.text = [NSString stringWithFormat:@"%@:",row1.title];
					tmpCell.lable2.text = [NSString stringWithFormat:@"%@:",row2.title];
					tmpCell.textField1.text = row1.value;
					tmpCell.textField2.text = row2.value;
					tmpCell.headImageView.image = section.image;
					
				}
				cell = tmpCell;
			}
			break;
		case kPKMyCardSectionCellPhone:
		case kPKMyCardSectionDepartment:
		case kPKMyCardSectionQQ:
		case kPKMyCardSectionEmail:
		case kPKMyCardSectionWebSite:
		case kPKMyCardSectionMSN:// To Be Add
		case kPKMyCardSectionGTalk:
		case kPKMyCardSectionCompanyAddress:
		case kPKMyCardSectionHomeAddress:
		case kPKMyCardSectionTitle:
		case kPKMyCardSectionBirthday:
		case kPKMyCardSectionWorkPhone:
		{
			PKMyCardRow* row = [myCardEngine_ rowOfSectionIndex:indexPath.section rowIndex:indexPath.row];
			NSString* kCellIdentifier = row.title;
			//static NSString *kCellIdentifier = @"kPKMyCardGeneralInfoIdentifier";
			PKMyCardGenInfoTableViewCell* tmpCell = (PKMyCardGenInfoTableViewCell*)[tableView dequeueReusableCellWithIdentifier:kCellIdentifier];
			if (tmpCell == nil) 
			{
				tmpCell = [[[PKMyCardGenInfoTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:kCellIdentifier backType:kCellBackStyle3] autorelease];
				tmpCell.selectionStyle = UITableViewCellSelectionStyleNone;
				tmpCell.textField.text = row.value;
				tmpCell.textField.keyboardType = [myCardEngine_ keyBoardTypeOfSectionIndex:indexPath.section rowIndex:indexPath.row];

			}
			tmpCell.lable.text     = row.title;
			cell = tmpCell;
		}
			break;
		case kPKMyCardSectionAddItem:
		{
			static NSString *kCellIdentifier = @"kPKMyCardAddItemsIdentifier";
			PKMyCardGenInfoTableViewCell* tmpCell = (PKMyCardGenInfoTableViewCell*)[tableView dequeueReusableCellWithIdentifier:kCellIdentifier];
			if (tmpCell == nil) 
			{
				tmpCell = [[[PKMyCardGenInfoTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:kCellIdentifier backType:kCellBackStyle3] autorelease];
				tmpCell.selectionStyle = UITableViewCellSelectionStyleNone;
				tmpCell.textField.enabled = NO;
				UIImageView* imageView = [[UIImageView alloc]initWithImage:[PKUtils myCardImageWithName:@"add_nor.png"]];
				[imageView setCenter:CGPointMake(36, 20)];
				[tmpCell addSubview:imageView];
				tmpCell.textLabel.backgroundColor = [UIColor clearColor];
				float version = [[[UIDevice currentDevice] systemVersion] floatValue];
				if (version >= 6.0)
				{
					tmpCell.textLabel.textAlignment = NSTextAlignmentCenter;
				}
				else
				{
					tmpCell.textLabel.textAlignment = UITextAlignmentCenter;
				}
				tmpCell.textLabel.font = [UIFont systemFontOfSize:16];
				tmpCell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
				[imageView	release];
			}
			PKMyCardRow* row = [myCardEngine_ rowOfSectionIndex:indexPath.section rowIndex:indexPath.row];
			tmpCell.textLabel.text = row.title;
			cell = tmpCell;
		}
			break;
		default:
			break;
	}
	cell.tag = section.tagOfSection;
	[cellDict_ setObject:cell forKey:[NSNumber numberWithInt:section.tagOfSection]];
	return cell;

}



#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	[[tableView cellForRowAtIndexPath:indexPath] setSelected:NO animated:YES];
	PKMyCardSection* section = [myCardEngine_ sectionOfIndex:indexPath.section];
	if (section.tagOfSection==kPKMyCardSectionAddItem)
	{
		PKMyCardContactCellTableViewController* showCellsViewController = [[PKMyCardContactCellTableViewController alloc] initWithStyle:UITableViewStyleGrouped];
		showCellsViewController.delegate = self;
		showCellsViewController.myCardEngine = myCardEngine_;
		[((UIViewController*)parentController_).navigationController pushViewController:showCellsViewController animated:YES];
		[showCellsViewController	release];
	}
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	if (indexPath.section==kPKMyCardSectionHeadImage) 
	{
		return kavaterCellHeight;
	}
	else
	{
		return 40.0f;
	}
	
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
	if (section==kPKMyCardSectionHeadImage)
	{
		return 20.0f;
	}
	return 10.0;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
	if (section==kPKMyCardSectionHeadImage)
	{
			return  clearHeadView_;
	}
	else 
	{
		//return [sectionHeadViewArr_ objectAtIndex:section];
	}
	return  clearHeadView_;
	
}

#pragma mark - Public Method

- (void)cancelMyCardEdit
{
	[myCardEngine_ cancelMyCardEdit];
}

- (BOOL)saveMyCardEdit
{

	BOOL	isChanged = NO;
	NSArray* sectionArray = [myCardEngine_ sectionArr];
	NSInteger secIndex = 0 ;
	for (PKMyCardSection* section in sectionArray)
	{
		//NSIndexPath* indexPath = [NSIndexPath indexPathForRow:0	inSection:secIndex];
		//id cell = [self.tableView cellForRowAtIndexPath:indexPath];
		id cell  = [cellDict_ objectForKey:[NSNumber numberWithInt:section.tagOfSection]];
		if (section.tagOfSection == kPKMyCardSectionHeadImage)
		{
			PKMyCardAvatarTableViewCell* tmpCell = (PKMyCardAvatarTableViewCell*)cell;
			if ([tmpCell.textField1 isFirstResponder]) 
			{
				[tmpCell.textField1	resignFirstResponder];
			}
			if ([tmpCell.textField2 isFirstResponder]) 
			{
				[tmpCell.textField2	resignFirstResponder];
			}
			NSString* text1  = tmpCell.textField1.text;
			NSString* value1 = ((PKMyCardRow* )[[section rowItemsArr] objectAtIndex:0]).value;
			//NSLog(@">>>text1=%@,valu1=%@",text1,value1);
			if ((value1&&[value1 isEqualToString:text1]==NO)||(value1==nil&&[text1 length]>0)) 
			{
				isChanged = YES;
				((PKMyCardRow* )[[section rowItemsArr] objectAtIndex:0]).value = text1;
			}
			NSString* text2  = tmpCell.textField2.text;
			NSString* value2 = ((PKMyCardRow* )[[section rowItemsArr] objectAtIndex:1]).value;
			//NSLog(@">>>text2=%@,valu2=%@",text2,value2);
			if ((value2&&[value2 isEqualToString:text2]==NO)||(value2==nil&&[text2 length]>0)) 
			{
				isChanged = YES;
				((PKMyCardRow* )[[section rowItemsArr] objectAtIndex:1]).value = text2;
			}
		}
		else if(section.tagOfSection!= kPKMyCardSectionAddItem)
		{
			PKMyCardGenInfoTableViewCell* tmpCell = (PKMyCardGenInfoTableViewCell*)cell;
			if ([tmpCell.textField isFirstResponder]) 
			{
				[tmpCell.textField	resignFirstResponder];
			}
			NSString* text1  = tmpCell.textField.text;
			NSString* value1 = ((PKMyCardRow* )[[section rowItemsArr] objectAtIndex:0]).value;
			//NSLog(@">>>text=%@,value=%@",text1,value1);
			if ((value1&&[value1 isEqualToString:text1]==NO)||(value1==nil&&[text1 length]>0)) 
			{
				isChanged = YES;
				((PKMyCardRow* )[[section rowItemsArr] objectAtIndex:0]).value = text1;
			}
		}
		secIndex++;
	}
	
	//如果有变化,并且网络可用则上传
	if (isChanged)
	{
		if ([PKUtils isNetWorkAvailable])
		{
			[myCardEngine_ saveMyCardEdit];
		}
	}
	else
	{
		PKALERTVIEW(nil, @"没有更新内容！", nil,@"确定",nil,nil,nil);
	}
	return isChanged;
	
}

#pragma mark - Private Method

- (void)showTabBarDelay
{
	CGRect bounds = [[UIScreen mainScreen] bounds];
	UIViewController* parent =self.parentController;
	parent.tabBarController.view.frame = CGRectMake(0,0,bounds.size.width,bounds.size.height);	
	parent.tabBarController.tabBar.hidden = NO;
}

- (void)dismissTabBar
{
	UIViewController* parent =self.parentController;
	CGRect bounds = [[UIScreen mainScreen] bounds];
	CGRect tabBarFrame = parent.tabBarController.tabBar.frame;
	parent.tabBarController.view.frame = CGRectMake(0,0,bounds.size.width,bounds.size.height+tabBarFrame.size.height);
	parent.tabBarController.tabBar.hidden = YES;
}

- (UIImage*)saveAsAvatarImage:(UIImage*)image
{
	image = [PKUtils reSizeImage:image toSize:kMyCardAvatarImageSize];
	[PKUtils saveAvatarImage:image];
	return image;
}


#pragma mark actionsheet delegate

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex 
{

	if (buttonIndex == 0 || buttonIndex == 1) 
	{
		UIImagePickerController *picker = [[UIImagePickerController alloc] init];
		if(0 == buttonIndex)
		{
			picker.sourceType = UIImagePickerControllerSourceTypeCamera;
			if (![UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera]) 
			{   
				picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;   
			}  
		}
		else 
		{
			picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
		}
		//picker.allowsEditing = YES;
		picker.delegate = self;
		[self.parentController presentModalViewController:picker animated:YES];
		[picker release];
		[self performSelector:@selector(showTabBarDelay) withObject:nil afterDelay:0.0];
	}
    
}

#pragma mark - UIImagePickerControllerDelegate

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
	if ([PKUtils isNetWorkAvailable])
	{
		[PKToastView showWithTitle:@"正在上传中" animation:YES];
		UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
		image = [self saveAsAvatarImage:image];
		myCardEngine_.delegate = self;
		[myCardEngine_ saveAvatarImage:image];
	}
}


- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self.parentController dismissModalViewControllerAnimated:YES];
	[self dismissTabBar];
}


#pragma mark - UITextFieldDelegate

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
	//NSLog(@">>>textFieldDidBeginEditing");
}
//
//#pragma mark - PKSectionHeadViewDelegate
//
//-(void)sectionHeaderView:(PKSectionHeadView*)sectionHeaderView sectionClosed:(NSInteger)section
//{
////	[currentEditTextField_ resignFirstResponder];
////	currentEditTextField_ = nil;
//	
//	NSInteger countOfRowsToDelete = [self.tableView numberOfRowsInSection:section];
//    if (countOfRowsToDelete > 0) 
//	{
//        NSMutableArray *indexPathsToDelete = [[NSMutableArray alloc] init];
//        for (NSInteger i = 0; i < countOfRowsToDelete; i++) 
//		{
//            [indexPathsToDelete addObject:[NSIndexPath indexPathForRow:i inSection:section]];
//        }
//        [self.tableView deleteRowsAtIndexPaths:indexPathsToDelete withRowAnimation:UITableViewRowAnimationNone];//UITableViewRowAnimationTop
//		[indexPathsToDelete	release];
//	}
//	
//}

//#pragma mark - PKMyCardTableViewCellDelegate
//
//-(void)tableViewCell:(PKMyCardTableViewCell*)tableViewCell buttonStatusChanged:(BOOL)status
//{
//	//[myCard_ setSelected:status categroy:tableViewCell.section row:tableViewCell.row];
//}

#pragma mark - PKMyCardAvatarTableViewCellProtocol

- (void)headImagePressed
{
	UIActionSheet *sheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"拍照", @"相册", nil];
	[sheet showInView:self.view];
	[sheet release];
}

#pragma mark - PKAddContactCellsDelegate

- (void)selectedContactCell:(PKMyCardSectionItem)cell
{
	[self.tableView	reloadData];
}

#pragma mark - PKMyCardEngineProtocol

- (void)myCardEngine:(PKMyCardEngine*)myCardEngine uploadAvatar:(BOOL)isSuccess errorCode:(NSInteger)errCode
{	
	[PKToastView dismissWithAnimation:YES];
	if (isSuccess)
	{
		[self.parentController dismissModalViewControllerAnimated:YES];
		[self dismissTabBar];
		PKMyCardSection* section = [myCardEngine_ sectionOfIndex:kPKMyCardSectionHeadImage];
		PKMyCardAvatarTableViewCell* cell = [cellDict_ objectForKey:[NSNumber numberWithInt:kPKMyCardSectionHeadImage]];
		cell.headImageView.image = section.image;
	}
	else 
	{
		NSString* errTitle = nil;
		if (errCode==kNetWorkErr) 
		{
			errTitle = NSLocalizedString(@"kNetWorkError", nil);
		}
		else 
		{
			errTitle = NSLocalizedString(@"kMyCardAvatarUploadError", nil);
		}	
		
		UIAlertView *tmpAlertView = [[UIAlertView alloc] initWithTitle:errTitle
															   message:nil 
															  delegate:self 
													 cancelButtonTitle:NSLocalizedString(@"kOK", nil) 
													 otherButtonTitles:nil];
		[tmpAlertView show];
		[tmpAlertView release];
	}

}
@end
