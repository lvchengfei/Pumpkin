//
//  PKMyCardContactCellTableViewController.m
//  Pumpkin
//
//  Created by lv on 6/30/12.
//  Copyright (c) 2012 XXX. All rights reserved.
//

#import "PKMyCardContactCellTableViewController.h"
#import "PKUIConst.h"
#import "PKUtils.h"

@interface PKMyCardContactCellTableViewController ()
@end

@implementation PKMyCardContactCellTableViewController
@synthesize myCardEngine = myCardEngine_;
@synthesize delegate = delegate_;


- (void)viewDidLoad
{
    [super viewDidLoad];

	//self.view.backgroundColor = kBackgroundColor;
	self.navigationController.navigationBar.tintColor = kNaviCtlColor;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [myCardEngine_ numberOfCandidateSection];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell==nil)
	{
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
	}
	PKMyCardRow*	row = [myCardEngine_ firstRowOfCandidateSectionIndex:indexPath.row]; 
	cell.textLabel.text = row.title;
	cell.textLabel.font = [UIFont systemFontOfSize:20]; 
	cell.textLabel.textAlignment = UITextAlignmentCenter;
    return cell;
}


#pragma mark - Table view delegate

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
	if (section==0){
		return 25;
	}
	return 0;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
	if (section==0) {
		UIView* view = [[UIView alloc] initWithFrame:CGRectZero];
		view.backgroundColor = [UIColor clearColor];
		return [view autorelease];
	}
	return nil;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	[[tableView cellForRowAtIndexPath:indexPath] setSelected:NO animated:YES];
	[self.navigationController popViewControllerAnimated:YES];

	[myCardEngine_	selectCandidateSectionIndex:indexPath.row];
	[delegate_		selectedContactCell:indexPath.row];

}



@end
