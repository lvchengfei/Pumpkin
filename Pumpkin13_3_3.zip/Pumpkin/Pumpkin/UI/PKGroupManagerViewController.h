//
//  PKGroupManagerViewController.h
//  Pumpkin
//
//  Created by lv on 3/2/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PKContactEngine.h"


@interface PKGroupManagerViewController : UITableViewController <UITextFieldDelegate , UIAlertViewDelegate> 
{
	PKContactEngine*    contactEngine_;
	UITextField*		groupNameTextField_;
	NSInteger			curSelectedIndex_;
}

@end
