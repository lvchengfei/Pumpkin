//
//  PKLogInViewController.h
//  Pumpkin
//
//  Created by lv on 6/3/12.
//  Copyright (c) 2012 XXXXX. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PKAccountManager.h"

@interface PKLogInViewController : UITableViewController <PKAccountManagerProtocol>
{
	NSArray*		cellArr_;
	UIImageView*	backgroundView_;
	UITextField*	accountTextField_;
	UITextField*	passWordTextField_;
	UILabel*		showPassWordLabel_;
	UIButton*		checkButton_;
	UIButton*		logInButton_;
	UIButton*		forgetButton_;
	UIImage*		normalImage_;
	UIImage*		selectedImage_;
	BOOL			isShowPassWord_;
	
	PKAccountManager*		accountManager_;
	UIAlertView*			alertView_;
}

@end
