//
//  PKMyCardAvatarTableViewCell.h
//  Pumpkin
//
//  Created by lv on 6/19/12.
//  Copyright (c) 2012 XXX. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PKMyCardTableViewCellBase.h"

@protocol PKMyCardAvatarTableViewCellProtocol <NSObject>
@optional
- (void)headImagePressed;

@end

@interface PKMyCardAvatarTableViewCell : PKMyCardTableViewCellBase
{
	UIImageView*										headImageView_;
	UIImageView*										headBackView_;
	UIImageView*										editPenView1_;
	UIImageView*										editPenView2_;

	UILabel*											lable1_;
	UILabel*											lable2_;
	UITextField*										textField1_;
	UITextField*										textField2_;
	id<PKMyCardAvatarTableViewCellProtocol>				delegate_;
}
@property(nonatomic,assign) id<PKMyCardAvatarTableViewCellProtocol> delegate;
@property(nonatomic,assign) UILabel*	lable1;
@property(nonatomic,assign) UILabel*	lable2;
@property(nonatomic,assign) UITextField*	textField1;
@property(nonatomic,assign) UITextField*	textField2;
@property(nonatomic,readonly) UIImageView*   headImageView;


@end
