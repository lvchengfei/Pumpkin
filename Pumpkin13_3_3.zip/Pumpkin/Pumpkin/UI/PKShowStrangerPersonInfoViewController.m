//
//  PKShowStrangerPersonInfoViewController.m
//  Pumpkin
//
//  Created by lv on 8/5/12.
//  Copyright (c) 2012 XXX. All rights reserved.
//

#import "PKShowStrangerPersonInfoViewController.h"
#import "PKShowStrangerInfoTableViewCell.h"
#import "PKDefine.h"
#import "PKUtils.h"

@interface PKShowStrangerPersonInfoViewController ()
@property(nonatomic,retain) NSDictionary* personInfoDict;
@property(nonatomic,retain) NSArray*	  allKeysArray;


@end

@implementation PKShowStrangerPersonInfoViewController
@synthesize personInfoDict = personInfoDict_;
@synthesize allKeysArray = allKeysArray_;

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{
	[allKeysArray_	 release];
	[personInfoDict_ release];
	[super dealloc];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	self.title = @"详细信息";

}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
#pragma mark - Public Method

- (void)setShowPersonInfo:(NSDictionary*)person
{
	if (person)
	{
		NSMutableDictionary* dict = [NSMutableDictionary dictionaryWithCapacity:0];
		NSArray* allKeys = [person allKeys];
		for (NSString* key in allKeys)
		{
			id value = [person objectForKey:key];
			if (value&&[value isKindOfClass:[NSString class]]&&[value length]>0)
			{
				[dict setObject:value forKey:key];
			}
			else if(value&&[value isKindOfClass:[NSArray class]])
			{
				if ([key isEqualToString:@"ims"]) 
				{
					for (NSDictionary* imDict in value) 
					{
						NSString* typeKey = [imDict objectForKey:@"imType"];
						NSString* imValue = [imDict objectForKey:@"imAddr"];
						[dict setObject:imValue forKey:typeKey];
					}
				}
			}
		}
		
		allKeys = [dict allKeys];
		if ([allKeys count]>0)
		{
			self.personInfoDict = [NSDictionary dictionaryWithDictionary:dict];
			NSDictionary* itemDict = [PKUtils myCardAllPostKeyToItemsDictionary];
			self.allKeysArray = [allKeys sortedArrayUsingComparator:^NSComparisonResult(id obj1, id obj2) {
				return [[itemDict objectForKey:obj1] integerValue]-[[itemDict objectForKey:obj2] integerValue];
			}];
		}
	}
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{

	return [self.allKeysArray count];
    //return [[self.personInfoDict allKeys] count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";    
	PKShowStrangerInfoTableViewCell* tmpCell = (PKShowStrangerInfoTableViewCell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	if (tmpCell == nil) 
	{
		tmpCell = [[[PKShowStrangerInfoTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier backType:kCellBackStyle3] autorelease];
		tmpCell.selectionStyle = UITableViewCellSelectionStyleNone;
		
	}
	NSArray* allKeys = self.allKeysArray;//[self.personInfoDict allKeys];
	NSString* key   = objectAtIndex(allKeys, indexPath.section);
	NSString* value = [self.personInfoDict objectForKey:key]; 
	
	NSDictionary* dict1 = [PKUtils myCardAllPostKeyToItemsDictionary];
	NSDictionary* dict2 = [PKUtils myCardAllItemsTitleDictionary];
	NSString* title = [dict2 objectForKey:[dict1 objectForKey:key]];
	tmpCell.lable.text     = title;
	tmpCell.textField.text = value;
	return tmpCell;
}


#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{

}

@end
