//
//  PKShowAnimationInfoViewController.h
//  Pumpkin
//
//  Created by lv on 8/12/12.
//  Copyright (c) 2012 Baidu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PKShowAnimationInfoViewController : UIViewController
{
	UIWebView*				webView_;
	NSString*				imageName_;
}
@property(nonatomic,retain)NSString* imageName;

@end
