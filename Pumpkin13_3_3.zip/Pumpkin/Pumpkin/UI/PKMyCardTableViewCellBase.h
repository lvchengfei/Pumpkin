//
//  PKMyCardTableViewCellBase.h
//  Pumpkin
//
//  Created by lv on 6/19/12.
//  Copyright (c) 2012 XXX. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum 
{
	kCellBackStyle0 =0,
	kCellBackStyle1,
	kCellBackStyle2,
	kCellBackStyle3,
	kCellBackStyle4,
}PKCellBackStyle;


@interface PKMyCardTableViewCellBase : UITableViewCell <UITextFieldDelegate>
{
	UIImageView*						backgroundView_;
	PKCellBackStyle						backStyle_;
}
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString*)identifier backType:(PKCellBackStyle)backStyle;
@end
