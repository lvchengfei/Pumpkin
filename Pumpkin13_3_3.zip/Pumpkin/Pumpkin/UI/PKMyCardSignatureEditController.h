//
//  PKMyCardSignatureEditController.h
//  Pumpkin
//
//  Created by lv on 7/3/12.
//  Copyright (c) 2012 XXX. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PKMyCardEngine.h"
#import "PKMyCardSignature.h"
#import "PKShareWeiboAuth.h"
#import "WBEngine.h"
#import "WeiboKey.h"
#import "OpenApi.h"
#import "OpenSdkOauth.h"
#import "Kaixin.h"


@interface PKMyCardSignatureEditController : UITableViewController <UIActionSheetDelegate,UIWebViewDelegate,UIAlertViewDelegate, PKMyCardSignatureProtocol,WBEngineDelegate,KaixinRequestDelegate>
{
	PKMyCardEngine*					myCardEngine_;
	UIView*							signatureBackView_;
	UITextView*						signatureTextView_;
	UIView*							clearHeadView_;
	UIButton*						shareSignatureButton_;
	BOOL							isAutoSaveSignature_;
	BOOL							isRuning_;
	PKMyCardSignature*				signatureEngine_;
	PKShareWeiboAuth*				shareAuth_;

	WBEngine*						sinaEngine_;
	OpenApi*						tencentEngine_;
	OpenSdkOauth*					tencentAuthEngine_;
	Kaixin*							kaixinEngine_;
}
@property(nonatomic,assign)PKMyCardEngine*  myCardEngine;

@end
