//
//  PKShowStrangerInfoTableViewCell.h
//  Pumpkin
//
//  Created by lv on 8/5/12.
//  Copyright (c) 2012 XXX. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PKMyCardGenInfoTableViewCell.h"


@interface PKShowStrangerInfoTableViewCell : PKMyCardGenInfoTableViewCell

@end
