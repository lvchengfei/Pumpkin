//
//  PumpkinAppDelegate.h
//  Pumpkin
//
//  Created by lv on 2/27/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PKTabBarViewController.h"
#import "PKReachAbilityManager.h"

@interface PumpkinAppDelegate : NSObject <UIApplicationDelegate,UITabBarControllerDelegate,UINavigationControllerDelegate,UIAlertViewDelegate> {

	//UITabBarController* tabBarController_;
	PKTabBarViewController*		tabBarController_;
	UIImageView*				tabBarArrow_;
	BOOL						isHaveRegisterAccount_;
	PKReachAbilityManager*		reachAbilityManager_;
	BOOL						isEnterBackGround_;
	NSInteger					pushType_;
}

@property (nonatomic, retain)  IBOutlet UIWindow *window;
@property (nonatomic, readonly)	PKTabBarViewController*	tabBarController;


- (void)initTabBarController;
- (void)showTabBarController;
- (void)tabBarControllerSeleted:(NSInteger)index;
- (void)showRegisterOrLoginViewController;
- (void)solvePushNotification;

@end
