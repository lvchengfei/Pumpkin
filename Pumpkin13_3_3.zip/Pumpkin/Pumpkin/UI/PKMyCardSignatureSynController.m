//
//  PKMyCardSignatureSynController.m
//  Pumpkin
//
//  Created by lv on 3/17/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import "PKMyCardSignatureSynController.h"
#import <QuartzCore/QuartzCore.h>


static CGFloat   headViewHeight = 105.0;
static NSInteger kTextFieldTag = 101;
@interface PKMyCardSignatureSynController()
- (void)initWeiBoSynchronize;
- (void)rightButtonPressed:(id)sender;
@end

@implementation PKMyCardSignatureSynController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
		self.title = NSLocalizedString(@"kSignatureSynchronize", nil);
		CGRect rect = self.tableView.frame;
		CGRect txtRt= CGRectMake(10, 15, rect.size.width-20, headViewHeight-30);
		headView_ = [[UIView alloc] initWithFrame:txtRt];
		UITextView* textField = [[UITextView alloc] initWithFrame:txtRt];
		textField.layer.cornerRadius = 8.0;
		textField.layer.masksToBounds = YES;
		textField.backgroundColor = [UIColor grayColor];
		textField.tag = kTextFieldTag;
		[headView_ addSubview:textField];
		[textField	release];
		[self initWeiBoSynchronize];
		
		
    }
    return self;
}

- (void)dealloc
{
	[headView_	release];
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];

    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
 
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
	
	UIBarButtonItem* rightButton = [[UIBarButtonItem alloc] initWithTitle:@"发布" style:UIBarButtonItemStyleBordered target:self action:@selector(rightButtonPressed:)];
	self.navigationItem.rightBarButtonItem = rightButton;
	[rightButton	release];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Public Method
- (void)setSignatrueText:(NSString*)signature
{
	UITextView* textView = (UITextView*)[headView_ viewWithTag:kTextFieldTag];
	textView.text = signature;
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return [weiboSynchArr_ count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
	PKMyCardTableViewCell* cell = (PKMyCardTableViewCell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	if (cell == nil) {
		cell = [[[PKMyCardTableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:CellIdentifier] autorelease];
	}
	cell.textLabel.text = [weiboSynchArr_ objectAtIndex:indexPath.row];
    cell.checked  = [[weiboSeleteArr_ objectAtIndex:indexPath.row] boolValue];
	cell.delegate = self;
	cell.section = indexPath.section;
	cell.row = indexPath.row;
    [cell showImageButton:YES];
    return cell;
}



#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	[[headView_ viewWithTag:101]resignFirstResponder];
	PKMyCardTableViewCell* cell = (PKMyCardTableViewCell*)[tableView cellForRowAtIndexPath:indexPath];
	[cell setSelected:NO animated:YES];
	BOOL select = [[weiboSeleteArr_ objectAtIndex:indexPath.row] boolValue];
	select = !select;
	cell.checked = select;
	[weiboSeleteArr_ replaceObjectAtIndex:indexPath.row withObject:[NSNumber numberWithBool:select]];
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
	if (section==0) {
		return headView_;
	}
	return nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
	if (section==0) {
		return headViewHeight;
	}
	return 0.0f;
}

#pragma mark - Private Method
- (void)initWeiBoSynchronize
{
	weiboSynchArr_ = [[NSMutableArray alloc] initWithObjects:NSLocalizedString(@"kSinaWeibo", nil),
					  NSLocalizedString(@"kTencentWeibo", nil),NSLocalizedString(@"kTencentQzone", nil),
					  NSLocalizedString(@"kRenRen", nil),NSLocalizedString(@"kKaiXin", nil), nil];
	
	selectedCount_ = 1;
	weiboSeleteArr_ = [[NSMutableArray alloc] initWithCapacity:0];
	[weiboSeleteArr_ addObject:[NSNumber numberWithBool:YES]];
	for (NSInteger i=1; i< [weiboSynchArr_ count]; i++) {
		[weiboSeleteArr_ addObject:[NSNumber numberWithBool:NO]];
	}
	
	
}

- (void)rightButtonPressed:(id)sender
{
	UITextField* text = (UITextField*)[headView_ viewWithTag:101];
	if ([text.text length]<=0) {
		UIAlertView* alert = [[UIAlertView alloc] initWithTitle:@"请输入签名！" message:nil delegate:self cancelButtonTitle:@"确定" otherButtonTitles: nil];
		[alert show];
		[alert release];
		
	}
	else
	{
		
	}
}



#pragma mark - PKMyCardTableViewCellDelegate

-(void)tableViewCell:(PKMyCardTableViewCell*)tableViewCell buttonStatusChanged:(BOOL)status
{
	if (status) {
		selectedCount_++;
	}else if(selectedCount_>1){
		selectedCount_--;
		[weiboSeleteArr_ replaceObjectAtIndex:tableViewCell.row withObject:[NSNumber numberWithBool:status]];
	}else{
		[tableViewCell setChecked:YES];
	}
	
}

@end
