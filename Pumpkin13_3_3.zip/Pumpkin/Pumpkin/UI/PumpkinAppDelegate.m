//
//  PumpkinAppDelegate.m
//  Pumpkin
//
//  Created by lv on 2/27/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import "PumpkinAppDelegate.h"
#import "PKMyCardEngine.h"
#import "PKLogInOrRegisterViewController.h"
#import "PKContactEngine.h"
#import "PKContactViewController.h"
#import "PKMyCardRootController.h"
#import "PKDialAnimationViewController.h"
#import "PKSettingsRootViewController.h"
#import "PKUIConst.h"
#import "PKUtils.h"
#import "PKLogicEngine.h"
#import "PKToastView.h"


#import "PKSettingsWeiboAuthViewController.h"
#import "WBEngine.h"
#import "OpenSdkOauth.h"
#import "Kaixin.h"
#import "PKToastView.h"

@implementation PumpkinAppDelegate


@synthesize window=_window;
@synthesize tabBarController = tabBarController_;


#pragma mark - TabBar Arrow

- (CGFloat) horizontalLocationFor:(NSUInteger)tabIndex
{
	// A single tab item's width is the entire width of the tab bar divided by number of items
	CGFloat tabItemWidth = tabBarController_.tabBar.frame.size.width / tabBarController_.tabBar.items.count;
	// A half width is tabItemWidth divided by 2 minus half the width of the arrow
	CGFloat halfTabItemWidth = (tabItemWidth / 2.0) - (tabBarArrow_.frame.size.width / 2.0);
	
	// The horizontal location is the index times the width plus a half width
	return (tabIndex * tabItemWidth) + halfTabItemWidth;
}

- (void) addTabBarArrow
{
	//UIImage* tabBarArrowImage = [PKUtils contactImageWithName:@"tab_arrow.png"];
	UIImage* tabBarArrowImage = [PKUtils contactImageWithName:@"tab_select_bg.png"];
	tabBarArrow_= [[UIImageView alloc] initWithImage:tabBarArrowImage];
	// To get the vertical location we start at the bottom of the window, go up by height of the tab bar, go up again by the height of arrow and then come back down 2 pixels so the arrow is slightly on top of the tab bar.
	CGFloat verticalLocation = self.window.frame.size.height /*- tabBarController_.tabBar.frame.size.height*/ - tabBarArrowImage.size.height+1;
	tabBarArrow_.frame = CGRectMake([self horizontalLocationFor:0], verticalLocation, tabBarArrowImage.size.width, tabBarArrowImage.size.height);
	
	[self.window addSubview:tabBarArrow_];
}


- (void)tabBarController:(UITabBarController *)theTabBarController didSelectViewController:(UIViewController *)viewController
{
	//theTabBarController.selectedViewController.tabBarItem.image =  nil;
	
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:0.2];
	CGRect frame = tabBarArrow_.frame;
	frame.origin.x = [self horizontalLocationFor:tabBarController_.selectedIndex];
	tabBarArrow_.frame = frame;
	[UIView commitAnimations];  
	
}

#pragma mark - Life Cycle


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
	[PKToastView dismissWithAnimation:NO];
	//NSLog(@">>>didFinishLaunchingWithOptions launchOptions =%@  token=%@ ",launchOptions,[PKLogicEngine sharedInstance].pushToken);
	if ([[PKLogicEngine sharedInstance].pushToken length]==0) 
	{
		//show enable push notification alertView
		[[UIApplication sharedApplication] registerForRemoteNotificationTypes: UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeSound| UIRemoteNotificationTypeAlert];
	}
	
	reachAbilityManager_ = [[PKReachAbilityManager alloc] init];
	isHaveRegisterAccount_ = [PKUtils isHaveRegisterAccount];
	if(isHaveRegisterAccount_)
	{
		[self initTabBarController];
		//[self addTabBarArrow];
	}
	else 
	{
//#if TARGET_IPHONE_SIMULATOR
//		[self initTabBarController];
//		[self addTabBarArrow];
//#else
		PKLogInOrRegisterViewController* loginOrRegViewCtl = [[PKLogInOrRegisterViewController alloc] init];		
		UINavigationController* naviCtl = [[UINavigationController alloc] initWithRootViewController:loginOrRegViewCtl];
		self.window.rootViewController = naviCtl ;
		[loginOrRegViewCtl	release];
		[naviCtl			release];
//#endif

	}
	[self.window makeKeyAndVisible];
	
	if (launchOptions)
	{
		NSDictionary* dict1 = [launchOptions objectForKey:@"UIApplicationLaunchOptionsRemoteNotificationKey"];
		NSDictionary* dict = [dict1 objectForKey:@"aps"];
		pushType_ = [[dict objectForKey:@"type"] intValue];
		[[self class] cancelPreviousPerformRequestsWithTarget:self selector:@selector(solvePushNotification) object:nil];
		[self performSelector:@selector(solvePushNotification) withObject:nil afterDelay:0.1];
	}
    return YES;
}

- (void)application:(UIApplication*)application  didRegisterForRemoteNotificationsWithDeviceToken:(NSData*)deviceToken
{
	//NSLog(@"My token is: %@",  deviceToken);
	if ([deviceToken length]>0)
	{
		[PKLogicEngine sharedInstance].pushToken = deviceToken;
	}
}


- (void)application:(UIApplication*)application didFailToRegisterForRemoteNotificationsWithError:(NSError*)error
{
	NSLog(@"Failed  to get token, error: %@",  error);
} 

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo
{
	//app运行过程中收到push消息
	//NSLog(@">>>>didReceiveRemoteNotification=%@",userInfo);
	NSDictionary* dict = [userInfo objectForKey:@"aps"];
	pushType_ = [[dict objectForKey:@"type"] intValue];
	[[self class] cancelPreviousPerformRequestsWithTarget:self selector:@selector(solvePushNotification) object:nil];
	[self performSelector:@selector(solvePushNotification) withObject:nil];

}


- (void)applicationWillResignActive:(UIApplication *)application
{
	UINavigationController* navi = (UINavigationController*)tabBarController_.selectedViewController ;
	UIViewController* viewController =  navi.topViewController;
	if (viewController&&[viewController isKindOfClass:[PKMyCardRootController class]])
	{
		PKMyCardRootController* myCardViewController = (PKMyCardRootController*)viewController;
		[myCardViewController  cancelMyCardEditState];
	}


	[PKUtils resetSynServerInfo];
	/*
	 Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
	 Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
	 */
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
	[PKUtils resetSynServerInfo];
	[PKUtils resetImportAllFriendsFlag];
	isEnterBackGround_ = YES;
	/*
	 Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
	 If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
	 */
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
	[PKUtils resetAppActive];
	[self tabBarControllerSeleted:0];

	/*
	 Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
	 */
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
	/*
	 Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
	 */
	//reset badge number
	application.applicationIconBadgeNumber = 0;

	[PKContactEngine refreshSharedContactEngine];
	UIViewController* viewController = objectAtIndex(self.tabBarController.viewControllers, self.tabBarController.selectedIndex);
	if ([viewController isKindOfClass:[UIViewController class]])
	{
		[viewController viewWillAppear:YES];	
	}
}

- (void)applicationWillTerminate:(UIApplication *)application
{
	/*
	 Called when the application is about to terminate.
	 Save data if appropriate.
	 See also applicationDidEnterBackground:.
	 */
}

- (void)dealloc
{
	[PKLogicEngine			releaseSharedInstance];
	[WBEngine				releaseWBEngine];
	[OpenSdkOauth			releaseOpenSdkOauth];
	[Kaixin					releaseKaiXinInstace];
	
	[reachAbilityManager_	release];
	[tabBarArrow_			release];
	[tabBarController_		release];
	[_window				release];
    [super dealloc];
}

#pragma mark - Public Methods

- (void)initTabBarController
{
	NSString* contactStr  = NSLocalizedString(@"kTabBarContact", nil);
	NSString* myCardStr   = NSLocalizedString(@"kTabBarCard", nil);
	NSString* dialShowStr = NSLocalizedString(@"kTabBarDialShow", nil);
	NSString* settingsStr = NSLocalizedString(@"kTabBarSettings", nil);
	NSArray* titlesArr = [NSArray arrayWithObjects:contactStr,myCardStr,dialShowStr,settingsStr, nil]; 
	UIImage* image1 = [PKUtils commonImageWithName:@"tab_contactN.png"];
	UIImage* image2 = [PKUtils commonImageWithName:@"tab_cardsN.png"];
	UIImage* image3 = [PKUtils commonImageWithName:@"tab_callshowN.png"];
	UIImage* image4 = [PKUtils commonImageWithName:@"tab_settingsN.png"];
	NSArray* imageNArr = [NSArray arrayWithObjects:image1,image2,image3,image4, nil];
	UIImage* imageH1 = [PKUtils commonImageWithName:@"tab_contactH.png"];
	UIImage* imageH2 = [PKUtils commonImageWithName:@"tab_cardsH.png"];
	UIImage* imageH3 = [PKUtils commonImageWithName:@"tab_callshowH.png"];
	UIImage* imageH4 = [PKUtils commonImageWithName:@"tab_settingsH.png"];
	NSArray* imageHArr = [NSArray arrayWithObjects:imageH1,imageH2,imageH3,imageH4, nil];

	
	NSMutableArray* controllerArr = [[NSMutableArray alloc] initWithCapacity:0];
	PKContactViewController* ctCtl = [[PKContactViewController alloc] init];
	ctCtl.title = contactStr;
	
	UINavigationController* contactNavi = [[UINavigationController alloc] initWithRootViewController:ctCtl];
	PKMyCardRootController* psCtl  = [[PKMyCardRootController alloc] init];
	psCtl.title = myCardStr;

	UINavigationController* PersonNavi  = [[UINavigationController alloc] initWithRootViewController:psCtl];
	PKDialAnimationViewController* anCtl = [[PKDialAnimationViewController alloc] initWithStyle:UITableViewStylePlain];
	anCtl.title = dialShowStr;
	UINavigationController* aniNavi = [[UINavigationController alloc] initWithRootViewController:anCtl];
	PKSettingsRootViewController* setCtl= [[PKSettingsRootViewController alloc] initWithStyle:UITableViewStyleGrouped];
	setCtl.title = settingsStr;
	UINavigationController* setNavi  = [[UINavigationController alloc] initWithRootViewController:setCtl];
	
	contactNavi.delegate = self;
	PersonNavi.delegate  = self;
	aniNavi.delegate     = self;
	setNavi.delegate     = self;
	[controllerArr addObject:contactNavi];
	[controllerArr addObject:PersonNavi];
	[controllerArr addObject:aniNavi];
	[controllerArr addObject:setNavi];
	
	tabBarController_ = [[PKTabBarViewController  alloc] init];
	tabBarController_.delegate = self;
	tabBarController_.viewControllers = controllerArr;
	[tabBarController_ setTabBarItemTitle:titlesArr];
	[tabBarController_ setTabBarItemNormalImage:imageNArr highlightImage:imageHArr];
	//tabBarController_.customizableViewControllers = controllerArr;
	//tabBarController_.tabBar.tintColor = kTabCtlColor;
	[self.window addSubview:tabBarController_.view];
	//tabBarController_.tabBar.tintColor = kToolBarColor;
	

	

	[ctCtl		release];
	[psCtl		release];
	[anCtl		release];
	[setCtl		release];
	[contactNavi	release];
	[PersonNavi		release];
	[aniNavi		release];
	[setNavi		release];
}

- (void)showTabBarController
{
	self.window.rootViewController = nil;
	[self initTabBarController];
	//[self addTabBarArrow];
}

- (void)tabBarControllerSeleted:(NSInteger)index
{
	[tabBarController_ setCustomSelectedIndex:index];
	
	UINavigationController* navi = (UINavigationController*)tabBarController_.selectedViewController ;
	if ([navi.topViewController respondsToSelector:@selector(gotoWeiboAuthViewController)])
	{
		[navi.topViewController performSelector:@selector(gotoWeiboAuthViewController)];
	}
	
	navi = (UINavigationController*)tabBarController_.selectedViewController ;
	UIViewController* viewController =  navi.topViewController;
	if (viewController&&[viewController isKindOfClass:[PKDialAnimationViewController class]]) 
	{
		PKDialAnimationViewController* dialViewController = (PKDialAnimationViewController*)viewController;
		[dialViewController setPushFlag:YES];
	}

	navi = (UINavigationController*)tabBarController_.selectedViewController ;
	viewController =  navi.topViewController;
	if (viewController&&[viewController isKindOfClass:[PKContactViewController class]]) 
	{
		PKContactViewController* contactViewController = (PKContactViewController*)viewController;
		[[contactViewController class] cancelPreviousPerformRequestsWithTarget:contactViewController selector:@selector(importAllFriendsToOpenListActiveByPush) object:nil];
		[contactViewController performSelector:@selector(importAllFriendsToOpenListActiveByPush) withObject:nil afterDelay:0.3];
	}
}

- (void)showRegisterOrLoginViewController
{
	isHaveRegisterAccount_ = [PKUtils isHaveRegisterAccount];
	if(isHaveRegisterAccount_==NO)
	{
		PKLogInOrRegisterViewController* loginOrRegViewCtl = [[PKLogInOrRegisterViewController alloc] init];		
		UINavigationController* naviCtl = [[UINavigationController alloc] initWithRootViewController:loginOrRegViewCtl];
		self.window.rootViewController = naviCtl ;
		[loginOrRegViewCtl	release];
		[naviCtl			release];
	}
}

#pragma mark - UIAlertView Delegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	if (buttonIndex==0)
	{
		[self solvePushNotification];
	}
}

#pragma mark - Push 
- (void)solvePushNotification
{
	//NSLog(@">>>solvePushNotification = %d",pushType_);
	if (pushType_==kPushTypeOne)
	{
		[PKUtils resetSynServerInfo];
		[self tabBarControllerSeleted:1];
		[self tabBarControllerSeleted:0];	
	}
	else if(pushType_==kPushTypeTwo)
	{
		[self updateDialAnimation];
	}
	else if(pushType_==kPushTypeThree)
	{
		[PKUtils checkShouldSynServerInfo];
		[self tabBarControllerSeleted:0];
	}
}
#pragma mark - Push Update Dial Animation
//更新浮面动画
- (void)updateDialAnimation
{
	[self tabBarControllerSeleted:2];	
	UINavigationController* navi = (UINavigationController*)tabBarController_.selectedViewController ;
	UIViewController* viewController =  navi.topViewController;
	if (viewController&&[viewController isKindOfClass:[PKDialAnimationViewController class]]) 
	{
		PKDialAnimationViewController* dialViewController = (PKDialAnimationViewController*)viewController;
		[dialViewController setPushFlag:YES];
	}
}

@end
