//
//  PKShowStrangerInfoTableViewCell.m
//  Pumpkin
//
//  Created by lv on 8/5/12.
//  Copyright (c) 2012 XXX. All rights reserved.
//

#import "PKShowStrangerInfoTableViewCell.h"

@implementation PKShowStrangerInfoTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString*)identifier backType:(PKCellBackStyle)backStyle;
{
    self = [super initWithStyle:style reuseIdentifier:identifier backType:backStyle];
    if (self) {
		textField_.enabled = NO;
	}

	return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
