//
//  PKLogInOrRegisterViewController.m
//  Pumpkin
//
//  Created by lv on 6/3/12.
//  Copyright (c) 2012 XXXXX. All rights reserved.
//

#import "PKLogInOrRegisterViewController.h"
#import "PKUtils.h"
#import "PKLogInViewController.h"
#import "PKRegisterViewController.h"
#import "PKUIConst.h"


@interface PKLogInOrRegisterViewController ()
- (void)logInButtonPressed:(id)sender;
- (void)registerButtonPressed:(id)sender;
@end

@implementation PKLogInOrRegisterViewController

- (id)init
{
    self = [super init];
    if (self) {
        // Custom initialization
		logImageView_ = [[UIImageView alloc] initWithFrame:CGRectZero];
		logImageView_.image = [PKUtils commonImageWithName:@"login_logo.png"];
		logImageView_.contentMode = UIViewContentModeCenter;
		logTextLabel_ = [[UILabel alloc] initWithFrame:CGRectZero];
		logTextLabel_.text = NSLocalizedString(@"kLogText", nil);
		logTextLabel_.textColor = [UIColor grayColor];
		logTextLabel_.font = [UIFont  fontWithName:@"Helvetica-Oblique"  size:18];
		logTextLabel_.textAlignment = UITextAlignmentCenter;
		logTextLabel_.backgroundColor = [UIColor clearColor];
		registerButton_ = [[UIButton buttonWithType:UIButtonTypeCustom] retain];
		logInButton_    = [[UIButton buttonWithType:UIButtonTypeCustom] retain];
		UIImage* regNormalImage = [PKUtils commonImageWithName:@"login_button_normal.png"];
		regNormalImage = [regNormalImage stretchableImageWithLeftCapWidth:10 topCapHeight:10];
		UIImage* regHighLigtImage = [PKUtils commonImageWithName:@"login_button_pressed.png"];
		regHighLigtImage = [regHighLigtImage stretchableImageWithLeftCapWidth:10 topCapHeight:10];
		UIImage* logInNormalImage = [PKUtils commonImageWithName:@"login_gray_normal.png"];
		logInNormalImage = [logInNormalImage stretchableImageWithLeftCapWidth:10 topCapHeight:10];
		UIImage* logInHighLigtImage = [PKUtils commonImageWithName:@"login_gray_pressed.png"];
		logInHighLigtImage = [logInHighLigtImage stretchableImageWithLeftCapWidth:10 topCapHeight:10];
		[registerButton_ setBackgroundImage:regNormalImage   forState:UIControlStateNormal];
		[registerButton_ setBackgroundImage:regHighLigtImage forState:UIControlStateHighlighted];
		[registerButton_ setTitle:NSLocalizedString(@"kNewUserRegister", nil) forState:UIControlStateNormal];
		[registerButton_ addTarget:self action:@selector(registerButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
		[logInButton_	 setBackgroundImage:logInNormalImage forState:UIControlStateNormal];
		[logInButton_	 setBackgroundImage:logInHighLigtImage forState:UIControlStateHighlighted];
		[logInButton_	 setTitle:NSLocalizedString(@"kUserLogin", nil) forState:UIControlStateNormal];
		[logInButton_	 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
		[logInButton_	addTarget:self action:@selector(logInButtonPressed:) forControlEvents:UIControlEventTouchUpInside];

    }
    return self; 
}

- (void)dealloc
{
	[logTextLabel_		release];
	[logImageView_		release];
	[registerButton_	release];
	[logInButton_		release];
	[super dealloc];
}


//- (void)loadView
//{
//    // If you create your views manually, you MUST override this method and use it to create your views.
//    // If you use Interface Builder to create your views, then you must NOT override this method.
//	UIView* view = [[UIView alloc] initWithFrame:[UIScreen mainScreen].bounds];
//	view.backgroundColor = [UIColor whiteColor];
//	self.view = view;
//	[view	release];
//}

- (void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	self.navigationController.navigationBarHidden = YES;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	self.title = NSLocalizedString(@"kInitViewTitle", nil); 
	self.view.frame = [UIScreen mainScreen].bounds;
	self.view.backgroundColor = kBackgroundColor;
	[self.view addSubview:logImageView_];
	[self.view addSubview:logTextLabel_];
	[self.view addSubview:registerButton_];
	[self.view addSubview:logInButton_];
	[logImageView_ setFrame:CGRectMake(0, 0, 320, 250)];
	[logTextLabel_ setFrame:CGRectMake(0, 250, 320, 40)];
	[registerButton_ setFrame:CGRectMake(30, 300, 260, 40)];
	[logInButton_	 setFrame:CGRectMake(30, 360, 260, 40)];

	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
	[logImageView_		removeFromSuperview];
	[logTextLabel_		removeFromSuperview];
	[registerButton_	removeFromSuperview];
	[logInButton_		removeFromSuperview];

}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
#pragma mark - UIButton Action Event

- (void)logInButtonPressed:(id)sender
{
	PKLogInViewController* logInViewController = [[PKLogInViewController alloc] initWithStyle:UITableViewStyleGrouped];
	[self.navigationController pushViewController:logInViewController animated:YES];
	[logInViewController release];
}

- (void)registerButtonPressed:(id)sender
{
	PKRegisterViewController* registerViewController = [[PKRegisterViewController alloc] initWithStyle:UITableViewStyleGrouped];
	[self.navigationController pushViewController:registerViewController animated:YES];
	[registerViewController release];
}

@end
