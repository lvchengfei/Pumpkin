//
//  PKTutorialView.h
//  Pumpkin
//
//  Created by lv on 6/16/12.
//  Copyright (c) 2012年 XXXXX. All rights reserved.
//

#import "PKAboutViewController.h"
#import <CommonCrypto/CommonDigest.h>

@implementation PKAboutViewController

- (id)initWithStyle:(UITableViewStyle)style
{
	self = [super initWithStyle:style];
	if (self)
	{
		
	}
	return self;
	
}

- (void)dealloc 
{
    [super dealloc];
}


- (void)viewDidLoad 
{
    [super viewDidLoad];
	self.title = @"关于";

}


#pragma mark Table view methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}


// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	return 5;
}



// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
	/*
	 关于脉客
	 脉客，你的人脉管理专家。脉客有效的帮您建立和维护现实生活中的人脉关系。
	 版本号：3.0.1
	 公司：浙江洲信信息技术有限公司
	 浙ICP备 09095240号  网络文化经营许可证  文网文[2010]015号  Copyright © 2012   
	 */
    UITableViewCell *cell = nil;
	NSUInteger row = [indexPath row];
	
	if (row == 0) {
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:nil] autorelease];
		cell.selectionStyle = UITableViewCellSelectionStyleNone;
		cell.textLabel.text = @"关于脉客";
		cell.textLabel.font = [UIFont boldSystemFontOfSize:18];
		cell.textLabel.textAlignment = UITextAlignmentCenter;
		cell.detailTextLabel.text = @"脉客，你的人脉管理专家。脉客有效的帮您建立和维护现实生活中的人脉关系。";
		cell.detailTextLabel.numberOfLines = 0;
		cell.detailTextLabel.textAlignment = UITextAlignmentLeft;
	}
	else if (row == 1) {
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:nil] autorelease];
		cell.textLabel.text = @"版本号";
		cell.textLabel.textAlignment = UITextAlignmentCenter;
		cell.textLabel.font = [UIFont boldSystemFontOfSize:18];
		cell.detailTextLabel.text = @"3.0.1";
		cell.detailTextLabel.textAlignment = UITextAlignmentCenter;
	}
	else if (row == 2) {
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:nil] autorelease];
		cell.textLabel.text = @"公司";
		cell.textLabel.textAlignment = UITextAlignmentCenter;
		cell.textLabel.font = [UIFont boldSystemFontOfSize:18];
		cell.detailTextLabel.text = @"浙江洲信信息技术有限公司";
		cell.detailTextLabel.textAlignment = UITextAlignmentCenter;
	}
	else if(row==3)
	{
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:nil] autorelease];
		cell.textLabel.text = @"浙ICP备";
		cell.textLabel.textAlignment = UITextAlignmentCenter;
		cell.textLabel.font = [UIFont boldSystemFontOfSize:18];
		cell.detailTextLabel.text = @"09095240号";
		cell.detailTextLabel.textAlignment = UITextAlignmentCenter;
	}
	else if(row==4)
	{
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:nil] autorelease];
		cell.textLabel.text = @"网络文化经营许可证 ";
		cell.textLabel.textAlignment = UITextAlignmentCenter;
		cell.textLabel.font = [UIFont boldSystemFontOfSize:18];
		cell.detailTextLabel.text = @"文网文[2010]015号";
		cell.detailTextLabel.textAlignment = UITextAlignmentCenter;
	}
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
	return;
}



- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
	if (indexPath.row==0)
	{
		return 80;
	}
	return 60.0f;
}


- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
	return 80.0f;
}



- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
	UIView *tmpView = [[[UIView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 320.0f, 80.0f)] autorelease];
	UIImage *tmpImage = [[UIImage alloc] initWithContentsOfFile:[[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"icon.png"]];
	UIImageView *tmpImageView = [[[UIImageView alloc] initWithImage:tmpImage] autorelease];
	[tmpImage release];
	[tmpImageView setFrame:CGRectMake(0, 0, 60, 60)];
	tmpImageView.center = CGPointMake(50.0f, 40.0f);
	UILabel *tmpLabel = [[[UILabel alloc] initWithFrame:CGRectMake(80.0f, 36.0f, 200.0f, 26.0f)] autorelease];
	tmpLabel.backgroundColor = [UIColor clearColor];
	tmpLabel.font = [UIFont boldSystemFontOfSize:18];
	tmpLabel.text = @" 脉客";
	[tmpView addSubview:tmpImageView];
	[tmpView addSubview:tmpLabel];
	return tmpView;
}

- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section
{
	return NSLocalizedString(@"Copyright©2012-2013", @"Copyright©2012-2013");
}

@end

