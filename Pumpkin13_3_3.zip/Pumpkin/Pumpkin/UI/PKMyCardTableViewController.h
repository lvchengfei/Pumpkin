//
//  PKMyCardTableViewController.h
//  Pumpkin
//
//  Created by lv on 2/27/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PKMyCard.h"
#import "PKSectionHeadView.h"
#import "PKMyCardAvatarTableViewCell.h"
#import "PKMyCardGenInfoTableViewCell.h"
#import "PKMyCardEngine.h"
#import "PKMyCardContactCellTableViewController.h"



@interface PKMyCardTableViewController : UITableViewController
	<PKSectionHeadViewDelegate,
	PKMyCardAvatarTableViewCellProtocol,
	PKAddContactCellsDelegate,
	PKMyCardEngineProtocol,
	UITextFieldDelegate,
	UIActionSheetDelegate,
	UINavigationControllerDelegate,
	UIImagePickerControllerDelegate> 
{
	PKMyCardEngine*				myCardEngine_;
	UIView*						clearHeadView_;
	NSMutableDictionary*		cellDict_;
	
}
@property(nonatomic,assign)id parentController;
@property(nonatomic,assign)PKMyCardEngine*  myCardEngine;
- (void)cancelMyCardEdit;
- (BOOL)saveMyCardEdit;
@end
