//
//  PKMyCardEditView.h
//  Pumpkin
//
//  Created by lv on 6/17/12.
//  Copyright (c) 2012 XXXXX. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PKMyCardTemplate.h"

@interface PKMyCardView : UIView
{
	UIImageView*			templateView_;
	UIImageView*			avatarView_;
	NSMutableArray*			titleLabelArray_;	//UILabel array
	NSMutableArray*			valueLabelArray_;	//UILabel array
	PKMyCardTemplate*		templateEngine_;
}

- (id)initWithTemplate:(PKMyCardTemplate*)templateEngine;
- (void)reloadData;
@end
