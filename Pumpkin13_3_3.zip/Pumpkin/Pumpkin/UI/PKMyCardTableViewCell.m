//
//  PKMyCardTableViewCell.m
//  Pumpkin
//
//  Created by lv on 3/17/12.
//  Copyright 2012 yunyi. All rights reserved.
//

#import "PKMyCardTableViewCell.h"
#import "PKUtils.h"

@interface PKMyCardTableViewCell ()
- (void)buttonPressed:(id)sender;
@end


@implementation PKMyCardTableViewCell
@synthesize delegate = delegate_;
@synthesize section = section_;
@synthesize row = row_;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self)
    {
        normalImage_   = [[PKUtils commonImageWithName:@"notchecked.png"] retain];
        selectedImage_ = [[PKUtils commonImageWithName:@"checked.png"]   retain];
        imageButton_   = [UIButton buttonWithType:UIButtonTypeCustom];
		[imageButton_ setImage:normalImage_ forState:UIControlStateNormal];
		[imageButton_ addTarget:self action:@selector(buttonPressed:) forControlEvents:UIControlEventTouchUpInside];
		imageButton_.hidden = YES;
		[self addSubview:imageButton_];
    }
    return self;
}

- (void)dealloc
{
    [imageButton_   release];
    [normalImage_   release];
	[selectedImage_ release];
    [super  dealloc];
}

- (void)setFrame:(CGRect)rect
{
	[super setFrame:rect];
	
	CGRect bounds = [self bounds];
	CGRect imageRect = CGRectMake(bounds.size.width-selectedImage_.size.width -20, (bounds.size.height + 1 - selectedImage_.size.height) / 2, selectedImage_.size.width, selectedImage_.size.height);
	[imageButton_   setFrame:imageRect];
	//NSLog(@">>>>rect=%@ ,imageRect=%@",NSStringFromCGRect(rect),NSStringFromCGRect(imageRect));
}

- (void)showImageButton:(BOOL)show
{
	imageButton_.hidden = !show;
}

- (void)setChecked:(BOOL)checked
{
	checked_ = checked;
	UIImage* image = checked ? selectedImage_ : normalImage_;
	[imageButton_ setImage:image forState:UIControlStateNormal];
}

- (BOOL)checked
{
    return checked_;
}

- (void)buttonPressed:(id)sender
{
	checked_ = !checked_;
	[self setChecked:checked_];
	if ([delegate_ respondsToSelector:@selector(tableViewCell:buttonStatusChanged:)]) {
		[delegate_ tableViewCell:self buttonStatusChanged:checked_];
	}
}

@end
