//
//  PKPersonTableViewCell.h
//  Pumpkin
//
//  Created by lv on 3/3/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface PKPersonTableViewCell : UITableViewCell {
    id		cellDelegate_;
}
@property(nonatomic,assign) id cellDelegate;
@end
