//
//  PKSettingsRecommendFriends.m
//  XXXIMSettings
//
//  Created by lvchengfei on 5/4/11.
//  Copyright 2011 XXX Inc. All rights reserved.
//



#import "PKSettingsRecommendFriends.h"
#import "PKUtils.h"
#import "PKDefine.h"


@interface PKSettingsRecommendFriends()
-(void)sendRecommendBySMS;
-(void)sendRecommendByEmail;
@end


@implementation PKSettingsRecommendFriends

#pragma mark Life Cycle
- (void)dealloc 
{
	[recommendArray_		release];
	[imageArray_			release];
    [super dealloc];
}


- (void)viewDidLoad 
{
    [super viewDidLoad];
	self.title = NSLocalizedString(@"kRecommendFriendsTitle", nil);//推荐给好友
	
	recommendArray_ = [[NSMutableArray alloc] initWithObjects:NSLocalizedString(@"kRecommendFriendsByEmail", nil),NSLocalizedString(@"kRecommendFriendsByMessage", nil), nil];
	imageArray_     = [[NSMutableArray alloc] initWithCapacity:0];
	UIImage* image = nil;
	image = [PKUtils settingImageWithName:@"email.png"];
	[imageArray_ addObject:image];
	image = [PKUtils settingImageWithName:@"message.png"];
	[imageArray_ addObject:image];
}





#pragma mark Table view methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView 
{
    return 1;
}

// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	return  [recommendArray_ count];
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath 
{
    
    static NSString *CellIdentifier = @"RecommendFriends_Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    }
 
	cell.textLabel.text  = objectAtIndex(recommendArray_, indexPath.row);
	cell.accessoryType   = UITableViewCellAccessoryDisclosureIndicator ;
	cell.imageView.image = objectAtIndex(imageArray_, indexPath.row);
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
	
    NSUInteger row = [indexPath row] ;
	switch (row)
	{
		case 0:
			[self sendRecommendByEmail] ;
			break;
		case 1:
			[self sendRecommendBySMS] ;
			break;
		case 2:
			break;
		default:
			break;
	}
}



#pragma mark - Private Method

-(void)showMessage:(NSString*) str
{
    UIAlertView *tmpAlertView = [[UIAlertView alloc] initWithTitle:str
                                                           message:nil 
                                                          delegate:nil
												 cancelButtonTitle:NSLocalizedString(@"kOK", nil) otherButtonTitles:nil];
    [tmpAlertView show];
    [tmpAlertView release];
}


#pragma mark -
#pragma mark SMS
//#if  __IPHONE_OS_VERSION_MIN_REQUIRED > __IPHONE_4_0
//#ifdef __IPHONE_OS4__
-(void)displaySMSComposerSheet
{
	MFMessageComposeViewController *picker = [[MFMessageComposeViewController alloc] init];
	picker.messageComposeDelegate = self;
	picker.body=NSLocalizedString(@"kRecommendFriendsText", nil);
	if ([self respondsToSelector:@selector(presentModalViewController:animated:)]) {
		[self presentModalViewController:picker animated:YES];
	}
	else if ([self respondsToSelector:@selector(presentViewController:animated:completion:)])
	{
		[self presentViewController:picker animated:YES completion:nil];
	}
	
    [[[[picker viewControllers] lastObject] navigationItem] setTitle:NSLocalizedString(@"kRecommendFriendsByMessage", nil)];
	[picker release];
}

-(void)sendRecommendBySMS
{
	//	The MFMessageComposeViewController class is only available in iPhone OS 4.0 or later.
	//	So, we must verify the existence of the above class and log an error message for devices
	//		running earlier versions of the iPhone OS. Set feedbackMsg if device doesn't support
	//		MFMessageComposeViewController API.
	Class messageClass = (NSClassFromString(@"MFMessageComposeViewController"));
    
	if (messageClass != nil) {
		// Check whether the current device is configured for sending SMS messages
		if ([messageClass canSendText ]) {
			[self displaySMSComposerSheet];
		}
		else {
			[self showMessage:@"设备没有短信功能"];
		}
	}
	else {
		[self showMessage:@"iOS版本过低,iOS4.0以上才支持程序内发送短信" ] ;
	}
}


- (void)messageComposeViewController:(MFMessageComposeViewController *)controller
				 didFinishWithResult:(MessageComposeResult)result {
    
    if (MessageComposeResultSent == result) 
    {
        [self showMessage:@"短信发送成功" ] ;
    }    
    else if(MessageComposeResultFailed == result)
    {
        [self showMessage:@"短信发送失败" ] ;
    }
	
	if ([self respondsToSelector:@selector(dismissModalViewControllerAnimated:)]) {
		[self dismissModalViewControllerAnimated:YES];
	}
	else if ([self respondsToSelector:@selector(dismissViewControllerAnimated:completion:)])
	{
		[self dismissViewControllerAnimated:YES completion:nil];
	}
}
//#endif


#pragma mark email 

//#if  __IPHONE_OS_VERSION_MIN_REQUIRED >= __IPHONE_3_1
- (void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error
{
    
    if (MFMailComposeResultSent == result) 
    {
        [self showMessage:@"邮件发送成功" ] ;
    }    
    else if(MFMailComposeResultFailed == result)
    {
        [self showMessage:@"邮件发送失败" ] ;
    }
	
	if ([self respondsToSelector:@selector(dismissModalViewControllerAnimated:)]) {
		[self dismissModalViewControllerAnimated:YES];
	}
	else if ([self respondsToSelector:@selector(dismissViewControllerAnimated:completion:)])
	{
		[self dismissViewControllerAnimated:YES completion:nil];
	}

}


-(void)displayEmailSheet
{
    MFMailComposeViewController *picker = [[MFMailComposeViewController alloc] init];
	picker.mailComposeDelegate = self;
	[picker setSubject:NSLocalizedString(@"kRecommendFriendsMessageTitle", nil)] ;
	
    NSMutableString* body = [[NSMutableString alloc] initWithString:NSLocalizedString(@"kRecommendFriendsText", nil)];
 	[picker setMessageBody:body isHTML:YES];
	[body release] ;
	if ([self respondsToSelector:@selector(presentModalViewController:animated:)]) {
		[self presentModalViewController:picker animated:YES];
	}
	else if ([self respondsToSelector:@selector(presentViewController:animated:completion:)])
	{
		[self presentViewController:picker animated:YES completion:nil];
	}
	[picker release];
	
}
// Launches the Mail application on the device.
-(void)launchMailAppOnDevice
{
	NSString *email = [NSString stringWithFormat:@"mailto:?subject=推荐使用脉客&body=%@",NSLocalizedString(@"kRecommendFriendsText", nil)];
    email = [email stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:email]];
}

-(void)sendRecommendByEmail
{
    Class mailClass = (NSClassFromString(@"MFMailComposeViewController"));
    if (mailClass != nil)
    {
        // We must always check whether the current device is configured for sending emails
        if ([mailClass canSendMail])
        {
            [self displayEmailSheet];
        }
        else
        {
            [self launchMailAppOnDevice] ;
            //[self showMessage:@"您没有开启邮件功能或者设备不支持发送邮件！" ] ;
        }
    }
    else
    {
        [self launchMailAppOnDevice] ;
        //[self showMessage:@"iOS版本过低,iOS4.0以上才支持程序内发送邮件" ] ;
    } 
	
}


@end

