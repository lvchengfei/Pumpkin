//
//  PKMyCardTableViewCellBase.m
//  Pumpkin
//
//  Created by lv on 6/19/12.
//  Copyright (c) 2012 XXX. All rights reserved.
//

#import "PKMyCardTableViewCellBase.h"
#import "PKUtils.h"
#import "PKUIConst.h"


@implementation PKMyCardTableViewCellBase

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString*)identifier backType:(PKCellBackStyle)backStyle
{
	self = [super initWithStyle:style reuseIdentifier:identifier];
	if (self)
	{
		backgroundView_ = [[UIImageView alloc] initWithFrame:CGRectZero];
		NSString* imageName = [NSString stringWithFormat:@"cell_back_type_%d.png",backStyle];
		UIImage* image = [PKUtils myCardImageWithName:imageName];
		//image = [image stretchableImageWithLeftCapWidth:(NSInteger)image.size.width/2 topCapHeight:(NSInteger)image.size.height/2];
		backgroundView_.image = image;
		backgroundView_.backgroundColor = [UIColor clearColor];
		[self insertSubview:backgroundView_ belowSubview:self.contentView];
		backStyle_ = backStyle;
	
	}
	return self;
}

- (void)dealloc
{
	[backgroundView_ release];
	[super dealloc];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)setFrame:(CGRect)frame
{
	[super setFrame:frame];
	CGFloat leftMargin = 4,topMargin = 1;
	leftMargin = backStyle_==kCellBackStyle3?8:4;
	CGRect rect = CGRectMake(leftMargin,topMargin, frame.size.width-2*leftMargin, frame.size.height-2*topMargin);
	[backgroundView_ setFrame:rect];
}

@end
