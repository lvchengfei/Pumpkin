//
//  PKMyCardGenInfoTableViewCell.h
//  Pumpkin
//
//  Created by lv on 6/26/12.
//  Copyright (c) 2012 XXX. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PKMyCardTableViewCellBase.h"



@interface PKMyCardGenInfoTableViewCell : PKMyCardTableViewCellBase 
{
	UILabel*											lable_;
	UITextField*										textField_;
	UIImageView*										sepLineView_;
}
@property(nonatomic,readonly) UILabel*		lable;
@property(nonatomic,readonly) UITextField*	textField;
@end
