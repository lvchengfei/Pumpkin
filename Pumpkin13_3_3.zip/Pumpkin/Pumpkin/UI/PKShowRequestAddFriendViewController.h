//
//  PKShowRequestAddFriendViewController.h
//  Pumpkin
//
//  Created by lv on 3/2/13.
//  Copyright (c) 2013 Baidu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PKMyCardTableViewCell.h"
#import "PKServerSyn.h"

@interface PKShowRequestAddFriendViewController : UITableViewController<PKMyCardTableViewCellDelegate,PKServerSynDelegate>
{
	PKServerSyn*	serverSyn_;
	NSArray*		showItemArray_;
	NSMutableArray*	seletedArray_;

}
@property(nonatomic,assign) PKServerSyn* serverSyn;
@end
