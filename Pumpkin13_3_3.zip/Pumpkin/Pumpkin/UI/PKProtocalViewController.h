//
//  PKProtocalViewController.h
//  Pumpkin
//
//  Created by lv on 2/28/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface PKProtocalViewController : UIViewController 
{
	UIWebView*		protocolWebView_;
	UIButton*		confirmButton_;
	UIButton*		cancelButton_;
}

@end
