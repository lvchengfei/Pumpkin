//
//  PKShowStrangerPersonInfoViewController.h
//  Pumpkin
//
//  Created by lv on 8/5/12.
//  Copyright (c) 2012 XXX. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PKShowStrangerPersonInfoViewController : UITableViewController
{
	NSDictionary* personInfoDict_;
	NSArray*	  allKeysArray_;
}
- (void)setShowPersonInfo:(NSDictionary*)person;
@end
