//
//  PKMyCardAvatarTableViewCell.m
//  Pumpkin
//
//  Created by lv on 6/19/12.
//  Copyright (c) 2012 XXX. All rights reserved.
//

#import "PKMyCardAvatarTableViewCell.h"
#import "PKUIConst.h"
#import "PKUtils.h"
#import "PKPathUtil.h"

@interface PKMyCardAvatarTableViewCell ()


@end
#define labelSize				CGSizeMake(35.0, 30.0)
#define textFieldSize			CGSizeMake(130.0, 30.0)
#define editPenSize				CGSizeMake(30.0, 30.0)

@implementation PKMyCardAvatarTableViewCell
@synthesize delegate = delegate_;
@synthesize lable1 = lable1_;
@synthesize lable2 = lable2_;
@synthesize textField1 = textField1_;
@synthesize textField2 = textField2_;
@synthesize headImageView = headImageView_;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString*)identifier backType:(PKCellBackStyle)backStyle;
{
    self = [super initWithStyle:style reuseIdentifier:identifier backType:backStyle];
    if (self) {
		
//		headBackView_  = [[UIImageView alloc] initWithFrame:CGRectZero];
//		//headBackView_.image = [PKUtils myCardImageWithName:@"avatarBg.png"];
//		headBackView_.backgroundColor = kBackgroundColor;
//		[self addSubview:headBackView_];
		
		headImageView_ = [[UIImageView alloc] initWithFrame:CGRectZero];
		headImageView_.image = [PKUtils loadAvatarImage];
		[self addSubview:headImageView_];

		lable1_ = [[UILabel alloc] initWithFrame:CGRectZero];
		lable2_ = [[UILabel alloc] initWithFrame:CGRectZero];
//		lable1_.text = NSLocalizedString(@"kName", nil);
//		lable2_.text = NSLocalizedString(@"kCellPhone", nil);
		lable1_.backgroundColor = [UIColor clearColor];
		lable2_.backgroundColor = [UIColor clearColor];
		lable1_.textColor = [UIColor grayColor];
		lable2_.textColor = [UIColor grayColor];
		lable1_.font  = [UIFont systemFontOfSize:14];
		lable2_.font  = [UIFont systemFontOfSize:14];

		textField1_ = [[UITextField alloc] initWithFrame:CGRectZero];
		textField2_ = [[UITextField alloc] initWithFrame:CGRectZero];
		textField1_.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
		textField2_.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
		textField1_.font = [UIFont systemFontOfSize:16];
		textField2_.font = [UIFont systemFontOfSize:14];
		//textField1_.backgroundColor = [UIColor blueColor];
		//textField2_.backgroundColor = [UIColor redColor];
		[self addSubview:lable1_];
		[self addSubview:lable2_];
		[self addSubview:textField1_];
		[self addSubview:textField2_];
		
		/*
		editPenView1_ = [[UIImageView alloc] initWithFrame:CGRectZero];
		editPenView2_ = [[UIImageView alloc] initWithFrame:CGRectZero];
		editPenView1_.image = [PKUtils myCardImageWithName:@"editPen.png"];
		editPenView2_.image = [PKUtils myCardImageWithName:@"editPen.png"];
		editPenView1_.backgroundColor = [UIColor grayColor];
		editPenView2_.backgroundColor = [UIColor grayColor];
		[self addSubview:editPenView1_];
		[self addSubview:editPenView2_];
		 */


		
    }
    return self;
}

- (void)dealloc
{
	[lable1_			release];
	[lable2_			release];
	[textField1_		release];
	[textField2_		release];
	[headBackView_		release];
	[headImageView_		release];
	[editPenView1_		release];
	[editPenView2_		release];
	[super dealloc];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)setFrame:(CGRect)frame
{
	[super setFrame:frame];
	NSInteger offset = (kavaterCellHeight-kHeadImageHeight)/2;
	CGRect rect  = CGRectMake(frame.origin.x+20, offset, kHeadImageHeight, kHeadImageHeight);
	CGRect rect1  = CGRectMake(frame.origin.x+40+kHeadImageHeight,20,labelSize.width, labelSize.height);
	CGRect rect2  = CGRectMake(frame.origin.x+40+kHeadImageHeight,28+labelSize.height, labelSize.width, labelSize.height);

	CGRect rect3  = CGRectMake(rect1.origin.x+rect1.size.width, rect1.origin.y, textFieldSize.width, textFieldSize.height);
	CGRect rect4  = CGRectMake(rect2.origin.x+rect2.size.width,rect2.origin.y, textFieldSize.width, textFieldSize.height);
	CGRect rect5  = CGRectMake(rect3.origin.x+rect3.size.width,rect3.origin.y, editPenSize.width, editPenSize.height);
	CGRect rect6  = CGRectMake(rect4.origin.x+rect4.size.width,rect4.origin.y, editPenSize.width, editPenSize.height);

	[headImageView_ setFrame:rect];
	[lable1_		setFrame:rect1];
	[lable2_		setFrame:rect2];
	[textField1_	setFrame:rect3];
	[textField2_	setFrame:rect4];
	[editPenView1_	setFrame:rect5];
	[editPenView2_	setFrame:rect6];
	//CGRect rect7 =  CGRectMake(rect.origin.x-kHeadBackOffset, rect.origin.y-kHeadBackOffset, kHeadImageHeight+2*kHeadBackOffset, kHeadImageHeight+2*kHeadBackOffset);
	//[headBackView_	setFrame:rect1];
//	CGRect rect7 = CGRectOffset(backgroundView_.frame, kHeadBackOffset, kHeadBackOffset);
//	rect7.size.width -=2*kHeadBackOffset;
//	rect7.size.height -=2*kHeadBackOffset;
//	[headBackView_	setFrame:rect7];
	
	
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
	CGPoint point = [[touches anyObject] locationInView:self];
	if (CGRectContainsPoint(headImageView_.frame, point)) 
	{
		[delegate_ headImagePressed];
	}
	
}

#pragma mark - Private Method



@end
