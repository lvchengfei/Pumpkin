//
//  PKRemovePopView.m
//  TestDrag
//
//  Created by lv on 2/26/12.
//  Copyright  All rights reserved.
//

#import "PKMovePopView.h"
#import <QuartzCore/QuartzCore.h>
#import "PKUIConst.h"
#import "PKUtils.h"

static CGFloat kMovePopViewSepMargin = 10;
static CGFloat kMovePopViewHight = 70;

@interface PKMovePopView ()
-(void)layout;
@end

@implementation PKMovePopView

- (void)dealloc
{
	[imageView_			release];
	[label_				release];
    [super dealloc];
}

#pragma mark - Public Method

- (id)init
{
	self = [super initWithFrame:CGRectZero];
    if (self) {
        // Initialization code		
		/*
		imageView_ = [[UIImageView alloc] initWithImage:[PKUtils contactImageWithName:@"person.png"]];
		imageView_.contentMode = UIViewContentModeCenter;
		imageView_.backgroundColor = [UIColor clearColor];
		*/
		label_ = [[UILabel alloc] initWithFrame:CGRectZero];
		label_.backgroundColor = [UIColor clearColor];
		self.backgroundColor   = [UIColor clearColor];
		//self.alpha = 0.75;
		[self addSubview:label_];
		[self addSubview:imageView_];
		self.layer.cornerRadius = 9.0;
		self.layer.masksToBounds = YES;
    }
    return self;
}

- (void)showWithTitle:(NSString*)title
{
	if ([title length]>0)
	{
		[[UIApplication sharedApplication].keyWindow addSubview:self];
		label_.text = title;
		[self layout];
		self.hidden = YES;
		[UIView animateWithDuration:0.2 animations:^{self.hidden = NO;}];
	}

}

- (void)dismiss
{
	self.hidden = NO;
	[UIView animateWithDuration:0.2 animations:^{self.hidden = YES;} completion:^(BOOL finished){[self removeFromSuperview];}];
	//[self removeFromSuperview];
}

- (void)updatePosition:(CGPoint)pt
{
	CGSize  sz = self.frame.size;
	CGRect	rt = CGRectMake(pt.x-sz.width/2, pt.y-sz.height-kMovePopViewSepMargin, sz.width, sz.height);
	[self setFrame:rt];
}

- (void)updateImage:(UIImage*)image
{
	if (image)
	{
		imageView_.image = image;
	}
}


#pragma mark - Private Method

-(void)layout
{

	CGSize imageSz = imageView_.image.size;
	CGSize textSz  = [label_ sizeThatFits:CGSizeZero];
	CGFloat width  = imageSz.width+textSz.width + kMovePopViewSepMargin*3;
	CGFloat height = kMovePopViewHight;
	
 	CGRect rect = CGRectMake(self.frame.origin.x, self.frame.origin.y, width, height);
	[self setFrame:rect];
	
	if (imageView_.image) 
	{
		CGRect imgRt = CGRectMake(kMovePopViewSepMargin, (height-imageSz.height)/2, imageSz.width, imageSz.height);
		[imageView_ setFrame:imgRt];
	}
	else
		[imageView_ setFrame:CGRectZero];
	
	if ([label_.text length]>0) 
	{
		CGRect labRt = CGRectMake(imageSz.width+2*kMovePopViewSepMargin,  (height-textSz.height)/2, textSz.width,textSz.height);
		[label_ setFrame:labRt];
	}
	else
		[label_ setFrame:CGRectZero];
}



@end
