//
//  PKPersonTableViewCell.m
//  Pumpkin
//
//  Created by lv on 3/3/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import "PKPersonTableViewCell.h"
#import "PKPersonsViewController.h"


@implementation PKPersonTableViewCell
@synthesize cellDelegate = cellDelegate_;

- (void)dealloc
{
	cellDelegate_ = nil;
    [super dealloc];
}



#pragma mark - View lifecycle

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	PKPersonsViewController* pktv = (PKPersonsViewController*)cellDelegate_;
	[pktv.ctlDelegate PKtouchesBegan:touches withEvent:event];
	[[self nextResponder] touchesBegan:touches withEvent:event];
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
	PKPersonsViewController* pktv = (PKPersonsViewController*)cellDelegate_;
	[pktv.ctlDelegate PKtouchesMoved:touches withEvent:event]; 
	[[self nextResponder] touchesMoved:touches withEvent:event];
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
	PKPersonsViewController* pktv = (PKPersonsViewController*)cellDelegate_;
	[pktv.ctlDelegate PKtouchesEnded:touches withEvent:event];
	[[self nextResponder] touchesEnded:touches withEvent:event];
}

- (void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event
{
	PKPersonsViewController* pktv = (PKPersonsViewController*)cellDelegate_;
	[pktv.ctlDelegate PKtouchesCancelled:touches withEvent:event];
	[[self nextResponder] touchesCancelled:touches withEvent:event];

}
@end
