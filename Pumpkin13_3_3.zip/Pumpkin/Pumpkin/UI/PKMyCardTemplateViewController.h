//
//  PKMyCardTemplateViewController.h
//  Pumpkin
//
//  Created by lv on 6/18/12.
//  Copyright (c) 2012 XXX. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PKMyCardEngine.h"
#import "PKMyCardView.h"
#import "PKMyCardTemplate.h"

@interface PKMyCardTemplateViewController : UITableViewController
{
	PKMyCardEngine*		myCardEngine_;
	PKMyCardView*		myCardView_;
	UIScrollView*		templateView_;
	UIView*				selectedView_;
	//UIPageControl*		pageControl_;
	UILabel*			templateTitleLabel_;
	UIImageView*		cellSeprateLineHeadView_;
	UIImageView*		cellSeprateLineFootView_;

}
@property(nonatomic,assign)PKMyCardEngine*  myCardEngine;

- (id)initWithMyCardEngine:(PKMyCardEngine*)myCardEngine;
- (BOOL)saveTemplateSelected;
- (void)cancelTemplateSelected;
- (void)reloadMyCardViewData;

@end
