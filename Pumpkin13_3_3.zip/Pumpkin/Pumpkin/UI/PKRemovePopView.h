//
//  PKRemovePopView.h
//  TestDrag
//
//  Created by lv on 2/26/12.
//  Copyright  All rights reserved.
//

#import <UIKit/UIKit.h>


@interface PKRemovePopView : UIView 
{
	UIImage*	normalImage_;
	UIImage*	highLightImage_;
	UIImage*    frontImage_;
	UIImageView* bgView_;
	NSInteger	state_;
}
- (void)show;
- (void)dismiss;
- (void)updateWithState:(NSInteger)state;
@end

