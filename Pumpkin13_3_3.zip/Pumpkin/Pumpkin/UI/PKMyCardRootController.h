//
//  PKMyCardRootController.h
//  Pumpkin
//
//  Created by lv on 6/3/12.
//  Copyright (c) 2012 XXXXX. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PKMyCardTableViewController.h"
#import "PKMyCardTemplateViewController.h"
#import "PKMyCardEngine.h"
#import "PKMyCardView.h"
#import "PKMyCardSignature.h"


@interface PKMyCardRootController : UITableViewController <PKMyCardEngineProtocol,PKMyCardTemplateUpdateProtocol>
{
	PKMyCardView*					myCardView_;
	UIButton*						signatureButton_;
	PKMyCardTableViewController*	myCardViewController_;
	PKMyCardTemplateViewController*	templateViewController_;
	PKMyCardEngine*					myCardEngine_;
	UIImageView*					cellSeprateLineHeadView_;
	UIImageView*					cellSeprateLineFootView_;
	PKMyCardSignature*				signatureEngine_;
}

- (void)cancelMyCardEditState;

@end
