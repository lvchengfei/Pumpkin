//
//  PKMovePopView.h
//  TestDrag
//
//  Created by lv on 2/26/12.
//  Copyright  All rights reserved.
//

#import <UIKit/UIKit.h>


@interface PKMovePopView : UIView 
{
	UIImageView* imageView_;
    UILabel*	 label_;
}
- (void)showWithTitle:(NSString*)title;
- (void)dismiss;
- (void)updatePosition:(CGPoint)pt;
- (void)updateImage:(UIImage*)image;
@end

