//
//  PKDialAnimationSetViewController.h
//  Pumpkin
//
//  Created by lv on 3/18/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PKDialSetAnimation.h"

@interface PKDialAnimationSetViewController : UITableViewController<UIAlertViewDelegate,PKDialSetAnimationProtocol> 
{
    PKDialSetAnimation*	 dialAnimationSet_;
	UIImageView*		 normalImage_;
	UIImageView*		 selectImage_;
	NSArray*			 toolButtonArr_;
}

- (id)initWithStyle:(UITableViewStyle)style animationSN:(NSString*)sn;
@end
