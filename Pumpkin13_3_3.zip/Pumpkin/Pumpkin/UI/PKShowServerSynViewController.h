//
//  PKShowServerSynViewController.h
//  Pumpkin
//
//  Created by lv on 8/5/12.
//  Copyright (c) 2012 XXX. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PKMyCardTableViewCell.h"
#import "PKServerSyn.h"

@interface PKShowServerSynViewController : UIViewController  <UITableViewDelegate,UITableViewDataSource,PKMyCardTableViewCellDelegate,PKServerSynDelegate>
{
	NSMutableArray* segmentArray_ ;
	NSArray*		requestFriendsArray_;
	NSArray*		updateFriendsArray_;
	NSArray*		updateAnimationArray_;
	NSArray*		showItemArray_;
	NSMutableArray*	seletedArray_;
	
	UIButton*		confirmButton_;
	UIButton*		cancelButton_;	
	UITableView*    tableView_;
	NSInteger		currentSeleted_;
	
	PKServerSyn*	serverSyn_;
	UISegmentedControl *segmentedControl_;
}
@property(nonatomic,assign) PKServerSyn* serverSyn;
@property(nonatomic,retain) NSArray* requestFriendsArray;
@property(nonatomic,retain) NSArray* updateFriendsArray;
@property(nonatomic,retain) NSArray* updateAnimationArray;

@end
