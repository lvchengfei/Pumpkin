//
//  PKSettingsOpenAccountViewController.m
//  Pumpkin
//
//  Created by lv on 6/16/12.
//

#import "PKSettingsOpenAccountViewController.h"
#import "PKSettingsOpenAccountToFrinedsViewController.h"
#import "PKConst.h"
#import "PKToastView.h"
#import "PKDefine.h"

@interface PKSettingsOpenAccountViewController()
- (void)addOpenAccountToFriendsNotification:(NSNotification *)notification;
@end

@implementation PKSettingsOpenAccountViewController
@synthesize settings = settings_;

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) 
	{
		[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(addOpenAccountToFriendsNotification:) name:kAddOpenAccountToFriendsNotification object:nil];
	}
	return self;
}

- (void)viewDidLoad 
{
    [super viewDidLoad];
	self.title = NSLocalizedString(@"kAccountAuthManagerDetail", nil);			
	
}

- (void)dealloc 
{
	[[NSNotificationCenter defaultCenter] removeObserver:self];
	settings_ = nil;
    [super dealloc];
}


#pragma mark Table view methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView 
{
    return 1;
}


// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
    return PKOpenAccountCount;
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath 
{
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    }
    
	cell.textLabel.text = [settings_ contentOfOpenAccountType:indexPath.row] ;
	cell.accessoryType =  UITableViewCellAccessoryNone;
	
    return cell;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath 
{
		
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
	NSInteger tmpRow = [indexPath row];
	if (tmpRow==PKOpenAccountToFriends) 
	{
		PKSettingsOpenAccountToFrinedsViewController* openAccountViewController = [[PKSettingsOpenAccountToFrinedsViewController alloc] initWithStyle:UITableViewStylePlain];
		UINavigationController* naviViewController = [[UINavigationController alloc] initWithRootViewController:openAccountViewController];
		if ([self respondsToSelector:@selector(presentModalViewController:animated:)]) {
			[self presentModalViewController:naviViewController animated:YES];
		}
		else if ([self respondsToSelector:@selector(presentViewController:animated:completion:)])
		{
			[self presentViewController:naviViewController animated:YES completion:nil];
		}
		[openAccountViewController		release];
		[naviViewController				release];
	}
	else 
	{
		NSLog(@">>>TODO:do what?");
	}
	
}

#pragma mark - Notification

- (void)addOpenAccountToFriendsNotification:(NSNotification *)notification
{
	[PKToastView showWithTitle:@"正在上传中" animation:YES];
	NSString* phoneStr = notification.object;
	settings_.delegate = self;
	[settings_ setOpenList:phoneStr];
}

#pragma mark - PKSettingsDelegate

- (void)settings:(PKSettings *)settings accountOpen:(BOOL)isSuccess errorCode:(NSInteger)errCode
{

	[PKToastView dismissWithAnimation:YES];
	if (!isSuccess) 
	{
		NSString* title = (errCode==kNetWorkErr)?NSLocalizedString(@"kNetWorkError", nil):NSLocalizedString(@"kAccountOpenSetError", nil);
		PKALERTVIEW(nil, title, nil,@"确定",nil,nil);
	}
	else 
	{
		PKALERTVIEW(nil, @"设置成功！", nil,@"确定",nil,nil);	
	}
	[self.tableView reloadData];
}

@end
