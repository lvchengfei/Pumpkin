//
//  PKGroupsViewController.h
//  TestDrag
//
//  Created by lv on 2/26/12.
//  Copyright  All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PKContactEngine.h"
#import "PKGroupViewLogic.h"
#import "PKInfoPopView.h"


@class PKGroupsViewController;

@protocol PKGroupsViewControllerDelegate <NSObject>
@required
- (NSString*)currentSelectedPersonName;
- (void)groupTableView:(PKGroupsViewController*)groupTableView didSelectedAtSectionTag:(NSInteger)secTag;
@end

@interface PKGroupsViewController : UIViewController  <UITableViewDelegate,UITableViewDataSource>
{
	UITableView*					tableView_;
	UIImageView*					backgroundView_; 
	PKGroupViewLogic*				logicEngine_;
	id<PKGroupsViewControllerDelegate>   ctlDelegate_;
	PKInfoPopView*					addMemInfoPopView_;
	NSInteger						selRow_;
	NSInteger						lastSelRow_;
	NSString*						moveInGroupName_;

}
@property(nonatomic, readonly)id<PKGroupsViewControllerDelegate>  ctlDelegate;
@property(nonatomic, readonly)UITableView*				tableView;

- (id)initWithDelegate:(id <PKGroupsViewControllerDelegate>) ctlDelegate;

- (void)setTableViewFrame:(CGRect)frame;
- (void)updateWithPoint:(CGPoint)pt;
- (void)dismissAddMemberPopView;
- (PKContactGroup*)groupRecordAtIndexPath:(NSIndexPath*)indexPath;
- (void)reloadWithContactData;

@end
