//
//  PKSettingsOpenAccountViewController.h
//  Pumpkin
//
//  Created by lv on 6/16/12.
//

#import <UIKit/UIKit.h>
#import "PKSettings.h"

@interface PKSettingsOpenAccountViewController : UITableViewController <PKSettingsDelegate>
{
	PKSettings*			settings_;
}
@property(nonatomic,assign) PKSettings*	settings;


@end
