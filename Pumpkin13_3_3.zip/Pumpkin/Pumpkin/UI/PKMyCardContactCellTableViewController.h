//
//  PKMyCardContactCellTableViewController.h
//  Pumpkin
//
//  Created by lv on 6/30/12.
//  Copyright (c) 2012 XXX. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PKMyCardEngine.h"
@protocol PKAddContactCellsDelegate<NSObject>
@required
- (void)selectedContactCell:(PKMyCardSectionItem)cell;
@end

@interface PKMyCardContactCellTableViewController : UITableViewController
{
	PKMyCardEngine*					myCardEngine_;
	id<PKAddContactCellsDelegate>	delegate_;
}
@property(nonatomic,assign) PKMyCardEngine*		myCardEngine;
@property(nonatomic,assign)id<PKAddContactCellsDelegate> delegate;

@end
