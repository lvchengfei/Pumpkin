//
//  PKRemovePopView.m
//  TestDrag
//
//  Created by lv on 2/26/12.
//  Copyright  All rights reserved.
//

#import "PKRemovePopView.h"
#import <QuartzCore/QuartzCore.h>
#import "PKUIConst.h"
#import "PKUtils.h"

static CGFloat kRemovePopViewWidth = 90;
static CGFloat kRemovePopViewHight = 70;

@implementation PKRemovePopView

- (void)dealloc
{
	[normalImage_			release];
	[highLightImage_		release];
	[frontImage_			release];
	[bgView_				release];
    [super dealloc];
}

#pragma mark - Public Method

- (id)init
{
	self = [super initWithFrame:CGRectZero];
    if (self) {
        // Initialization code
		normalImage_    = [[[PKUtils contactImageWithName:@"drag_rem_bg.png"] stretchableImageWithLeftCapWidth:20 topCapHeight:20] retain];
		highLightImage_ = [[[PKUtils contactImageWithName:@"drag_rem_dropped_bg.png"] stretchableImageWithLeftCapWidth:20 topCapHeight:20] retain];
		frontImage_     = [[PKUtils contactImageWithName:@"drag_kickout.png"] retain];
		bgView_ = [[UIImageView alloc] initWithImage:frontImage_];
		bgView_.contentMode = UIViewContentModeCenter;
		bgView_.backgroundColor = [UIColor clearColor];
		self.backgroundColor    = [UIColor clearColor];
		[self addSubview:bgView_];
    }
    return self;
}

- (void)show;
{
	[[UIApplication sharedApplication].keyWindow addSubview:self];
	CGFloat width = 320;
	CGFloat orignY = kScreenHeight/2;
	CGRect  rect = CGRectMake(width-kRemovePopViewWidth, orignY-kRemovePopViewHight/2, kRemovePopViewWidth, kRemovePopViewHight);
	CGRect rect1 = CGRectMake(width, orignY-kRemovePopViewHight/2, kRemovePopViewWidth, kRemovePopViewHight);
	CGRect rect2 = CGRectMake(0, 0, kRemovePopViewWidth, kRemovePopViewHight-5);

	//NSLog(@"%@\n %@",NSStringFromCGRect(rect),NSStringFromCGRect(rect1));
	[self	 setFrame:rect1];
	[bgView_ setFrame:rect2];
	[UIView animateWithDuration:0.2 animations:^{self.frame = rect;}];
}

- (void)dismiss
{
	CGRect rect = self.frame;
	rect.origin.x = 320;
	[UIView animateWithDuration:0.2 animations:^{self.frame = rect;} completion:^(BOOL finished){[self removeFromSuperview];}];
	//[self removeFromSuperview];
}

- (void)updateWithState:(NSInteger)state
{
	state_ = state;
	[self setNeedsDisplay];
}

#pragma mark - Private Method

-(void)drawRect:(CGRect)rect
{
	//NSLog(@"%@",NSStringFromCGRect(rect));
	if (state_==0) 
	{
		[normalImage_ drawInRect:rect];
	}
	else 
	{
		[highLightImage_ drawInRect:rect];
	}
}



@end
