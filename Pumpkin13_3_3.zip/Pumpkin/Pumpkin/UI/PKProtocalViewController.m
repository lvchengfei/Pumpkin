//
//  PKProtocalViewController.m
//  Pumpkin
//
//  Created by lv on 2/28/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import "PKProtocalViewController.h"
#import "PKUtils.h"

@interface PKProtocalViewController()
- (void)confirmButtonPressed:(id)sender;
- (void)cancelButtonPressed:(id)sender;

@end

@implementation PKProtocalViewController


- (id)init
{
	self = [super init];
	if (self) {
		
		NSString* confirmStr = NSLocalizedString(@"kConfrim", nil);
		NSString* cancelStr  = NSLocalizedString(@"kCancel", nil);
		CGFloat height = 60 , buttonWitdth=130 , buttonHeight=40 , spacSep=30;
		CGFloat leftMargin=(320-buttonWitdth*2-spacSep)/2,topMargin=370;
		CGRect rt = [UIScreen mainScreen].bounds;
		CGRect textRect = CGRectMake(0,0,rt.size.width, rt.size.height-height-60);
		CGRect confirmRect = CGRectMake(leftMargin, topMargin, buttonWitdth, buttonHeight);
		CGRect cancelRect = confirmRect;
		cancelRect.origin.x = leftMargin+buttonWitdth+spacSep;
		
		protocolWebView_ =  [[UIWebView alloc] initWithFrame:textRect];
		protocolWebView_.backgroundColor = [UIColor clearColor];
		
		confirmButton_ = [[UIButton buttonWithType:UIButtonTypeCustom] retain];
		UIImage* norImg= [PKUtils commonImageWithName:@"login_button_normal.png"];
		norImg = [norImg stretchableImageWithLeftCapWidth:norImg.size.width/2 topCapHeight:norImg.size.height/2];
		[confirmButton_ setBackgroundImage:norImg   forState:UIControlStateNormal];
		[confirmButton_ setTitle:confirmStr forState:UIControlStateNormal];
		[confirmButton_ setFrame:confirmRect];
		[confirmButton_ addTarget:self action:@selector(confirmButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
		cancelButton_  = [[UIButton buttonWithType:UIButtonTypeCustom] retain];
		[cancelButton_	setBackgroundImage:norImg forState:UIControlStateNormal];
		[cancelButton_ setTitle:cancelStr forState:UIControlStateNormal];
		[cancelButton_ setFrame:cancelRect];
		[cancelButton_ addTarget:self action:@selector(cancelButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
		
	}
	return self;
}

- (void)dealloc
{
	[protocolWebView_	release];
	[confirmButton_		release];
	[cancelButton_		release];
    [super dealloc];
}

- (void)loadView {
	UIView *tmpView = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
	tmpView.autoresizingMask = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
	self.view = tmpView;
	[tmpView release];
	self.view.backgroundColor = [UIColor whiteColor];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle



// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];

	[self.view addSubview:protocolWebView_];
	[self.view addSubview:confirmButton_];
	[self.view addSubview:cancelButton_];

	NSString* agreePath = [[[NSBundle mainBundle]resourcePath] stringByAppendingPathComponent:@"agreement.htm"];
	NSString* tmpString = [NSString stringWithContentsOfFile:agreePath encoding:NSUnicodeStringEncoding error:nil];
	[protocolWebView_ loadHTMLString:tmpString baseURL:[NSURL fileURLWithPath:[[NSBundle mainBundle] resourcePath]]];
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Private Method
- (void)confirmButtonPressed:(id)sender
{
	[self.navigationController	 popViewControllerAnimated:YES];
}

- (void)cancelButtonPressed:(id)sender
{
	[self.navigationController popViewControllerAnimated:YES];
}


@end
