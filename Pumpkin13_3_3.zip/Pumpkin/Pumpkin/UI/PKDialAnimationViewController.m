//
//  PKDialAnimationViewController.m
//  Pumpkin
//
//  Created by lv on 2/28/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import "PKDialAnimationViewController.h"
#import "PKUIConst.h"
#import "PKUtils.h"
#import "PKDialAnimationDetailViewController.h"

@interface PKDialAnimationViewController()
- (void)reloadTableViewDataSource;
-(void)updateDialAnimationTroggleByPush;
@end

@implementation PKDialAnimationViewController
@synthesize reloading = reloading_;
@synthesize pushFlag = pushFlag_;

- (id)initWithStyle:(UITableViewStyle)style
{
	self = [super initWithStyle:style];
	if (self) 
	{		
		dialAnimationEngine_ = [[PKDialAnimation alloc] init];
		dialAnimationEngine_.delegate = self;
		
		refreshHeaderView_ = [[PKDialRefreshTableHeaderView alloc] initWithFrame:CGRectMake(0.0f, 0.0f - self.tableView.bounds.size.height, self.tableView.frame.size.width, self.tableView.bounds.size.height)];
        refreshHeaderView_.backgroundColor = [UIColor colorWithRed:249.0/255.0 green:249.0/255.0 blue:249.0/255.0 alpha:1.0];
		
		[self.tableView addSubview:refreshHeaderView_];
		self.tableView.showsVerticalScrollIndicator = YES;
		
	}
	return self;
}
- (void)dealloc
{
	[dialAnimationEngine_		release];
	[refreshHeaderView_			release];
	[bubblePrompt_				release];
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidAppear:(BOOL)animated
{
	[super viewDidAppear:animated];
	if (pushFlag_) 
	{
		[self updateDialAnimationTroggleByPush];
	}
	else 
	{
		if ([PKUtils shouldShowUpdateAnimationPrompt])
		{
			bubblePrompt_=[[PKDialBubblePrompt alloc]initWithFrame:CGRectMake(0, 0, self.tableView.frame.size.width, 30)];
			[bubblePrompt_ bubblePrompt:@"下拉可以更新模板"];
			[self.view insertSubview:bubblePrompt_ aboveSubview:self.tableView];
		}	
	}
	self.navigationController.navigationBar.tintColor = kNaviCtlColor;

}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
	self.navigationController.navigationBar.tintColor = kNaviCtlColor;
	
}


- (void)viewDidUnload
{
    [super viewDidUnload];
	[refreshHeaderView_ removeFromSuperview];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [dialAnimationEngine_ numberOfAnimationSections];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	return [dialAnimationEngine_ numberOfRowsInAnimationSection:section];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	UITableViewCell *cell = nil;	
	NSString* identifier = @"identifier";
	cell = [self.tableView dequeueReusableCellWithIdentifier:identifier];
	if (cell==nil) {
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:identifier] autorelease];
	}
	cell.imageView.image = [dialAnimationEngine_ smallImageOfAnimationSection:indexPath.section row:indexPath.row];
	cell.textLabel.text  = [dialAnimationEngine_ titleOfAnimationSection:indexPath.section row:indexPath.row];
	cell.detailTextLabel.text = [dialAnimationEngine_ detailTitleOfAnimationSection:indexPath.section row:indexPath.row];
	cell.accessoryType = UITableViewCellAccessoryDetailDisclosureButton;
	return cell;
}



#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	[[tableView cellForRowAtIndexPath:indexPath] setSelected:NO animated:YES];
	if (!reloading_)
	{
		NSString* imageName = [dialAnimationEngine_ imageNameOfAnimationSection:indexPath.section row:indexPath.row];
		PKDialAnimationDetailViewController* detailAnimationCtl = [[PKDialAnimationDetailViewController alloc] init];
		detailAnimationCtl.imageName = imageName;
		detailAnimationCtl.sn = [dialAnimationEngine_ snOfAnimationSection:indexPath.section row:indexPath.row];
		detailAnimationCtl.dialAnimation = dialAnimationEngine_;
		[self.navigationController pushViewController:detailAnimationCtl animated:YES];
		[detailAnimationCtl		release];
	}
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	return 60.0f;
}


#pragma mark - UIScrollView delegate

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{	
	
	if (scrollView.isDragging) 
	{
		if (refreshHeaderView_.state == PullRefreshPulling && scrollView.contentOffset.y > -55.0f && scrollView.contentOffset.y < 0.0f && !reloading_)
		{
			[refreshHeaderView_ setState:PullRefreshNormal];
		} else if (refreshHeaderView_.state == PullRefreshNormal && scrollView.contentOffset.y < -55.0f && !reloading_)
		{
			[refreshHeaderView_ setState:PullRefreshPulling];
		}
	}
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
	if (scrollView.contentOffset.y <= - 55.0f && !reloading_) 
	{
        reloading_ = YES;
        [self reloadTableViewDataSource];
        [refreshHeaderView_ setState:PullRefreshLoading];
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDuration:0.2];
        self.tableView.contentInset = UIEdgeInsetsMake(50.0f, 0.0f, 0.0f, 0.0f);
        [UIView commitAnimations];
	}
    
}



#pragma mark - PKDialAnimationDelegate

- (void)dialAnimation:(PKDialAnimation*)dialAnimation updateAnimation:(BOOL)isSuccess count:(NSInteger)count error:(NSError*)error
{
	[refreshHeaderView_ setState:PullRefreshLoading];
	
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration:0.3];
	[self.tableView setContentInset:UIEdgeInsetsMake(0.0f, 0.0f, 0.0f, 0.0f)];
	[UIView commitAnimations];
	
	[refreshHeaderView_ setState:PullRefreshNormal];
	[refreshHeaderView_ setCurrentDate]; 
	
	reloading_ = NO;
	
	if (isSuccess)
	{
		if (count>0) 
		{
			NSString* tmp = [NSString stringWithFormat:@"%@: %d",@"本次更新了模板个数",count];
			if (refreshHeaderView_.state==PullRefreshNormal) 
			{
				[self performSelector:@selector(bubble:) withObject:tmp afterDelay:0.3];
			}
			[self.tableView	reloadData];
		}
	}
	else 
	{
		NSInteger code = [error code];
		NSString* title = (code==kNetWorkErr)? NSLocalizedString(@"kNetWorkError", nil): NSLocalizedString(@"kUpdateAnimationError", nil);
		PKALERTVIEW(nil, title, nil,NSLocalizedString(@"kOK", nil) ,nil,nil);
	}
	
}

#pragma mark - Private Method

- (void)reloadTableViewDataSource
{
    [[self class] cancelPreviousPerformRequestsWithTarget:self selector:@selector(startLoadingTableViewData) object:nil];
    [self performSelector:@selector(startLoadingTableViewData) withObject:nil afterDelay:0.5];
}


- (void)startLoadingTableViewData
{
	[dialAnimationEngine_ updateAnimationNumbers];
}

- (void)bubble:(NSString*)message
{
    [bubblePrompt_ bubblePrompt:message];
    [self.view insertSubview:bubblePrompt_ aboveSubview:self.tableView];
}

-(void)updateDialAnimationTroggleByPush
{
	reloading_ = YES;
	[self reloadTableViewDataSource];
	[refreshHeaderView_ setState:PullRefreshLoading];
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationDuration:0.2];
	self.tableView.contentInset = UIEdgeInsetsMake(50.0f, 0.0f, 0.0f, 0.0f);
	[UIView commitAnimations];
}
@end
