//
//  PKMyCardGenInfoTableViewCell.m
//  Pumpkin
//
//  Created by lv on 6/26/12.
//  Copyright (c) 2012 XXX. All rights reserved.
//

#import "PKMyCardGenInfoTableViewCell.h"
#import "PKUtils.h"

@implementation PKMyCardGenInfoTableViewCell
@synthesize lable = lable_;
@synthesize textField = textField_;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString*)identifier backType:(PKCellBackStyle)backStyle;
{
    self = [super initWithStyle:style reuseIdentifier:identifier backType:backStyle];
    if (self) {
		lable_ = [[UILabel alloc] initWithFrame:CGRectZero];
		lable_.backgroundColor = [UIColor clearColor];
		lable_.textColor = [UIColor grayColor];
		lable_.font  = [UIFont systemFontOfSize:16];
	
		textField_ = [[UITextField alloc] initWithFrame:CGRectZero];
		textField_.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
		textField_.delegate = self;
		
		sepLineView_ = [[UIImageView alloc] initWithFrame:CGRectZero];
		sepLineView_.image = [PKUtils myCardImageWithName:@"line.png"];

		[self addSubview:lable_];
		[self addSubview:textField_];
		[self addSubview:sepLineView_];
    }
    return self;
}

- (void)dealloc
{
	[lable_			release];
	[textField_		release];
	[super dealloc];
}

- (void)setFrame:(CGRect)frame
{
	[super setFrame:frame];
	NSInteger leftMargin = 5 ,topMargin = 2;
	NSInteger labelWidth = 40 ;
	if ([lable_.text length]>0)
	{
		textField_.placeholder =[NSString stringWithFormat:@"点击编辑\"%@\"",lable_.text];
		NSInteger width = [lable_ sizeThatFits:CGSizeZero].width;
		labelWidth = labelWidth<width?width:labelWidth;
	}
	CGRect rect  = CGRectMake(frame.origin.x+12+leftMargin, topMargin, labelWidth, (frame.size.height-2*topMargin));
	CGRect rect1  = CGRectMake(rect.origin.x+rect.size.width+leftMargin,0,2,(frame.size.height-2*topMargin));
	CGRect rect2  = CGRectMake(rect1.origin.x+rect1.size.width+leftMargin,topMargin,frame.size.width-labelWidth-leftMargin*2,(frame.size.height-2*topMargin));
	[lable_			setFrame:rect];
	[sepLineView_	setFrame:rect1];
	[textField_		setFrame:rect2];
}

#pragma mark - UITextField Delegate

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    float sysVersion =  [[[UIDevice currentDevice] systemVersion] floatValue];
    if (sysVersion < 5.0)
	{
		UIView* sv = [self superview];
		if ([sv isKindOfClass:[UITableView class]]) 
		{
			UIEdgeInsets contentInsets = UIEdgeInsetsMake(0.0, 0.0, 216, 0.0);	//keybaord Height 216 Port
			((UITableView*)sv).contentInset = contentInsets;
			NSIndexPath* indexPath  = [(UITableView*)sv indexPathForCell:self];
			[(UITableView*)sv scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionTop animated:YES];
			//[(UITableView*)sv scrollRectToVisible:self.frame animated:YES];
		}
	}
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{	
	float sysVersion =  [[[UIDevice currentDevice] systemVersion] floatValue];
    if (sysVersion < 5.0)
	{
		UIView* sv = [self superview];
		if ([sv isKindOfClass:[UITableView class]]) 
		{
			((UITableView*)sv).contentInset = UIEdgeInsetsZero;
		}
	}
}

@end
