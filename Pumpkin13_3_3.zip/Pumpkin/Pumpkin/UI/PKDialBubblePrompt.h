//
//  PKDialBubblePrompt.h
//  Pumpkin
//
//  Created by lv on 2/28/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@interface PKDialBubblePrompt : UIView
{
    UILabel *proLabel_;
}
- (void)bubblePrompt:(NSString*)message;

@end
