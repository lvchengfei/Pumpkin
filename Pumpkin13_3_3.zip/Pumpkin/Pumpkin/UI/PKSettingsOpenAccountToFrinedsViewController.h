//
//  PKSettingsOpenAccountToFrinedsViewController.h
//  Pumpkin
//
//  Created by lv on 3/18/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PKSetOpenAccountToFriend.h"

@interface PKSettingsOpenAccountToFrinedsViewController : UITableViewController<UIAlertViewDelegate> 
{
    PKSetOpenAccountToFriend*	 openAccountToFriends_;
	UIImageView*				 normalImage_;
	UIImageView*				 selectImage_;
	NSArray*					 toolButtonArr_;
}

@end
