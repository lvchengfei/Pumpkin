//
//  PKSettingsRecommendFriends.h
//  XXXIMSettings
//
//  Created by lvchengfei on 5/4/11.
//  Copyright 2011 XXX Inc. All rights reserved.
//

#import <UIKit/UIKit.h>


#import <MessageUI/MessageUI.h>
#import <Availability.h>

@interface PKSettingsRecommendFriends : UITableViewController <MFMessageComposeViewControllerDelegate , MFMailComposeViewControllerDelegate>
{
	NSMutableArray*		recommendArray_;
	NSMutableArray*		imageArray_;
}
@end
