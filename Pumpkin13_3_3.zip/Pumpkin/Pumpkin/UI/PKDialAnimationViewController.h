//
//  PKDialAnimationViewController.h
//  Pumpkin
//
//  Created by lv on 2/28/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PKDialAnimation.h"
#import "PKDialRefreshTableHeaderView.h"
#import "PKDialBubblePrompt.h"

@interface PKDialAnimationViewController : UITableViewController <PKDialAnimationDelegate>
{
	PKDialAnimation*				dialAnimationEngine_;
	PKDialRefreshTableHeaderView *	refreshHeaderView_;
	BOOL							reloading_;
	PKDialBubblePrompt*				bubblePrompt_;
	BOOL							pushFlag_;
}
@property(nonatomic,assign) BOOL reloading;
@property(nonatomic,assign) BOOL pushFlag;

@end
