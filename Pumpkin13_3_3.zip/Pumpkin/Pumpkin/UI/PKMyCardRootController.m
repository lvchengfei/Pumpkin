//
//  PKMyCardRootController.m
//  Pumpkin
//
//  Created by lv on 6/3/12.
//  Copyright (c) 2012 XXXXX. All rights reserved.
//

#import "PKMyCardRootController.h"
#import "PKUtils.h"
#import "PKUIConst.h"
#import "PKMyCardSignatureEditController.h"
#import "PKLogicEngine.h"
#import "PKToastView.h"
#import "PumpkinAppDelegate.h"


#define kMyCardEditRect CGRectMake(0, 0,320,kScreenHeight-20 )

@interface PKMyCardRootController ()
- (void)editButtonPressed:(UIButton*)button;
- (void)backButtonPressed:(UIButton*)button;
- (void)segmentButtonPressed:(UISegmentedControl*)segmentControl;
- (void)signatureButtonPressed:(UIButton*)button;
@end

@implementation PKMyCardRootController

- (id)init
{
	self = [super init];
	if (self) {
		
		// Custom initialization
		myCardEngine_ = [[PKLogicEngine sharedInstance] getBusinessInstance:@"PKMyCardEngine"];
		myCardView_   = [[PKMyCardView alloc] initWithTemplate:myCardEngine_.myCardTemplate];
		
		signatureEngine_ = [[PKLogicEngine sharedInstance] getBusinessInstance:@"PKMyCardSignature"];
		
		signatureButton_ = [[UIButton buttonWithType:UIButtonTypeCustom] retain];
		[signatureButton_ setFrame:kSignatureBackRect];
		UIImage* image = [PKUtils myCardImageWithName:@"signature_back.png"];
		[signatureButton_	 setBackgroundImage:image forState:UIControlStateNormal];
		[signatureButton_	 setTitle:[signatureEngine_ signaturePlaceHolderOfMyCard] forState:UIControlStateNormal];
		[signatureButton_	 setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
		signatureButton_.titleLabel.font = [UIFont systemFontOfSize:20];
		signatureButton_.titleLabel.numberOfLines = 0 ;
		[signatureButton_ addTarget:self action:@selector(signatureButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
		
		
		myCardViewController_   = [[PKMyCardTableViewController alloc] init];
		templateViewController_ = [[PKMyCardTemplateViewController alloc] initWithMyCardEngine:myCardEngine_]; 
		myCardViewController_.myCardEngine   = myCardEngine_;
		myCardViewController_.parentController = self;
		
		
		cellSeprateLineHeadView_ = [[UIImageView alloc] initWithFrame:kTemplateCellSepLineRect];
		cellSeprateLineHeadView_.image = [PKUtils myCardImageWithName:@"cell_separate_line.png"];
		cellSeprateLineHeadView_.contentMode = UIViewContentModeCenter;
		
		cellSeprateLineFootView_ = [[UIImageView alloc] initWithFrame:kTemplateCellSepLineRect];
		cellSeprateLineFootView_.image = [PKUtils myCardImageWithName:@"cell_separate_line.png"];
		cellSeprateLineFootView_.contentMode = UIViewContentModeCenter;
	}
	return self;
}
- (void)dealloc
{
	[myCardEngine_				release];
	[myCardView_				release];
	[myCardViewController_		release];
	[templateViewController_	release];
	signatureEngine_ = nil;
	[super dealloc];
}


- (void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	[myCardEngine_		 reloadPersonInfoIfNeed];
	[signatureButton_	 setTitle:[signatureEngine_ signaturePlaceHolderOfMyCard] forState:UIControlStateNormal];
	
	if ([PKUtils checkAppIsBecomeActive])
	{
		[self backButtonPressed:nil];
		PumpkinAppDelegate* appDelegate = (PumpkinAppDelegate*)[[UIApplication sharedApplication] delegate];
		[appDelegate tabBarControllerSeleted:1];
	}
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	self.navigationController.navigationBar.tintColor = kNaviCtlColor;
	self.view.backgroundColor = kMyCardBackgroundColor;
	self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;

	UIBarButtonItem* rightButton = [[UIBarButtonItem alloc] initWithTitle:@"编辑" style:UIBarButtonItemStyleBordered target:self action:@selector(editButtonPressed:)];
	self.navigationItem.rightBarButtonItem = rightButton;
	[rightButton	release];
	
	[myCardView_		 reloadData];
	[myCardView_		 setFrame:kMyCardRect];
	
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	NSArray* identifierArr  = [NSArray arrayWithObjects:@"Cell1",@"Cell2", nil];
	NSString*CellIdentifier = [identifierArr objectAtIndex:indexPath.section];
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell==nil)
	{
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
		cell.selectionStyle = UITableViewCellSelectionStyleNone;
	}
	if (indexPath.section==0)
	{
		[cell addSubview:myCardView_];
	}
	else
	{
		[signatureButton_	 setTitle:[signatureEngine_ signaturePlaceHolderOfMyCard] forState:UIControlStateNormal];
		[cell addSubview:signatureButton_];
	}

	return cell;

}

#pragma mark - Table view delegate


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	if (indexPath.section==0) 
	{
		return kTemplateHeight+2*KTemplateOffset;
	}
	else if(indexPath.section==1)
	{
		return kSignatureTextHeight+kSignatureTextOrignY*2;
	}
	return 0;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
	return  cellSeprateLineHeadView_;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
	if (section==1)
	{
		return kTemplateCellSepLineRect.size.height;
	}
	return 0;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
	return cellSeprateLineFootView_;
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
	if (section==1)
	{
		return kTemplateCellSepLineRect.size.height;
	}
	return 0;
}

#pragma mark - Public Method

- (void)cancelMyCardEditState
{
	[self  backButtonPressed:nil];
}

#pragma mark - Private Medthod

- (void)editButtonPressed:(UIButton*)button
{
	NSString* btnTitle = self.navigationItem.rightBarButtonItem.title;
	if ([btnTitle isEqualToString:@"编辑"])
	{		
		self.tableView.scrollEnabled = NO;
		
		NSArray *segmentedArray = [[NSArray alloc]initWithObjects:@"个人资料",@"名片模板",nil];  
		UISegmentedControl *segmentedControl = [[UISegmentedControl alloc] initWithItems:segmentedArray];  
		segmentedControl.frame = CGRectMake(80, 0, 160.0, 30.0);
		segmentedControl.selectedSegmentIndex = 0;
		segmentedControl.segmentedControlStyle = UISegmentedControlStyleBar;
		[segmentedControl addTarget:self action:@selector(segmentButtonPressed:) forControlEvents:UIControlEventValueChanged];
		self.navigationItem.titleView = segmentedControl;
		[segmentedControl	release];
		[segmentedArray		release];
		CGRect bounds = [[UIScreen mainScreen] bounds];
		CGRect tabBarFrame = self.tabBarController.tabBar.frame;
		PumpkinAppDelegate* appDelegate = (PumpkinAppDelegate*)[[UIApplication sharedApplication] delegate];
		tabBarFrame = appDelegate.tabBarController.tabBar.frame;
		[appDelegate.tabBarController setFrame:CGRectMake(0,0,bounds.size.width,bounds.size.height+tabBarFrame.size.height)];
		[appDelegate.tabBarController setCustomTabBarHide:YES];
		//self.tabBarController.view.frame = CGRectMake(0,0,bounds.size.width,bounds.size.height+tabBarFrame.size.height);
		//self.tabBarController.tabBar.hidden = YES;
		
		[self.view	addSubview:myCardViewController_.view];

		CGRect navRect= self.navigationController.navigationBar.frame;
		CGFloat height = kScreenHeight-navRect.size.height-20;
		[myCardViewController_.view setFrame:CGRectMake(0, 0, 320, height)];
		//[myCardViewController_.view	setFrame:kMyCardEditRect];
		self.navigationItem.rightBarButtonItem.title = @"保存";
		UIBarButtonItem* leftButton = [[UIBarButtonItem alloc] initWithTitle:@"返回" style:UIBarButtonItemStyleBordered target:self action:@selector(backButtonPressed:)];
		self.navigationItem.leftBarButtonItem = leftButton;
		[leftButton	release];
		

		
	}
	else
	{
		if (myCardViewController_.view.superview) 
		{
			myCardViewController_.myCardEngine.delegate = self;
			if([myCardViewController_	saveMyCardEdit])
			{
				[PKToastView showWithTitle:@"正在上传名片" animation:YES];
			}
		}
		else if(templateViewController_.view.superview)
		{
			myCardEngine_.myCardTemplate.updateDelegate = self;
			if([templateViewController_ saveTemplateSelected])
			{
				[PKToastView showWithTitle:@"正在更新模板" animation:YES];
			}
		}
	}
}

- (void)backButtonPressed:(UIButton*)button
{
	
	self.tableView.scrollEnabled = YES;
	[myCardViewController_		cancelMyCardEdit];
	[templateViewController_    cancelTemplateSelected];
	[myCardView_				reloadData];
	[myCardView_				setFrame:kMyCardRect];
	self.navigationItem.titleView = nil;
	CGRect bounds = [[UIScreen mainScreen] bounds];
	//self.tabBarController.view.frame = CGRectMake(0,0,bounds.size.width,bounds.size.height);	
	//self.tabBarController.tabBar.hidden = NO;
	PumpkinAppDelegate* appDelegate = (PumpkinAppDelegate*)[[UIApplication sharedApplication] delegate];
	[appDelegate.tabBarController setFrame:CGRectMake(0,0,bounds.size.width,bounds.size.height)];
	[appDelegate.tabBarController setCustomTabBarHide:NO];
	[myCardViewController_.view		removeFromSuperview];
	[templateViewController_.view	removeFromSuperview];
	self.navigationItem.leftBarButtonItem = nil;
	self.navigationItem.rightBarButtonItem.title = @"编辑";
	[self.tableView reloadData];
}

- (void)segmentButtonPressed:(UISegmentedControl*)segmentControl
{

	if (segmentControl.selectedSegmentIndex==0)
	{
		[templateViewController_.view	removeFromSuperview];
		[self.view		addSubview:myCardViewController_.view];
	}
	else if(segmentControl.selectedSegmentIndex==1)
	{
		CGRect bounds = [[UIScreen mainScreen] bounds];
		CGRect tabBarFrame = self.tabBarController.tabBar.frame;
		//self.tabBarController.view.frame = CGRectMake(0,0,bounds.size.width,bounds.size.height+tabBarFrame.size.height);
		//self.tabBarController.tabBar.hidden = YES;
		PumpkinAppDelegate* appDelegate = (PumpkinAppDelegate*)[[UIApplication sharedApplication] delegate];
		[appDelegate.tabBarController setFrame:CGRectMake(0,0,bounds.size.width,bounds.size.height+tabBarFrame.size.height)];
		[appDelegate.tabBarController setCustomTabBarHide:YES];
		
		[myCardViewController_.view	removeFromSuperview];
		[self.view		addSubview:templateViewController_.view];	
		[templateViewController_.view	setFrame:kMyCardEditRect];
		[templateViewController_ reloadMyCardViewData];
	}
}

- (void)signatureButtonPressed:(UIButton*)button
{
	PKMyCardSignatureEditController* signatureEditCtl = [[PKMyCardSignatureEditController alloc] initWithStyle:UITableViewStylePlain];
	signatureEditCtl.myCardEngine = myCardEngine_;
	[self.navigationController pushViewController:signatureEditCtl animated:YES];
	[signatureEditCtl	release];
}

#pragma mark - PKMyCardEngineProtocol

- (void)myCardEngine:(PKMyCardEngine*)myCardEngine uploadMyCard:(BOOL)isSuccess errorCode:(NSInteger)errCode
{
	//sleep(1);
	[PKToastView dismissWithAnimation:YES];
	if (isSuccess)
	{
		[self backButtonPressed:nil];
	}
	else
	{
		NSString* errTitle = NSLocalizedString(@"kMyCardUploadSuc", nil);
		if (!isSuccess)
		{
			errTitle = (errCode==kNetWorkErr)? NSLocalizedString(@"kNetWorkError", nil):NSLocalizedString(@"kMyCardUploadError", nil);
		}
		UIAlertView *tmpAlertView = [[UIAlertView alloc] initWithTitle:errTitle
															   message:nil 
															  delegate:self 
													 cancelButtonTitle:NSLocalizedString(@"kOK", nil) 
													 otherButtonTitles:nil];
		[tmpAlertView show];
		[tmpAlertView release];
	}
}

#pragma mark - PKMyCardTemplateUpdateProtocol

- (void)cardTemplate:(PKMyCardTemplate*)cardTemplate updateTemplate:(BOOL)isSuccess errorCode:(NSInteger)errCode
{
	sleep(1);
	[PKToastView dismissWithAnimation:YES];
	if (isSuccess)
	{
		[myCardEngine_ saveTemplateName:myCardEngine_.myCardTemplate.selTemplateName];
		[myCardView_	reloadData];
		[self backButtonPressed:nil];
	}
	else 
	{
		
		NSString* errTitle = nil;
		if (errCode==kNetWorkErr) 
		{
			errTitle = NSLocalizedString(@"kNetWorkError", nil);
		}
		else 
		{
			errTitle = NSLocalizedString(@"kTemplateUploadError", nil);
		}	
		
		UIAlertView *tmpAlertView = [[UIAlertView alloc] initWithTitle:errTitle
															   message:nil 
															  delegate:self 
													 cancelButtonTitle:NSLocalizedString(@"kOK", nil) 
													 otherButtonTitles:nil];
		[tmpAlertView show];
		[tmpAlertView release];
	}
}



@end
