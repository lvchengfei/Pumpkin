//
//  PKLogInViewController.m
//  Pumpkin
//
//  Created by lv on 6/3/12.
//  Copyright (c) 2012 XXXXX. All rights reserved.
//

#import "PKLogInViewController.h"
#import <QuartzCore/QuartzCore.h>
#import "PKUIConst.h"
#import "PKUtils.h"
#import "PKRegisterViewController.h"
#import "PKLogicEngine.h"
#import "PKToastView.h"
#import "PKForgetPasswordViewController.h"


#define kSeprateSpace	10
#define kCellHiehgt		50
#define kFontSize		22
#define kCheckBoxWith	27
enum
{
	kAccountTextField,
	kPassWordTextField,
	kShowPassWord,
	kLogInButton,
	kForgetButton,
}PKLogInCell;

@interface PKLogInViewController ()
@property(nonatomic,retain)NSArray* cellArr;
@property(nonatomic,retain)UIAlertView* alertView;
- (void)layoutAllSubViews;
- (void)checkButtonPressed:(id)sender;
- (void)logInButtonPressed:(id)sender;
- (void)forgetButtonPressed:(id)sender;
- (void)registerAccount;

- (void)logIn;
@end

@implementation PKLogInViewController
@synthesize cellArr = cellArr_;
@synthesize alertView = alertView_;

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) 
	{
		backgroundView_ = [[UIImageView alloc] initWithFrame:CGRectZero];
		backgroundView_.layer.cornerRadius = 6.0;
		backgroundView_.layer.masksToBounds = YES;
		backgroundView_.backgroundColor = kBackgroundColor;
		accountTextField_	= [[UITextField alloc] initWithFrame:CGRectZero];
		passWordTextField_	= [[UITextField alloc] initWithFrame:CGRectZero];
		accountTextField_.placeholder   = NSLocalizedString(@"kAccountTextFieldPlaceHolder", nil);
		passWordTextField_.placeholder  = NSLocalizedString(@"kPasswordTextFieldPlaceHolder", nil);
		accountTextField_.contentVerticalAlignment   = UIControlContentVerticalAlignmentCenter;
		passWordTextField_.contentVerticalAlignment  = UIControlContentVerticalAlignmentCenter;
		accountTextField_.borderStyle   = UITextBorderStyleRoundedRect;
		passWordTextField_.borderStyle  = UITextBorderStyleRoundedRect;
		accountTextField_.font   = [UIFont systemFontOfSize:kFontSize];
		passWordTextField_.font  = [UIFont systemFontOfSize:kFontSize];
		accountTextField_.keyboardType = UIKeyboardTypeNumberPad;
		passWordTextField_.keyboardType = UIKeyboardTypeASCIICapable;
		passWordTextField_.secureTextEntry = YES;
		
		logInButton_  = [[UIButton buttonWithType:UIButtonTypeCustom] retain];
		checkButton_  = [[UIButton buttonWithType:UIButtonTypeCustom] retain];
		forgetButton_ = [[UIButton buttonWithType:UIButtonTypeCustom] retain];
		UIImage* norImage = [PKUtils commonImageWithName:@"login_button_normal.png"];
		norImage = [norImage stretchableImageWithLeftCapWidth:10 topCapHeight:10];
		UIImage* highLightImage = [PKUtils commonImageWithName:@"login_button_pressed.png"];
		highLightImage = [highLightImage stretchableImageWithLeftCapWidth:10 topCapHeight:10];
		normalImage_   = [[PKUtils commonImageWithName:@"ico_checkbox.png"] retain];
		selectedImage_ = [[PKUtils commonImageWithName:@"ico_choose.png"] retain];
		[logInButton_ setBackgroundImage:norImage   forState:UIControlStateNormal];
		[logInButton_ setBackgroundImage:highLightImage forState:UIControlStateHighlighted];
		[logInButton_  setTitle:NSLocalizedString(@"kOK", nil) forState:UIControlStateNormal];
		[forgetButton_ setTitle:NSLocalizedString(@"kForgetPassWord", nil) forState:UIControlStateNormal];
		[forgetButton_ setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];

		showPassWordLabel_ = [[UILabel alloc] initWithFrame:CGRectZero];
		showPassWordLabel_.text = NSLocalizedString(@"kshowPassWord", nil);
		showPassWordLabel_.font = [UIFont systemFontOfSize:16];
		showPassWordLabel_.textColor = [UIColor grayColor];
		showPassWordLabel_.backgroundColor = [UIColor clearColor];
		
		[checkButton_  addTarget:self action:@selector(checkButtonPressed:) forControlEvents:UIControlEventTouchUpInside];		
		[logInButton_  addTarget:self action:@selector(logInButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
		[forgetButton_ addTarget:self action:@selector(forgetButtonPressed:) forControlEvents:UIControlEventTouchUpInside];

		accountManager_ = [[PKLogicEngine sharedInstance] getBusinessInstance:@"PKAccountManager"];
		accountManager_.delegate = self;

	}
	return self;
}
- (void)dealloc
{
	accountManager_ = nil;
	accountManager_.delegate = nil;
	[backgroundView_	release];
	[accountTextField_	release];
	[passWordTextField_	release];
	[showPassWordLabel_	release];
	[checkButton_		release];
	[logInButton_		release];
	[forgetButton_		release];
	[normalImage_		release];
	[selectedImage_		release];
	[alertView_			release];
	[super dealloc];
}

- (void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	self.navigationController.navigationBarHidden = NO;
	self.navigationController.navigationBar.tintColor = kNaviCtlColor;
}


- (void)viewDidLoad
{
    [super viewDidLoad];
	self.title = NSLocalizedString(@"kUserLogin", nil);
	self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;//do not work when group style
	self.tableView.separatorColor = [UIColor clearColor];
	self.view.backgroundColor = [UIColor whiteColor];//kBackgroundColor;
	self.cellArr = [NSArray arrayWithObjects:
					[NSNumber numberWithInteger:kAccountTextField],
					[NSNumber numberWithInteger:kPassWordTextField],
					[NSNumber numberWithInteger:kShowPassWord],
					[NSNumber numberWithInteger:kLogInButton],
					[NSNumber numberWithInteger:kForgetButton],nil];
	UIView* view = [[UIView alloc] initWithFrame:CGRectZero];
	self.tableView.backgroundView = view;
	[view	release];
	[self.tableView.backgroundView addSubview:backgroundView_];
	[backgroundView_ setFrame:CGRectMake(kSeprateSpace,kSeprateSpace, 300, 260)];
	UIBarButtonItem* rightButton = [[UIBarButtonItem alloc] initWithTitle:@"注册账号" style:UIBarButtonItemStyleBordered target:self action:@selector(registerAccount)];
	self.navigationItem.rightBarButtonItem = rightButton;
	[rightButton	release];
	
	isShowPassWord_ = NO;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}



#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	return [cellArr_ count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	NSArray* tmpCellIdentifier = [NSArray arrayWithObjects:@"account",@"password",@"authorize",@"protocol",@"register", nil];
	UITableViewCell *cell = nil;	
	NSString* identifier = [tmpCellIdentifier objectAtIndex:indexPath.row];
	cell = [self.tableView dequeueReusableCellWithIdentifier:identifier];
	if (cell==nil) {
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier] autorelease];
	}
	switch (indexPath.row) 
	{
		case kAccountTextField:
			[cell.contentView   addSubview:accountTextField_];
			[accountTextField_	setFrame:CGRectMake(kSeprateSpace,kSeprateSpace/2,280, kCellHiehgt-kSeprateSpace)];
			break;
		case kPassWordTextField:
			[cell.contentView addSubview:passWordTextField_];
			[passWordTextField_	setFrame:CGRectMake(kSeprateSpace,kSeprateSpace/2,280, kCellHiehgt-kSeprateSpace)];
			passWordTextField_.secureTextEntry = !isShowPassWord_;
			break;
		case kShowPassWord:
			[cell.contentView addSubview:checkButton_];
			[cell.contentView addSubview:showPassWordLabel_];
			UIImage* image = isShowPassWord_?selectedImage_:normalImage_;
			[checkButton_			setBackgroundImage:image   forState:UIControlStateNormal];
			[checkButton_			setFrame:CGRectMake(kSeprateSpace,(kCellHiehgt-kCheckBoxWith)/2,kCheckBoxWith,kCheckBoxWith)];
			[showPassWordLabel_		setFrame:CGRectMake(kCheckBoxWith+kSeprateSpace,kSeprateSpace/2,100,kCellHiehgt-kSeprateSpace)];
			break;
		case kLogInButton:
			[cell.contentView addSubview:logInButton_];
			[logInButton_ setFrame:CGRectMake(kSeprateSpace,kSeprateSpace/2,280, kCellHiehgt-kSeprateSpace)];
			break;
		case kForgetButton:
			[cell.contentView addSubview:forgetButton_];
			[forgetButton_ setFrame:CGRectMake(kSeprateSpace+180,kSeprateSpace/2,100, kCellHiehgt-kSeprateSpace)];
			break;
			default:
			break;
	}
	cell.backgroundColor = [UIColor clearColor];
	cell.selectionStyle  = UITableViewCellSelectionStyleNone;
    return cell;
}

#pragma mark - Table view delegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	return kCellHiehgt;
}




#pragma mark UIButton Action Event 

- (void)checkButtonPressed:(id)sender
{
	isShowPassWord_ = !isShowPassWord_;
	UIImage* image = isShowPassWord_?selectedImage_:normalImage_;
	[checkButton_ setBackgroundImage:image   forState:UIControlStateNormal];	
	NSString* pass = passWordTextField_.text;
	passWordTextField_.enabled = NO;
	passWordTextField_.secureTextEntry = !isShowPassWord_;
	passWordTextField_.enabled = YES;
	[passWordTextField_ becomeFirstResponder];
	passWordTextField_.text = pass;
}

- (void)logInButtonPressed:(id)sender
{
	[self logIn];
}

- (void)forgetButtonPressed:(id)sender
{
	PKForgetPasswordViewController* viewController = [[PKForgetPasswordViewController alloc] init];
	[self.navigationController pushViewController:viewController animated:YES];
	[viewController release];
}

- (void)registerAccount
{
	[accountTextField_  resignFirstResponder];
	[passWordTextField_	resignFirstResponder];
	PKRegisterViewController* registerViewController = [[PKRegisterViewController alloc] initWithStyle:UITableViewStyleGrouped];
	[self.navigationController pushViewController:registerViewController animated:YES];
	[registerViewController release];
}


#pragma mark - Private Method

- (void)layoutAllSubViews
{
	[backgroundView_   setFrame:CGRectMake(kSeprateSpace, kSeprateSpace, 320-2*kSeprateSpace, 260)];
	[accountTextField_ setFrame:CGRectMake(2*kSeprateSpace, 2*kSeprateSpace, 320-4*kSeprateSpace, kCellHiehgt)];
	[passWordTextField_ setFrame:CGRectMake(2*kSeprateSpace, 2*kSeprateSpace+kCellHiehgt, 320-4*kSeprateSpace, kCellHiehgt)];
	[checkButton_		setFrame:CGRectMake(2*kSeprateSpace, 2*kSeprateSpace+2*kCellHiehgt, kCheckBoxWith, kCellHiehgt)];
	[showPassWordLabel_ setFrame:CGRectMake(2*kSeprateSpace+kCheckBoxWith, 2*kSeprateSpace+2*kCellHiehgt, 320-4*kSeprateSpace-kCheckBoxWith, kCellHiehgt)];
	[logInButton_      setFrame:CGRectMake(2*kSeprateSpace, 2*kSeprateSpace+3*kCellHiehgt, 320-4*kSeprateSpace, kCellHiehgt)];

}


- (void)logIn
{
	NSString* userNameStr = accountTextField_.text;
	NSString* passwordStr = passWordTextField_.text;
	[accountTextField_	resignFirstResponder];
	[passWordTextField_ resignFirstResponder];
	userNameStr = [userNameStr stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] ;
	
	if (userNameStr && [userNameStr length]>0 && passwordStr && [passwordStr length]>0) 
	{
		

		
		//[self addToKeyChain:userNameStr password:passwordStr];
		
//		UIAlertView *tmpAlertView = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"kLogIning", nil) 
//															   message:nil 
//															  delegate:self 
//													 cancelButtonTitle:NSLocalizedString(@"kCancel", nil) 
//													 otherButtonTitles:nil];
//		self.alertView = tmpAlertView;
//		[tmpAlertView show];
//		[tmpAlertView release];
		if ([PKUtils isNetWorkAvailable])
		{
			
			[PKToastView showWithTitle:NSLocalizedString(@"kLogIning", nil)  animation:YES];
			accountManager_.delegate = self;
			[accountManager_  logInWithAccount:userNameStr password:passwordStr];			
		}
	} 
	else if (userNameStr==nil || [userNameStr length]==0) 
	{
		PKALERTVIEW(nil, NSLocalizedString(@"kAccountCannotEmpty", nil), nil,NSLocalizedString(@"kOK", nil) ,nil,nil);
	} 
	else if (passwordStr==nil || [passwordStr length]==0) 
	{
		PKALERTVIEW(nil, NSLocalizedString(@"kPassWordCannotEmpty", nil), nil,NSLocalizedString(@"kOK", nil) ,nil,nil);
	}
	
}


#pragma mark - PKAccountManagerProtocol

- (void)accountManager:(PKAccountManager*)accountManager logInAccount:(BOOL)isSuccess errorCode:(PKAccountErrorCode)errCode
{
	[PKToastView dismissWithAnimation:YES];
	
	if (isSuccess) 
	{
		[[[UIApplication sharedApplication] delegate] performSelector:@selector(showTabBarController)];
	}
	else 
	{
		NSString* errTitle = nil;
		if (errCode==PKLogInErr) {
			errTitle = NSLocalizedString(@"kLogInAccountError", nil);
		}else if(errCode==PKNetworkErr){
			errTitle = NSLocalizedString(@"kNetWorkError", nil);
		}
		if (errTitle) 
		{
			UIAlertView *tmpAlertView = [[UIAlertView alloc] initWithTitle:errTitle
																   message:nil 
																  delegate:self 
														 cancelButtonTitle:NSLocalizedString(@"kOK", nil) 
														 otherButtonTitles:nil];
			[tmpAlertView show];
			[tmpAlertView release];
		}
	}
}

@end
