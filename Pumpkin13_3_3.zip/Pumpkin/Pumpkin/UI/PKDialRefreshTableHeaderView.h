//
//  PKDialRefreshTableHeaderView.h
//  Pumpkin
//
//  Created by lv on 2/28/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
typedef enum{
	PullRefreshPulling = 0,
	PullRefreshNormal,
	PullRefreshLoading,	
} PullRefreshState;

@interface PKDialRefreshTableHeaderView : UIView
{
    UILabel *lastUpdatedLabel_;
	UILabel *statusLabel_;
	CALayer *arrowImage_;
	UIActivityIndicatorView *activityView_;
	
	PullRefreshState state_;

}
@property(nonatomic,assign) PullRefreshState state;

- (void)setCurrentDate;
- (void)setState:(PullRefreshState)aState;

@end


