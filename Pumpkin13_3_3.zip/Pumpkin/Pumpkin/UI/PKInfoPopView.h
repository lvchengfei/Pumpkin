//
//  PKInfoPopView.h
//  Pumpkin
//
//  Created by lv on 3/11/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PKInfoPopView : UIView 
{
        UILabel*	 label_;
}
- (void)showWithTitle:(NSString*)title;
- (void)dismiss;

@end
