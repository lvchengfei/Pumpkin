//
//  PKRegisterViewController.h
//  Pumpkin
//
//  Created by lv on 6/3/12.
//  Copyright (c) 2012 XXXXX. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PKAccountManager.h"

@interface PKRegisterViewController : UITableViewController <PKAccountManagerProtocol,UIAlertViewDelegate>
{
	NSArray*		cellArr_;
	UIImageView*	backgroundView_;
	UITextField*	accountTextField_;
	UITextField*	passWordTextField_;
	UITextField*    authorizeTextField_;
	UIButton*		getAuthoCodeButton_;
	UIButton*		registerNowButton_;
	UIButton*		protocolCheckButton_;
	UIButton*		protocolTextButton_;
	UILabel*		protocolTextLabel_;
	UIImage*		normalImage_;
	UIImage*		selectedImage_;
	BOOL			isConfirmProtocol_;
	
	PKAccountManager*	accountManager_;
	UIAlertView*		alertView_;
}
@end
