//
//  PKDialAnimationSetViewController.m
//  Pumpkin
//
//  Created by lv on 3/18/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import "PKDialAnimationSetViewController.h"
#import "PKUIConst.h"
#import "PKLogicEngine.h"
#import "PKToastView.h"

@interface PKDialAnimationSetViewController ()

- (void)leftButtonPressed:(id)sender;
- (void)rightButtonPressed:(id)sender;

@end

@implementation PKDialAnimationSetViewController

- (id)initWithStyle:(UITableViewStyle)style animationSN:(NSString*)sn
{
    self = [super initWithStyle:style];
    if (self) 
	{
        // Custom initialization
		dialAnimationSet_ = [[PKLogicEngine sharedInstance] getBusinessInstance:@"PKDialSetAnimation"];
		[dialAnimationSet_  updateCandidateFriendsAinmation:sn];
		NSInteger	width = 90;
		UIBarButtonItem *selectAllButton = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"kSelectAll", nil) 
																			style:UIBarButtonItemStyleBordered target:self action:@selector(allSelected)];
		UIBarButtonItem *reverseButton = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"kConverse", nil) 
																		  style:UIBarButtonItemStyleBordered target:self action:@selector(reverseSelected)];
		UIBarButtonItem *cancelSelectButton = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"kCancelSelect", nil) 
																			   style:UIBarButtonItemStyleBordered target:self action:@selector(cancelSelected)];
		selectAllButton.width	 = width;
		reverseButton.width		 = width;
		cancelSelectButton.width = width;
		toolButtonArr_ = [[NSArray arrayWithObjects:selectAllButton, reverseButton, cancelSelectButton, nil] retain];
		[selectAllButton	release];
		[reverseButton		release];
		[cancelSelectButton release];
		
		normalImage_ = [[UIImageView alloc]initWithImage:[PKUtils commonImageWithName:@"notchecked.png"]];
		selectImage_ = [[UIImageView alloc]initWithImage: [PKUtils commonImageWithName:@"checked.png"]];
    }
    return self;
}

- (void)dealloc
{
	dialAnimationSet_ = nil;
	[normalImage_			release];
	[selectImage_			release];
	[toolButtonArr_			release];
	[super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	
	self.navigationController.navigationBar.tintColor = kNaviCtlColor;
	self.navigationController.toolbar.tintColor = kNaviCtlColor;

	// add toolbar at bottom page.
	self.navigationController.toolbar.barStyle = UIBarStyleDefault;
	[self.navigationController setToolbarHidden:NO animated:YES];
	[self setToolbarItems:toolButtonArr_ animated:YES];
	
	
	NSString* cancel = NSLocalizedString(@"kCancel", nil);
	NSString* confirm= NSLocalizedString(@"kOK", nil);
	UIBarButtonItem* leftButton = [[UIBarButtonItem alloc] initWithTitle:cancel style:UIBarButtonItemStyleBordered target:self action:@selector(leftButtonPressed:)];
	self.navigationItem.leftBarButtonItem = leftButton;
	[leftButton		release];
	UIBarButtonItem* rightButton = [[UIBarButtonItem alloc] initWithTitle:confirm style:UIBarButtonItemStyleBordered target:self action:@selector(rightButtonPressed:)];
	self.navigationItem.rightBarButtonItem = rightButton;
	[rightButton	release];
	
	if (![dialAnimationSet_ isHaveCandidatePersons]) 
	{
		UIAlertView* alertView = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"kHaveNonePersonsToAdd", nil) message:nil delegate:self cancelButtonTitle:confirm otherButtonTitles:nil];
		[alertView show];
		[alertView	release];
		
	}
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return [dialAnimationSet_ numberOfSection];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return [dialAnimationSet_ numberOfRowsInSection:section];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) 
	{
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
	}
	cell.textLabel.text = [dialAnimationSet_ contentAtIndexPath:indexPath];
	cell.accessoryType  = [dialAnimationSet_ isSelectedAtindexpath:indexPath]?UITableViewCellAccessoryCheckmark:UITableViewCellAccessoryNone;
    return cell;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return [dialAnimationSet_ titleForHeaderInSection:section];
}

- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView 
{
	return [dialAnimationSet_ sectionIndexTitlesArray];
}



#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{	
	UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
	[cell setSelected:NO animated:YES];
	BOOL isSelected = NO;
	if (cell.accessoryType == UITableViewCellAccessoryNone)
	{
		cell.accessoryType = UITableViewCellAccessoryCheckmark;
		isSelected = YES;
	}
	else
	{
		cell.accessoryType = UITableViewCellAccessoryNone;
	}
	
	[dialAnimationSet_ setSelectedPerson:isSelected indexpath:indexPath];
}


#pragma mark - Private Method
- (void)leftButtonPressed:(id)sender
{
	if ([self.parentViewController respondsToSelector:@selector(dismissModalViewControllerAnimated:)]) {
		[self.parentViewController dismissModalViewControllerAnimated:YES];
	}
	else if ([self.parentViewController respondsToSelector:@selector(dismissViewControllerAnimated:completion:)])
	{
		[self.parentViewController dismissViewControllerAnimated:YES completion:nil];
	}
}

- (void)rightButtonPressed:(id)sender
{

	dialAnimationSet_.delegate = self;
	if ([dialAnimationSet_ saveSelectedPerson])
	{
		[PKToastView showWithTitle:@"正在上传中" animation:YES];
	}
}

#pragma mark - Toolbar Target Action 


- (void)allSelected
{
	[dialAnimationSet_	allSelected];
	[self.tableView reloadData] ;
}

- (void)reverseSelected
{
	[dialAnimationSet_	reverseSelected];
	[self.tableView reloadData] ;
}

- (void)cancelSelected
{
	[dialAnimationSet_	cancelSelected];
	[self.tableView reloadData] ;
}


#pragma mark - AlertView Delegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	if ([self.parentViewController respondsToSelector:@selector(dismissModalViewControllerAnimated:)]) {
		[self.parentViewController dismissModalViewControllerAnimated:YES];
	}
	else if ([self.parentViewController respondsToSelector:@selector(dismissViewControllerAnimated:completion:)])
	{
		[self.parentViewController dismissViewControllerAnimated:YES completion:nil];
	}
}

#pragma mark - PKDialSetAnimationProtocol

- (void)animationSet:(PKDialSetAnimation *)animationSet uploadAnimationSet:(BOOL)isSuccess errorCode:(NSInteger)errCode
{
	[PKToastView dismissWithAnimation:YES];
	if (isSuccess)
	{
		if ([self.parentViewController respondsToSelector:@selector(dismissModalViewControllerAnimated:)]) {
			[self.parentViewController dismissModalViewControllerAnimated:YES];
		}
		else if ([self.parentViewController respondsToSelector:@selector(dismissViewControllerAnimated:completion:)])
		{
			[self.parentViewController dismissViewControllerAnimated:YES completion:nil];
		}
		PKALERTVIEW(nil, NSLocalizedString(@"kAnimationSetSuc", nil), nil,NSLocalizedString(@"kOK", nil),nil,nil);
	}
	else
	{
		NSString* title	= (errCode==kNetWorkErr)? NSLocalizedString(@"kNetWorkError", nil):NSLocalizedString(@"kAnimationSetError", nil);
		PKALERTVIEW(nil, title, nil,NSLocalizedString(@"kOK", nil),nil,nil);
	}
}
@end
