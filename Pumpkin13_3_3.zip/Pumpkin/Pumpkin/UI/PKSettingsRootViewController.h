//
//  PKSettingsRootViewController.h
//  Pumpkin
//
//  Created by lv on 2/28/12.
//  Copyright 2012 XXXXX. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PKSettings.h"
#import "PKAccountManager.h"


@interface PKSettingsRootViewController : UITableViewController <UIAlertViewDelegate,UITextFieldDelegate, UIActionSheetDelegate, PKSettingsDelegate,PKAccountManagerProtocol>
{
	PKSettings*			settings_;
	PKAccountManager*   accountManager_;
	UIAlertView*		alertView_;
	UITextField*		accountTextField_;
	UITextField*		passwordTextField_;
	UIButton*		    passwordCheckBox_;
	BOOL				isPasswordChecked_;
}

- (void)gotoWeiboAuthViewController;

@end
