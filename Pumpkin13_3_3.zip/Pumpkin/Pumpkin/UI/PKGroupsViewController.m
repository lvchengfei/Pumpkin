//
//  PKGroupsViewController.m
//  TestDrag
//
//  Created by lv on 2/26/12.
//  Copyright  All rights reserved.
//

#import "PKGroupsViewController.h"
#import "PKUIConst.h"
#import "PKCustomCellContent.h"
#import "PKUtils.h"

@interface PKGroupsViewController ()
@property(nonatomic,retain)NSString*moveInGroupName;

- (void)showAddMemberPopView;
- (BOOL)checkShouldShowPopView:(NSIndexPath*)indexPath;
- (void)updateIntersectCellColor:(NSIndexPath*)indexPath;
@end

@implementation PKGroupsViewController
@synthesize ctlDelegate = ctlDelegate_;
@synthesize tableView = tableView_;
@synthesize moveInGroupName = moveInGroupName_;

- (id)initWithDelegate:(id <PKGroupsViewControllerDelegate>) ctlDelegate
{
	self = [super init];
	if (self) 
	{
		logicEngine_ = [[PKGroupViewLogic    alloc] init];
		ctlDelegate_ = ctlDelegate;

		tableView_ = [[UITableView alloc] initWithFrame:CGRectZero];
		tableView_.backgroundColor = [UIColor clearColor];
		tableView_.separatorColor  = [UIColor lightGrayColor];
		//self.separatorStyle = UITableViewCellSeparatorStyleNone; 
		tableView_.dataSource = self;
		tableView_.delegate   = self;
		addMemInfoPopView_ = [[PKInfoPopView alloc] init];
		addMemInfoPopView_.backgroundColor = [UIColor blackColor];
		addMemInfoPopView_.alpha = 0.9;
		//UIImage* image = [[PKUtils contactImageWithName:@"group_bg.png"] stretchableImageWithLeftCapWidth:5 topCapHeight:5];
		//backgroundView_ = [[UIImageView alloc] initWithImage:image];
		//[self.view addSubview:backgroundView_];
		[self.view addSubview:tableView_];
		self.view.backgroundColor = kGroupColor;
	}
	return self;
}

-(void)dealloc
{
	[logicEngine_		release];
	[tableView_			release];
	[addMemInfoPopView_	release];
	[backgroundView_	release];
	[super dealloc];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [logicEngine_ numberOfSection];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	return [logicEngine_ numberOfRowsInSection:section];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier   = @"cell";
	UITableViewCell *cell = nil;
	cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
	if (cell == nil) {
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
		cell.backgroundColor = [UIColor clearColor];
	}	
	cell.textLabel.text  = @"";
	cell.imageView.image = nil;
	cell.textLabel.font  = [UIFont systemFontOfSize:12];
	float version = [[[UIDevice currentDevice] systemVersion] floatValue];
	if (version >= 6.0)
	{
		cell.textLabel.textAlignment = NSTextAlignmentCenter;
	}
	else
	{
		cell.textLabel.textAlignment = UITextAlignmentCenter;
	}
	cell.selectionStyle  = UITableViewCellSelectionStyleNone;
	
	NSInteger tag = [logicEngine_ tagAtIndexPath:indexPath];
	switch (tag) {
		case kPKGroupsStartSectionTag:
		{
			PKCustomCellContent* cellContent = (PKCustomCellContent*)[logicEngine_ contentAtIndexPath:indexPath];
			cell.textLabel.text  = [cellContent text];
		}
			break;
		case kPKGroupsEndSectionTag:
		{
			PKCustomCellContent* cellContent = (PKCustomCellContent*)[logicEngine_ contentAtIndexPath:indexPath];
			cell.imageView.image = [cellContent image]; 
		}
			break;
		case kPKGroupsContentSectionTag:
		{
			NSString* content = [logicEngine_ contentAtIndexPath:indexPath];
			cell.textLabel.text = content;	
		}	break;
		default:
			break;
	}
	
    return cell;
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
	NSInteger sel = [logicEngine_ selGroupIndex];
	NSInteger tag = [logicEngine_ tagAtIndexPath:indexPath];
	switch (tag) {
		case kPKGroupsStartSectionTag:
		{
			cell.backgroundColor = (sel==kContactGroupNone)?kGroupSeletedColor:[UIColor clearColor];
		}
			break;
		case kPKGroupsEndSectionTag:
			break;
		case kPKGroupsContentSectionTag:
		{
			cell.backgroundColor = (sel==indexPath.row)?kGroupSeletedColor:[UIColor clearColor];
		}	break;
		default:
			break;
	}
	
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Navigation logic may go here. Create and push another view controller.
	UITableViewCell* cell =[tableView cellForRowAtIndexPath:indexPath];
	[cell setSelected:NO animated:YES];
	NSInteger preSelGroup = [logicEngine_ selGroupIndex];
	NSIndexPath* preIndexPath = preSelGroup==-1?[NSIndexPath indexPathForRow:0 inSection:0]:[NSIndexPath indexPathForRow:preSelGroup inSection:1];
	[[tableView cellForRowAtIndexPath:preIndexPath] setBackgroundColor:[UIColor clearColor]];
	[logicEngine_ didSelectedAtIndex:indexPath];
	NSInteger tag = [logicEngine_ tagAtIndexPath:indexPath];
	if (tag==kPKGroupsContentSectionTag || tag==kPKGroupsStartSectionTag) 
	{
		NSInteger curSelGroup = [logicEngine_  selGroupIndex];
		if (curSelGroup==indexPath.row || curSelGroup==kContactGroupNone) 
		{
			cell.backgroundColor = kGroupSeletedColor;
		}
	}
	
	if (ctlDelegate_&&[ctlDelegate_ respondsToSelector:@selector(groupTableView:didSelectedAtSectionTag:)]) 
	{
		[ctlDelegate_ groupTableView:self didSelectedAtSectionTag:tag];
	}
     
}


#pragma mark - Public Method

- (void)setTableViewFrame:(CGRect)frame
{
	CGFloat offset =93;//tabBarHeight+navBarHeight ;
	CGRect rect = CGRectMake(0, 0, frame.size.width, frame.size.height-offset);
	//frame.size.height+=40;
	[self.view		 setFrame:frame];
	//[backgroundView_ setFrame:frame];
	[self.tableView	 setFrame:rect];
}

- (void)updateWithPoint:(CGPoint)pt
{
	NSIndexPath* indexPath = [tableView_ indexPathForRowAtPoint:pt];
	if(indexPath)
	{
		BOOL result = [self checkShouldShowPopView:indexPath];
		if (result)
		{
			[self showAddMemberPopView];
			[self updateIntersectCellColor:indexPath];
		}
		else
		{	
			[self dismissAddMemberPopView];
		}
	}
	else 
	{
		[self dismissAddMemberPopView];
	}
}



- (PKContactGroup*)groupRecordAtIndexPath:(NSIndexPath*)indexPath
{
	return [logicEngine_ groupRecordRefAtIndexPath:indexPath];
}

- (void)reloadWithContactData
{
	[logicEngine_ refreshGroups];
	[tableView_   reloadData];
}

#pragma mark - Private Method

- (BOOL)checkShouldShowPopView:(NSIndexPath*)indexPath
{
	if (indexPath) 
	{
		NSInteger tag = [logicEngine_ tagAtIndexPath:indexPath];
		NSInteger row = indexPath.row;
		NSInteger groupIndex =  logicEngine_.selGroupIndex;
		if (tag==kPKGroupsContentSectionTag&&row!=groupIndex) 
		{
			self.moveInGroupName = [logicEngine_ groupNameOfGroupIndex:row]; 
			return YES;
		}
	}
	//set init status when not in groupView or not in validate groupview cell
	selRow_=-1;
	return NO;
}

- (void)showAddMemberPopView
{
	NSString* personName = [ctlDelegate_ currentSelectedPersonName];
	NSString* title = [NSString stringWithFormat:NSLocalizedString(@"kMovePersonToGroup", nil),personName,self.moveInGroupName];
	[addMemInfoPopView_ showWithTitle:title];
	self.moveInGroupName = nil;
}

- (void)dismissAddMemberPopView
{
	[self updateIntersectCellColor:nil];
	[addMemInfoPopView_ dismiss];
}

- (void)updateIntersectCellColor:(NSIndexPath*)indexPath
{
	[tableView_ reloadData];
	if (indexPath) 
	{
		[[tableView_ cellForRowAtIndexPath:indexPath] setBackgroundColor:[UIColor whiteColor]];
	}
}


@end

