//
//  PKForgetPasswordViewController.m
//  Pumpkin
//
//  Created by lv on 11/10/12.
//  Copyright (c) 2012 Baidu. All rights reserved.
//

#import "PKForgetPasswordViewController.h"

@interface PKForgetPasswordViewController ()
- (void)showWebView;
- (void)backButtonPressed:(id)sender;
@end

@implementation PKForgetPasswordViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
		contentView_ = [[UIView alloc] initWithFrame:CGRectZero];
		//contentView_.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
		//contentView_.delegate = self;
    }
    return self;
}

- (void)dealloc
{
	[contentView_ release];
	[super dealloc];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	[self showWebView];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Private Method

- (void)showWebView
{
	if (!contentView_.superview)
	{
//		UIImage* headImage = [UIImage imageNamed:@"head"];
//		UIImage* cancelImgN = [UIImage imageNamed:@"bianji.png"];
//		UIImage* cancelImgH= [UIImage imageNamed:@"bianjidown.png"];
//		//添加一个头
//		UIButton *titleBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 320, 44)];
//		[titleBtn setBackgroundImage:headImage forState:UIControlStateHighlighted];
//		[titleBtn setBackgroundImage:headImage forState:UIControlStateNormal];
//		[contentView_ addSubview:titleBtn];
//		[titleBtn release];
//		
//		UIButton *backBtn = [[UIButton alloc] initWithFrame:CGRectMake(10,0 , 60, 45)];
//		[backBtn setTitle:@"返回" forState:UIControlStateNormal];
//		backBtn.titleLabel.font = [UIFont systemFontOfSize:14];
//		backBtn.titleLabel.adjustsFontSizeToFitWidth = TRUE;
//		[backBtn addTarget:self action:@selector(backButtonPressed:)  forControlEvents:UIControlEventTouchUpInside];
//		[backBtn setBackgroundImage:cancelImgN  forState:UIControlStateNormal];
//		[backBtn setBackgroundImage:cancelImgH  forState:UIControlStateHighlighted];
//		[contentView_ addSubview:backBtn];
//		[backBtn release];
//		
//
//		CGRect webRect = CGRectMake(0, 44, 320, [[UIScreen mainScreen] bounds].size.height-64);
		
		/*
		CGRect webRect = CGRectMake(0, 0, 320, self.view.frame.size.height);

		UIWebView *webView = [[UIWebView alloc] initWithFrame:webRect];
		webView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
		//webView.delegate = self;
		NSURLRequest* request = [NSURLRequest requestWithURL:[NSURL URLWithString:@"http://maike4i.97sng.com/wap/retrvpwd.html"]];
		[webView loadRequest:request];
		[contentView_ addSubview:webView];
		[webView release];
		[self.view addSubview: contentView_];
		*/
		
		CGRect webRect = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
		UIWebView *webView = [[UIWebView alloc] initWithFrame:webRect];
		webView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
		NSURLRequest* request = [NSURLRequest requestWithURL:[NSURL URLWithString:@"http://maike4i.97sng.com/wap/retrvpwd.html"]];
		[webView loadRequest:request];
		[self.view addSubview: webView];
		[webView release];

	}
}



- (void)backButtonPressed:(id)sender
{
	[self.navigationController popViewControllerAnimated:YES];
}

@end
