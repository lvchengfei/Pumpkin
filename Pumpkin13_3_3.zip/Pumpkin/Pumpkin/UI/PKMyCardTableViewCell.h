//
//  PKMyCardTableViewCell.h
//  Pumpkin
//
//  Created by lv on 3/17/12.
//  Copyright 2012 yunyi. All rights reserved.
//

#import <UIKit/UIKit.h>

@class PKMyCardTableViewCell;

@protocol PKMyCardTableViewCellDelegate <NSObject>
@optional
-(void)tableViewCell:(PKMyCardTableViewCell*)tableViewCell buttonStatusChanged:(BOOL)status;
@end

@interface PKMyCardTableViewCell : UITableViewCell {
	NSInteger   section_;
	NSInteger   row_;
    UIImage*	normalImage_;
	UIImage*	selectedImage_;
	UIButton*	imageButton_;
	id <PKMyCardTableViewCellDelegate> delegate_;
	BOOL        checked_;
	
}

@property (nonatomic, assign) NSInteger section;
@property (nonatomic, assign) NSInteger row;
@property (nonatomic, retain) id <PKMyCardTableViewCellDelegate> delegate;
@property (nonatomic, assign) BOOL      checked;

- (void)showImageButton:(BOOL)show;

@end
