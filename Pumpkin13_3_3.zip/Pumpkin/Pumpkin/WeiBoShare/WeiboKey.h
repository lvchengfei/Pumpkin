//
//  WBShareKey.h
//  WBShareKit
//
//  Created by Gao Semaus on 11-8-8.
//  Copyright 2011年 Chlova. All rights reserved.
//

#pragma mark - app account
//itunesConnect 帐号：ruinangua 密码：zhangruifeng

#pragma mark - Sina Weibo

//用户名ngcard@sina.com 密码ng86980299

#define SINAAPPKEY				@"3305870153"									
#define SINAAPPSECRET			@"b68fa910cfdddb471e3764c6c487a34b"					
			

#pragma mark - Tencent Weibo

#define ClientIpValue			@"CLIENTIP"
#define oauthAppKey				@"801150142"
#define oauthAppSecret			@"90b9247df07af8c7f746482f0ac6336c"
#define redirect_uri			@"http://www.fcards.net"

//#define oauthAppKey @"100261623"
//#define oauthAppSecret @"61bc6a5cd60a181f7daa1167982a98cb"
//APP ID：100261623


#pragma mark - KaiXin
#define KXAPPKEY		@"628113534504c7fce1f147a45be49fe5"	 //设置KAIXIN appkey
#define KXAPPSECRET		@"b6b3dd90ddd417dd5b4d6ac1dcc66cfd"	
#define KXRedirectURL	@"http://www.fcards.net"





