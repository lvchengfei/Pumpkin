//
//  WBAuthorize.m
//  SinaWeiBoSDK
//  Based on OAuth 2.0
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
//  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
//  OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
//  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
//  HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
//  WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
//  FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//  OTHER DEALINGS IN THE SOFTWARE.
//
//  Copyright 2011 Sina. All rights reserved.
//

#import "WBAuthorize.h"
#import "WBRequest.h"
#import "WBSDKGlobal.h"
#import "PKToastView.h"

#define kWBAuthorizeURL     @"https://api.weibo.com/oauth2/authorize"
#define kWBAccessTokenURL   @"https://api.weibo.com/oauth2/access_token"

@interface WBAuthorize (Private)

- (void)dismissModalViewController;
- (void)requestAccessTokenWithAuthorizeCode:(NSString *)code;
- (void)requestAccessTokenWithUserID:(NSString *)userID password:(NSString *)password;
- (void)showWebViewWith:(NSString*)urlString;
- (void)dismissWebView;
- (CGAffineTransform)transformForOrientation ;
@end

@implementation WBAuthorize

@synthesize appKey;
@synthesize appSecret;
@synthesize redirectURI;
@synthesize request;
@synthesize rootViewController;
@synthesize delegate;

#pragma mark - WBAuthorize Life Circle

- (id)initWithAppKey:(NSString *)theAppKey appSecret:(NSString *)theAppSecret
{
    if (self = [super init])
    {
        self.appKey = theAppKey;
        self.appSecret = theAppSecret;
		CGRect bounds = [[UIScreen mainScreen] applicationFrame];

		webView_ = [[UIView alloc] initWithFrame:bounds];

    }
    
    return self;
}

- (void)dealloc
{
	[webView_	release];
	webView_ = nil;
    [appKey release], appKey = nil;
    [appSecret release], appSecret = nil;
    
    [redirectURI release], redirectURI = nil;
    
    [request setDelegate:nil];
    [request disconnect];
    [request release], request = nil;
    
    rootViewController = nil;
    delegate = nil;
    
    [super dealloc];
}

#pragma mark - WBAuthorize Private Methods

- (void)dismissModalViewController
{
	if ([rootViewController respondsToSelector:@selector(dismissModalViewControllerAnimated:)]) {
		[rootViewController dismissModalViewControllerAnimated:YES];
	}
	else if ([rootViewController respondsToSelector:@selector(dismissViewControllerAnimated:completion:)])
	{
		[rootViewController dismissViewControllerAnimated:YES completion:nil];
	}
}

- (void)requestAccessTokenWithAuthorizeCode:(NSString *)code
{
    NSDictionary *params = [NSDictionary dictionaryWithObjectsAndKeys:appKey, @"client_id",
                                                                      appSecret, @"client_secret",
                                                                      @"authorization_code", @"grant_type",
                                                                      redirectURI, @"redirect_uri",
                                                                      code, @"code", nil];
    [request disconnect];
    
    self.request = [WBRequest requestWithURL:kWBAccessTokenURL
                                   httpMethod:@"POST"
                                       params:params
                                 postDataType:kWBRequestPostDataTypeNormal
                             httpHeaderFields:nil 
                                     delegate:self];
    
    [request connect];
}

- (void)requestAccessTokenWithUserID:(NSString *)userID password:(NSString *)password
{
    NSDictionary *params = [NSDictionary dictionaryWithObjectsAndKeys:appKey, @"client_id",
                                                                      appSecret, @"client_secret",
                                                                      @"password", @"grant_type",
                                                                      redirectURI, @"redirect_uri",
                                                                      userID, @"username",
                                                                      password, @"password", nil];
    
    [request disconnect];
    
    self.request = [WBRequest requestWithURL:kWBAccessTokenURL
                                   httpMethod:@"POST"
                                       params:params
                                 postDataType:kWBRequestPostDataTypeNormal
                             httpHeaderFields:nil 
                                     delegate:self];
    
    [request connect];
}

#pragma mark - WBAuthorize Public Methods

- (void)startAuthorize
{
    NSDictionary *params = [NSDictionary dictionaryWithObjectsAndKeys:appKey, @"client_id",
                                                                      @"code", @"response_type",
                                                                      redirectURI, @"redirect_uri", 
                                                                      @"mobile", @"display", nil];
    NSString *urlString = [WBRequest serializeURL:kWBAuthorizeURL
                                           params:params
                                       httpMethod:@"GET"];
    
//    WBAuthorizeWebView *webView = [[WBAuthorizeWebView alloc] init];
//    [webView setDelegate:self];
//    [webView loadRequestWithURL:[NSURL URLWithString:urlString]];
//    [webView show:YES];
//    [webView release];
	
	[self showWebViewWith:urlString];
}

- (void)startAuthorizeUsingUserID:(NSString *)userID password:(NSString *)password
{
    [self requestAccessTokenWithUserID:userID password:password];
}

#define kTransitionDuration 0.3
- (CGAffineTransform)transformForOrientation 
{
	UIInterfaceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation;
	if (orientation == UIInterfaceOrientationLandscapeLeft) {
		return CGAffineTransformMakeRotation(M_PI*1.5);
	} else if (orientation == UIInterfaceOrientationLandscapeRight) {
		return CGAffineTransformMakeRotation(M_PI/2);
	} else if (orientation == UIInterfaceOrientationPortraitUpsideDown) {
		return CGAffineTransformMakeRotation(-M_PI);
	} else {
		return CGAffineTransformIdentity;
	}
}

#pragma mark - 显示webView 程序内登陆的界面
- (void)showWebViewWith:(NSString*)_url
{
	[PKToastView dismissWithAnimation:NO];

	if ([webView_.subviews count] == 0) {
		//添加一个头
		UIButton *titleBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 320, 44)];
		[titleBtn setBackgroundImage:[UIImage imageNamed:@"head"]
							forState:UIControlStateHighlighted];
		[titleBtn setBackgroundImage:[UIImage imageNamed:@"head"]
							forState:UIControlStateNormal];
		[webView_ addSubview:titleBtn];
		[titleBtn release];
		
		UIButton *backBtn = [[UIButton alloc] initWithFrame:CGRectMake(10, 0, 60, 45)];
		[backBtn setTitle:@"取消" forState:UIControlStateNormal];
		backBtn.titleLabel.font = [UIFont systemFontOfSize:14];
		backBtn.titleLabel.adjustsFontSizeToFitWidth = TRUE;
		[backBtn addTarget:self
					action:@selector(dismissWebView)
		  forControlEvents:UIControlEventTouchUpInside];
		[backBtn setBackgroundImage:[UIImage imageNamed:@"bianji.png"] 
						   forState:UIControlStateNormal];
		[backBtn setBackgroundImage:[UIImage imageNamed:@"bianjidown.png"] 
						   forState:UIControlStateHighlighted];
		[webView_ addSubview:backBtn];
		[backBtn release];
		
		
		UIWebView *_curWebView = [[UIWebView alloc] initWithFrame:CGRectMake(0, 44, 320, [[UIScreen mainScreen] bounds].size.height-64)];
		_curWebView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
		_curWebView.delegate = self;
		[_curWebView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:_url]]];
		_curWebView.tag = 5;
		[webView_ addSubview:_curWebView];
		[_curWebView release];
		
	}
	else 
	{
		UIView *_curWebView = [webView_ viewWithTag:5];
		[(UIWebView *)_curWebView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:_url]]];
	}
	UIWindow *window = [UIApplication sharedApplication].keyWindow;
	if (!window) {
		window = [[UIApplication sharedApplication].windows objectAtIndex:0];
	}
	webView_.frame = CGRectMake(0, 20, 320, [[UIScreen mainScreen] bounds].size.height);
	[window addSubview:webView_];
	
//	webView_.transform = CGAffineTransformScale([self transformForOrientation], 0.001, 0.001);
//	[UIView beginAnimations:nil context:nil];
//	[UIView setAnimationDuration:kTransitionDuration/1.5];
//	[UIView setAnimationDelegate:self];
//	[UIView setAnimationDidStopSelector:@selector(bounce1AnimationStopped)];
//	webView_.transform = CGAffineTransformScale([self transformForOrientation], 1.1, 1.1);
//	[UIView commitAnimations];
}

- (void)dismissWebView
{
	[webView_ removeFromSuperview];
	UIView *_curWebView = [webView_ viewWithTag:5];
	[(UIWebView *)_curWebView loadHTMLString:@"" baseURL:nil];
	
	if (delegate&&[delegate respondsToSelector:@selector(authorize:cancelAuthorize:)])
	{
		[delegate authorize:self cancelAuthorize:nil];
	}
}

#pragma mark - UIWebView Delegate Methods
- (BOOL)webView:(UIWebView *)aWebView shouldStartLoadWithRequest:(NSURLRequest *)requesttt navigationType:(UIWebViewNavigationType)navigationType
{
	
    NSRange range = [requesttt.URL.absoluteString rangeOfString:@"code="];
    if (range.location != NSNotFound)
    {
        NSString *code = [requesttt.URL.absoluteString substringFromIndex:range.location + range.length];
		// if not canceled
		if (![code isEqualToString:@"21330"])
		{
			[self requestAccessTokenWithAuthorizeCode:code];
			[self dismissWebView];
		}
    }
    
    return YES;
}


#pragma mark - WBRequestDelegate Methods

- (void)request:(WBRequest *)theRequest didFinishLoadingWithResult:(id)result
{
    BOOL success = NO;
    if ([result isKindOfClass:[NSDictionary class]])
    {
        NSDictionary *dict = (NSDictionary *)result;
        
        NSString *token = [dict objectForKey:@"access_token"];
        NSString *userID = [dict objectForKey:@"uid"];
        NSInteger seconds = [[dict objectForKey:@"expires_in"] intValue];
        
        success = token && userID;
        
        if (success && [delegate respondsToSelector:@selector(authorize:didSucceedWithAccessToken:userID:expiresIn:)])
        {
            [delegate authorize:self didSucceedWithAccessToken:token userID:userID expiresIn:seconds];
        }
    }
    
    // should not be possible
    if (!success && [delegate respondsToSelector:@selector(authorize:didFailWithError:)])
    {
        NSError *error = [NSError errorWithDomain:kWBSDKErrorDomain 
                                             code:kWBErrorCodeSDK 
                                         userInfo:[NSDictionary dictionaryWithObject:[NSString stringWithFormat:@"%d", kWBSDKErrorCodeAuthorizeError] 
                                                                              forKey:kWBSDKErrorCodeKey]];
        [delegate authorize:self didFailWithError:error];
    }
}

- (void)request:(WBRequest *)theReqest didFailWithError:(NSError *)error
{
    if ([delegate respondsToSelector:@selector(authorize:didFailWithError:)])
    {
        [delegate authorize:self didFailWithError:error];
    }
}

@end
