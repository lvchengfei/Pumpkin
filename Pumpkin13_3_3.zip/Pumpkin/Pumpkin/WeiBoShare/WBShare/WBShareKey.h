//
//  WBShareKey.h
//  WBShareKit
//
//  Created by Gao Semaus on 11-8-8.
//  Copyright 2011年 Chlova. All rights reserved.
//

#define SINAAPPKEY				@"3305870153"										//@"2396343608" //设置sina appkey
#define SINAAPPSECRET			@"b68fa910cfdddb471e3764c6c487a34b"					//@"bb5bdc7df7609a13ffdf7201c32de2b0"

#define DOUBANAPPKEY @"0c02534bf6111dcf2406f9e3e233596d" //设置douban appkey
#define DOUBANAPPSECRET @"27962f5a2d923156"

#define TXAPPKEY				@"801150142"										//@"527e334faf9c4eef86ad6bb1bb412163" //设置tx appkey
#define TXAPPSECRET				@"90b9247df07af8c7f746482f0ac6336c"					//@"0f4d7aae73b73e7ee7077d49e2e7140e"

#define TWITTERAPPKEY @"9CZRoVzLGQerndRrJJWM0w" //设置twitter appkey
#define TWITTERAPPSECRET @"pdyafzGseNvsBpy9H8i9nUDzUsuQrIMjmGGn7ITAogU"

#define WYAPPKEY @"3WEBUGnYsYzd6SUz" //设置163 appkey
#define WYAPPSECRET @"GJSDc48rnWKFITlHIMMS0Xho2ahbPfhm"

#define KXAPPKEY	@"628113534504c7fce1f147a45be49fe5"	 //设置KAIXIN appkey
#define KXAPPSECRET @"b6b3dd90ddd417dd5b4d6ac1dcc66cfd"	
//豆瓣
#define DOUBANRequestURL @"http://www.douban.com/service/auth/request_token" //获取未授权request token
#define DOUBANAuthorizeURL @"http://www.douban.com/service/auth/authorize"  //获取授权request token
#define DOUBANAccessURL @"http://www.douban.com/service/auth/access_token"  //获取access token

//新浪
#define SINARequestURL @"http://api.t.sina.com.cn/oauth/request_token" //获取未授权request token
#define SINAAuthorizeURL @"http://api.t.sina.com.cn/oauth/authorize"  //获取授权request token
#define SINAAccessURL @"http://api.t.sina.com.cn/oauth/access_token"  //获取access token

//腾讯
#define TXRequestURL @"https://open.t.qq.com/cgi-bin/request_token" //获取未授权request token
#define TXAuthorizeURL @"https://open.t.qq.com/cgi-bin/authorize"  //获取授权request token
#define TXAccessURL @"https://open.t.qq.com/cgi-bin/access_token"  //获取access token

//TWITTER
#define TWITTERRequestURL @"https://api.twitter.com/oauth/request_token" //获取未授权request token
#define TWITTERAuthorizeURL @"https://api.twitter.com/oauth/authorize"  //获取授权request token
#define TWITTERAccessURL @"https://api.twitter.com/oauth/access_token"  //获取access token

//网易
#define WYRequestURL @"http://api.t.163.com/oauth/request_token" //获取未授权request token
#define WYAuthorizeURL @"http://api.t.163.com/oauth/authenticate"  //获取授权request token
#define WYAccessURL @"http://api.t.163.com/oauth/access_token"  //获取access token

//renren

//开心
#define KXRequestURL @"http://api.kaixin001.com/oauth/request_token" //获取未授权request token
#define KXAuthorizeURL @"http://api.kaixin001.com/oauth/authenticate"  //获取授权request token
#define KXAccessURL @"http://api.kaixin001.com/oauth/access_token"  //获取access token

#define CallBackURL @"oauth://maike.com"  //回调url

