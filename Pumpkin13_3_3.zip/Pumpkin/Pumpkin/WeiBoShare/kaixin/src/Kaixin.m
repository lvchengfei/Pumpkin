#import "Kaixin.h"
#import <CommonCrypto/CommonDigest.h>
#import "WeiboKey.h"


static NSString* kDialogBaseURL = @"https://api.kaixin001.com/oauth2/";
static NSString* kLogin = @"authorize";
static NSString* kRefreshTokenPath = @"access_token";


static Kaixin* globalKaiXin = nil;

///////////////////////////////////////////////////////////////////////////////////////////////////

@interface Kaixin ()

@end

///////////////////////////////////////////////////////////////////////////////////////////////////

@implementation Kaixin

@synthesize accessToken = _accessToken,
            refreshToken = _refreshToken,
         expirationDate = _expirationDate,
        sessionDelegate = _sessionDelegate;

///////////////////////////////////////////////////////////////////////////////////////////////////
// private




#pragma mark - Lv 



#define kTransitionDuration 0.3
- (CGAffineTransform)transformForOrientation 
{
	UIInterfaceOrientation orientation = [UIApplication sharedApplication].statusBarOrientation;
	if (orientation == UIInterfaceOrientationLandscapeLeft) {
		return CGAffineTransformMakeRotation(M_PI*1.5);
	} else if (orientation == UIInterfaceOrientationLandscapeRight) {
		return CGAffineTransformMakeRotation(M_PI/2);
	} else if (orientation == UIInterfaceOrientationPortraitUpsideDown) {
		return CGAffineTransformMakeRotation(-M_PI);
	} else {
		return CGAffineTransformIdentity;
	}
}

- (void)showWebViewWith:(NSURLRequest*)requestURL
{
	if ([webView_.subviews count] == 0) {
		//添加一个头
		UIButton *titleBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 320, 44)];
		[titleBtn setBackgroundImage:[UIImage imageNamed:@"head"]
							forState:UIControlStateHighlighted];
		[titleBtn setBackgroundImage:[UIImage imageNamed:@"head"]
							forState:UIControlStateNormal];
		[webView_ addSubview:titleBtn];
		[titleBtn release];
		
		UIButton *backBtn = [[UIButton alloc] initWithFrame:CGRectMake(10,0 , 60, 45)];
		[backBtn setTitle:@"取消" forState:UIControlStateNormal];
		backBtn.titleLabel.font = [UIFont systemFontOfSize:14];
		backBtn.titleLabel.adjustsFontSizeToFitWidth = TRUE;
		[backBtn addTarget:self
					action:@selector(cancelAuthorized)
		  forControlEvents:UIControlEventTouchUpInside];
		[backBtn setBackgroundImage:[UIImage imageNamed:@"bianji.png"] 
						   forState:UIControlStateNormal];
		[backBtn setBackgroundImage:[UIImage imageNamed:@"bianjidown.png"] 
						   forState:UIControlStateHighlighted];
		[webView_ addSubview:backBtn];
		[backBtn release];
		
		
		UIWebView *_curWebView = [[UIWebView alloc] initWithFrame:CGRectMake(0, 44, 320, [[UIScreen mainScreen] bounds].size.height-64)];
		_curWebView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
		_curWebView.delegate = self;
		[_curWebView loadRequest:requestURL];
		_curWebView.tag = 5;
		[webView_ addSubview:_curWebView];
		[_curWebView release];
		
	}
	else 
	{
		UIView *_curWebView = [webView_ viewWithTag:5];
		[(UIWebView *)_curWebView loadRequest:requestURL];
	}
	UIWindow *window = [UIApplication sharedApplication].keyWindow;
	if (!window) {
		window = [[UIApplication sharedApplication].windows objectAtIndex:0];
	}
	webView_.frame = CGRectMake(0, 20, 320, [[UIScreen mainScreen] bounds].size.height);
	[window addSubview:webView_];
		
	/*
	webView_.transform = CGAffineTransformScale([self transformForOrientation], 0.001, 0.001);
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDuration:kTransitionDuration/1.5];
	[UIView setAnimationDelegate:self];
	[UIView setAnimationDidStopSelector:@selector(bounce1AnimationStopped)];
	webView_.transform = CGAffineTransformScale([self transformForOrientation], 1.1, 1.1);
	[UIView commitAnimations];
	 */
}


- (void)dismissWebView
{
	[webView_ removeFromSuperview];
	UIView *_curWebView = [webView_ viewWithTag:5];
	[(UIWebView *)_curWebView loadHTMLString:@"" baseURL:nil];
}


- (void)cancelAuthorized
{
	if (_sessionDelegate&&[_sessionDelegate respondsToSelector:@selector(KaixinDidNotLogin:)])
	{
		[_sessionDelegate KaixinDidNotLogin:YES];
	}
	[self dismissWebView];
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// UIWebViewDelegate
#pragma mark - UIWebViewDelegate
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request
 navigationType:(UIWebViewNavigationType)navigationType {
    NSURL* url = request.URL;
    
    NSLog(@"[IN] UIWebViewDelegate::webView():request.URL = %@ \n",request.URL);
    
    if ([[url absoluteString] hasPrefix:KXRedirectURL])
    {
        if ([[url.resourceSpecifier substringToIndex:8] isEqualToString:@"//cancel"]) 
		{
			[self dismissWebView];
        }
		else 
		{
			[self dismissWebView];
			NSString *q = [url absoluteString];
			NSString *token = [KaixinDialog getStringFromUrl:q needle:@"access_token="];
			NSString *refreshToken = [KaixinDialog getStringFromUrl:q needle:@"refresh_token="];
			NSString *expTime = [KaixinDialog getStringFromUrl:q needle:@"expires_in="];
			NSDate *expirationDate =nil;
			
			if (expTime != nil) {
				int expVal = [expTime intValue];
				if (expVal == 0) {
					expirationDate = [NSDate distantFuture];
				} else {
					expirationDate = [NSDate dateWithTimeIntervalSinceNow:expVal];
				} 
			} 
			
			if ([token length]>0)
			{
				[self KaixinDialogLogin:token refreshToken:refreshToken expirationDate:expirationDate];
			}
		}
		return NO;
	} else if ([_loadingURL isEqual:url]) {
        return YES;
	} else if (navigationType == UIWebViewNavigationTypeLinkClicked) {
		[webView loadRequest:request];
		return YES;
	} else {
		return YES;
	}
}

- (void)webViewDidFinishLoad:(UIWebView *)webView {
	
	//[self updateWebOrientation];
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error {
	// 102 == WebKitErrorFrameLoadInterruptedByPolicyChange
	NSLog(@"dialog webview error : %@", [error localizedDescription]);
	if (!([error.domain isEqualToString:@"WebKitErrorDomain"] && error.code == 102)) {
		[self dismissWebView];
	}
}

#pragma mark - Life Cycle
 

+ (id)kaixinInstanceWithAppId:(NSString *)app_id reDirectURL:(NSString *)kRedirectURL secretKey:(NSString *)key
{
	if (globalKaiXin==nil)
	{
		globalKaiXin = [[Kaixin alloc] initWithAppId:app_id reDirectURL:kRedirectURL secretKey:key];
	}
	return globalKaiXin;
}

+ (void)releaseKaiXinInstace
{
	if (globalKaiXin)
	{
		[globalKaiXin release];
		globalKaiXin = nil;
	}
}

- (id)initWithAppId:(NSString *)app_id reDirectURL:(NSString *)kRedirectURL secretKey:(NSString *) key{
  self = [super init];
  if (self) {
    [_appId release];
    _appId = [app_id copy];
	[_kRedirectURL release];
	_kRedirectURL = [kRedirectURL copy];
	  [_secretKey release];
	  _secretKey = [key copy];
	  _loadingURL = nil;
	  webView_ = [[UIView alloc] initWithFrame:[UIScreen mainScreen].bounds];
	  
	  NSUserDefaults *defaults=[NSUserDefaults standardUserDefaults];	
	  self.accessToken = [defaults objectForKey:@"access_Token"];
	  self.refreshToken = [defaults objectForKey:@"refresh_Token"];
	  self.expirationDate = [defaults objectForKey:@"expiration_Date"];	  
  }
  return self;
}

/**
 * Override NSObject : free the space
 */
- (void)dealloc {
  [webView_	release];
  [_accessToken release];
  [_refreshToken release];
  [_expirationDate release];
  [_request release];
  [_loginDialog release];
  [_KaixinDialog release];
  [_appId release];
  [_kRedirectURL release];
  [_secretKey release];
	_loadingURL = nil;
  [super dealloc];
}

/**
 * A private helper function for sending HTTP requests.
 *
 * @param url
 *            url to send http request
 * @param params
 *            parameters to append to the url
 * @param httpMethod
 *            http method @"GET" or @"POST"
 * @param delegate
 *            Callback interface for notifying the calling application when
 *            the request has received response
 */
- (KaixinRequest*)openUrl:(NSString *)url
               params:(NSMutableDictionary *)params
           httpMethod:(NSString *)httpMethod
             delegate:(id<KaixinRequestDelegate>)delegate {

  
  [_request release];
  _request = [[KaixinRequest getRequestWithParams:params
                                   httpMethod:httpMethod
                                     delegate:delegate
                                   requestURL:url] retain];
  [_request connect];
  return _request;
}



/**
 * save login information
 */
-(void)createUserSessionInfo{
	NSUserDefaults *defaults=[NSUserDefaults standardUserDefaults];	
	if (self.accessToken) {
		[defaults setObject:self.accessToken forKey:@"access_Token"];
	}
	if (self.refreshToken) {
		[defaults setObject:self.refreshToken forKey:@"refresh_Token"];
	}    
	if (self.expirationDate) {
		[defaults setObject:self.expirationDate forKey:@"expiration_Date"];
	}
	[defaults synchronize];	
    
}

/**
 * delete saved information 
 */
-(void)delUserSessionInfo{
	NSUserDefaults *defaults=[NSUserDefaults standardUserDefaults];
    [defaults removeObjectForKey:@"access_Token"];
    [defaults removeObjectForKey:@"refresh_Token"];   
	[defaults removeObjectForKey:@"expiration_Date"];
    [defaults synchronize];
}

/**
 * Getting a new access_token by the refresh_token when current access_token out of date.
 */

- (KaixinRequest*)requestByRefreshTokenHttpMethod:(NSString *) StrHttpMethod
                             andDelegate:(id <KaixinRequestDelegate>)delegate{	
    
    self.accessToken = nil;
    
    if ((self.refreshToken == (NSString *) [NSNull null]) || (self.refreshToken.length == 0)) {
        return nil;
    }
    
    NSString *getRefreshTokenURL = [kDialogBaseURL stringByAppendingString:kRefreshTokenPath];
    
    NSMutableDictionary* params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   @"refresh_token", @"grant_type",
                                   _refreshToken, @"refresh_token",
                                   _appId, @"client_id",
                                   _secretKey, @"client_secret",
                                   nil];
    
	return [self openUrl:getRefreshTokenURL
				  params:params
			  httpMethod:StrHttpMethod
				delegate:delegate];
}



/**
 * A function for parsing URL parameters.
 */
- (NSDictionary*)parseURLParams:(NSString *)query {
	NSArray *pairs = [query componentsSeparatedByString:@"&"];
	NSMutableDictionary *params = [[[NSMutableDictionary alloc] init] autorelease];
	for (NSString *pair in pairs) {
		NSArray *kv = [pair componentsSeparatedByString:@"="];
		NSString *val =
    [[kv objectAtIndex:1]
     stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];

		[params setObject:val forKey:[kv objectAtIndex:0]];
	}
  return params;
}


///////////////////////////////////////////////////////////////////////////////////////////////////
//public

- (void)authorizeDelegate:(id<KaixinSessionDelegate>)delegate
{
    _sessionDelegate = delegate;
}

- (void)authorizeWithKXAppAuth
{
    NSMutableDictionary* params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   _appId, @"client_id",
                                   @"token", @"response_type",
                                   _kRedirectURL, @"redirect_uri",
                                   @"touch", @"display",
                                   @"basic%20create_records%20upload_photo%20user_photo", @"scope",//要多权限时，以%20串联各个权限标记，例如：“basic%20friends_records”
                                   nil];
    NSString *loginDialogURL = [kDialogBaseURL stringByAppendingString:kLogin];

	[_loadingURL	release];
	_loadingURL =  [[KaixinDialog generateURL:loginDialogURL params:params] retain];

	NSMutableURLRequest* request = [NSMutableURLRequest requestWithURL:_loadingURL];
	
	[self showWebViewWith:request];
	
	
//    [_loginDialog release];
//    _loginDialog = [[KaixinLoginDialog alloc] initWithURL:loginDialogURL
//                                              loginParams:params
//                                                 delegate:self];
//    [_loginDialog show];
}

- (void)authorizeWithLocalLoginInView:(UIView*)parent
{
    NSMutableDictionary* params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   _appId, @"client_id", 
                                   @"password",@"grant_type",
                                   _secretKey,@"client_secret",
                                   @"basic%20upload_photo%20user_photo", @"scope",//要多权限时，以%20串联各个权限标记，例如：“basic%20friends_records”
                                   nil];
    
    NSString *loginDialogURL = [kDialogBaseURL stringByAppendingString:@"access_token"];

    _localLoginDialog = [[KaixinLocalLoginDialog alloc] initWithURL:loginDialogURL
                                              loginParams:params
                                                 delegate:self];
    [parent addSubview:_localLoginDialog];
    [_localLoginDialog release];
}

- (void)logout:(id<KaixinSessionDelegate>)delegate {

  _sessionDelegate = delegate;

  [_accessToken release];
  _accessToken = nil;
  [_refreshToken release];
    _refreshToken = nil;   
  [_expirationDate release];
  _expirationDate = nil;

	NSHTTPCookieStorage* cookies = [NSHTTPCookieStorage sharedHTTPCookieStorage];
	NSArray* KaixinCookies = [cookies cookiesForURL:
							  [NSURL URLWithString:kDialogBaseURL]];
	
	for (NSHTTPCookie* cookie in KaixinCookies) {
		[cookies deleteCookie:cookie];
	}
	
  if ([self.sessionDelegate respondsToSelector:@selector(KaixinDidLogout)]) {
    [_sessionDelegate KaixinDidLogout];
  }
	
  [self delUserSessionInfo];
	
}


- (NSString*)generateCallId {
	return [NSString stringWithFormat:@"%.2f", [[NSDate date] timeIntervalSince1970]];
}


- (KaixinRequest*)requestWithSeparateURL:(NSString*) requestURL 
                           andHttpMethod:(NSString *) StrHttpMethod
                             andDelegate:(id <KaixinRequestDelegate>)delegate{	
    NSMutableDictionary *params=[NSMutableDictionary dictionaryWithObjectsAndKeys: 
                                 self.accessToken, @"access_token", 
                                 nil];

	return [self openUrl:requestURL
				  params:params
			  httpMethod:StrHttpMethod
				delegate:delegate];
}

- (KaixinRequest*)requestWithSeparateURL:(NSString*) requestURL 
                                  params:(NSDictionary*)requestParams
                           andHttpMethod:(NSString *) StrHttpMethod
                             andDelegate:(id <KaixinRequestDelegate>)delegate
{
    NSMutableDictionary *params = nil;
    
    if (requestParams != nil && [[requestParams allKeys] count] > 0)
    {
        params = [NSMutableDictionary dictionaryWithDictionary:requestParams];
        [params setObject:self.accessToken forKey:@"access_token"];
    }
    else
    {
        params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
        self.accessToken, @"access_token", 
        nil];    
    }
    
	return [self openUrl:requestURL
				  params:params
			  httpMethod:StrHttpMethod
				delegate:delegate];
}

- (void)dialog:(NSString *)action
   andDelegate:(id<KaixinDialogDelegate>)delegate {
  NSMutableDictionary * params = [NSMutableDictionary dictionary];
  [self dialog:action andParams:params andDelegate:delegate];
}

- (void)dialog:(NSString *)action
     andParams:(NSMutableDictionary *)params
   andDelegate:(id <KaixinDialogDelegate>)delegate {

  [_KaixinDialog release];

  NSString *dialogURL = [kDialogBaseURL stringByAppendingString:action];
  [params setObject:@"touch" forKey:@"display"];
  [params setObject:_kRedirectURL forKey:@"redirect_uri"];
  [params setObject:@"1" forKey:@"oauth_client"];
  if (action == kLogin) {
    _KaixinDialog = [[KaixinLoginDialog alloc] initWithURL:dialogURL loginParams:params delegate:self];
  } else {
    [params setObject:_appId forKey:@"app_id"];
    if ([self isSessionValid]) {
      [params setValue:[self.accessToken stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding]
                forKey:@"access_token"];
    }
    _KaixinDialog = [[KaixinDialog alloc] initWithURL:dialogURL params:params delegate:delegate];
  }

  [_KaixinDialog show];
}


- (BOOL)isSessionValid {
  return (self.accessToken != nil && self.expirationDate != nil
           && NSOrderedDescending == [self.expirationDate compare:[NSDate date]]);

}

- (void)KaixinDialogLogin:(NSString *)token 
             refreshToken:(NSString *)refresh_token 
           expirationDate:(NSDate *)expirationDate {
    self.accessToken = token;
    self.refreshToken = refresh_token;
    self.expirationDate = expirationDate;
    if ([self.sessionDelegate respondsToSelector:@selector(KaixinDidLogin)]) {
        [_sessionDelegate KaixinDidLogin];
    }
	
    [self createUserSessionInfo];	
    
}


- (void)KaixinDialogNotLogin:(BOOL)cancelled {
  if ([self.sessionDelegate respondsToSelector:@selector(KaixinDidNotLogin:)]) {
    [_sessionDelegate KaixinDidNotLogin:cancelled];
  }
}


- (void)request:(KaixinRequest*)request didFailWithError:(NSError*)error{
  NSLog(@"Failed to expire the session");
}



@end
